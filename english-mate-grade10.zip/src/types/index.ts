export type Language = 'ar' | 'en';
export type Theme = 'light' | 'dark';

export interface VocabularyWord {
  id: string;
  word: string;
  phonetic: string;
  partOfSpeech: string;
  unit: 1 | 2 | 3 | 4;
  lesson: string;
  page: number;
  arabicMeaning: string;
  englishDefinition: string;
  exampleSentence: string;
}

export interface Lesson {
  id: string;
  unitId: number;
  lessonNumber: number;
  type: 'Opener' | 'Reading' | 'Grammar' | 'Listening' | 'Speaking' | 'Writing' | 'Project';
  titleEn: string;
  titleAr: string;
  pageNumber: number;
  newVocabulary: string[];
  grammarFocus?: string;
  objectiveEn: string;
  objectiveAr: string;
  content: {
    summaryEn: string;
    summaryAr: string;
    headline?: string;
    readingText?: string;
    readingHeadline?: string;
    listeningScript?: string;
    speakingPrompts?: string[];
    usefulLanguage?: { title: string; expressions: string[] }[];
    writingPrompt?: {
      topic: string;
      requirements: string[];
      linkers: string[];
      modelParagraph?: string;
    };
    tasks: {
      id: string;
      questionEn: string;
      questionAr: string;
      type: 'mcq' | 'true_false' | 'fill_blank' | 'matching' | 'discussion';
      options?: string[];
      correctAnswer: string | number | boolean;
      explanation: string;
    }[];
  };
}

export interface Unit {
  id: number;
  moduleNameEn: string;
  moduleNameAr: string;
  titleEn: string;
  titleAr: string;
  descriptionEn: string;
  descriptionAr: string;
  themeColor: string;
  educationalValues: string[];
  centurySkills: string[];
  lessons: Lesson[];
}

export interface GrammarRule {
  id: string;
  number: number;
  unitId: number;
  titleEn: string;
  titleAr: string;
  page: number;
  summaryEn: string;
  summaryAr: string;
  rules: {
    heading: string;
    formula?: string;
    details: string;
    examples: { sentence: string; note?: string }[];
  }[];
  specialSection?: {
    title: string;
    items: any[];
  };
  practiceQuestions: {
    id: string;
    question: string;
    options: string[];
    correctAnswer: number;
    explanation: string;
  }[];
}

export interface LanguageFunction {
  id: string;
  categoryEn: string;
  categoryAr: string;
  page: number;
  expressions: string[];
  exampleDialogue: {
    speakerA: string;
    textA: string;
    speakerB: string;
    textB: string;
  };
}

export interface QuizQuestion {
  id: string;
  unitId: number;
  type: 'vocab' | 'grammar' | 'reading' | 'function';
  question: string;
  questionAr?: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
}

export interface StudentProgress {
  name: string;
  school: string;
  avatar: string;
  completedLessons: string[];
  completedQuizzes: Record<string, { score: number; total: number; date: string }>;
  savedNotes: Record<string, string>;
  bookmarks: string[];
  totalScore: number;
}
