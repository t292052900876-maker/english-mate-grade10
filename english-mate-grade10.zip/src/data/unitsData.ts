import { Unit } from '../types';

export const UNITS_DATA: Unit[] = [
  // ================= UNIT 1 =================
  {
    id: 1,
    moduleNameEn: 'Module One: The Sustainable Self',
    moduleNameAr: 'الوحدة النمطية الأولى: الذات المستدامة',
    titleEn: 'Unit One: The Science of Nutrition',
    titleAr: 'الوحدة الأولى: علم التغذية',
    descriptionEn: 'Explore how nutrition fuels our academic performance, well-being, traditional Kuwaiti heritage diets, and the science of personalised nutrition.',
    descriptionAr: 'استكشاف كيف تغذي التغذية السليمة أداءنا الدراسي، والتعرف على التطور الغذائي في الكويت وعلم التغذية المخصصة.',
    themeColor: 'emerald',
    educationalValues: [
      'Well-being',
      'Respect for heritage',
      'Health awareness',
      'Responsibility',
      'Maintaining routines',
      'Caring for family health',
      'Accepting different views',
      'Ethical thinking'
    ],
    centurySkills: [
      'Critical thinking',
      'Communication',
      'Creativity',
      'Collaboration',
      'Cultural awareness',
      'Self-expression',
      'Health literacy',
      'Media literacy'
    ],
    lessons: [
      {
        id: 'u1-l1',
        unitId: 1,
        lessonNumber: 1,
        type: 'Opener',
        titleEn: 'Food Log Reflection',
        titleAr: 'سجل الطعام والتأمل اليومي',
        pageNumber: 17,
        newVocabulary: ['nutritious', 'portion', 'swap', 'resist', 'pledge'],
        objectiveEn: 'Describe daily eating habits by analysing a food log and suggest simple healthy shifts.',
        objectiveAr: 'وصف العادات الغذائية اليومية من خلال تحليل سجل الطعام واقتراح تعهدات صحية بسيطة.',
        content: {
          summaryEn: 'Classifying daily food intake into Fuel, Treat, and Habitual, followed by creating a realistic nutrition pledge.',
          summaryAr: 'تصنيف الأطعمة اليومية إلى وقود صحي، مكافأة، وعادات عفوية، وصياغة تعهد غذائي أسبوعي.',
          tasks: [
            {
              id: 'u1-l1-t1',
              questionEn: 'Which category best describes fresh grilled fish with brown rice and leafy salad?',
              questionAr: 'أي تصنيف يصف بشكل أفضل وجبة السمك المشوي مع الأرز وسلطة الخضار؟',
              type: 'mcq',
              options: [
                'Fuel (nutritious and energising)',
                'Treat (fun and tasty, but not necessarily nutritious)',
                'Habitual (eaten out of boredom or stress)'
              ],
              correctAnswer: 0,
              explanation: 'Nutritious meals that give sustained energy and vitality are categorized as Fuel.'
            },
            {
              id: 'u1-l1-t2',
              questionEn: 'What is the most effective approach to establishing a nutrition pledge?',
              questionAr: 'ما هي الطريقة الأكثر فاعلية لصياغة التعهد الغذائي وفق نصيحة الكتاب؟',
              type: 'mcq',
              options: [
                'Using all-or-nothing statements like "I must stop eating everything delicious"',
                'Making small, realistic shifts such as "I am aiming to consume fewer sugary drinks"',
                'Skipping meals completely to lose weight quickly'
              ],
              correctAnswer: 1,
              explanation: 'The textbook emphasizes avoiding the all-or-nothing trap by phrasing pledges with "I am aiming to..." rather than "I must stop...".'
            }
          ]
        }
      },
      {
        id: 'u1-l2',
        unitId: 1,
        lessonNumber: 2,
        type: 'Reading',
        titleEn: 'The Evolution of the Kuwaiti Diet',
        titleAr: 'تطور النظام الغذائي الكويتي',
        pageNumber: 18,
        newVocabulary: ['bestow', 'nutrition', 'urge', 'routinely', 'inactive', 'attitude', 'stimulate', 'consume', 'notable', 'involvement'],
        objectiveEn: 'Analyse the causes and effects of dietary changes in Kuwait from the pearl-diving era to the modern age.',
        objectiveAr: 'تحليل أسباب ونتائج التحولات الغذائية في الكويت من عصر الغوص على اللؤلؤ حتى العصر الحديث.',
        content: {
          headline: 'From Traditional Resilience to Modern Nutrition Challenges',
          summaryEn: 'A historical and social analysis of how the discovery of oil changed food availability and daily physical activity in Kuwait.',
          summaryAr: 'دراسة اجتماعية وتاريخية لكيفية تحول نمط الغذاء والحياة الحركية بعد اكتشاف النفط ودور المدارس في التوعية.',
          readingText: `For centuries, the Kuwaiti diet reflected the lifestyle of pearl divers and fishermen. Meals were simple, healthy, and based on what the sea and desert could bestow. Fresh fish, dates, rice, and a few vegetables formed the foundation of daily nutrition. These foods gave people the energy needed for long hours of diving and sailing. Life was physically hard, and the diet matched this active lifestyle. As a result, health problems related to food were rare, and obesity was almost unknown.

However, with the discovery of oil and Kuwait’s rapid development, eating habits began to change. Supermarkets, restaurants, and fast-food chains introduced new options that were convenient but often high in fat, sugar, and salt. At the same time, daily life became less physically active. Cars replaced walking, and technology urged people to spend more time indoors. Research shows that many Kuwaiti teenagers, especially girls, engage in little physical activity. They do not routinely get enough exercise, and their lifestyles are inactive. Consequently, this shift has contributed to rising rates of obesity, as well as health problems such as diabetes.

To overcome these challenges, schools have become important places to stimulate healthier lifestyles. The programme developed in Kuwait by the Kuwait Flour Mills and Bakeries Company aims to teach students in selected schools about nutrition in engaging ways. Studies show that students who participated in the programme improved their healthy eating habits. They developed more positive attitudes and modified some of their behaviours. They ate more fruits and vegetables and consumed less fast food. This notable programme has made a significant difference in shaping healthier habits, especially with the help of the school’s involvement.

In conclusion, the Kuwaiti diet has evolved from the natural, balanced meals of the pearl-diving period to the modern challenges of fast food and inactive lifestyles. Research highlights the urgent need for action, especially among teenagers, to encourage physical activity and healthier eating habits. By combining traditional wisdom with modern educational programmes, Kuwait has the opportunity to guide its young people towards a healthier future.`,
          tasks: [
            {
              id: 'u1-l2-t1',
              questionEn: 'The main idea of the passage is:',
              questionAr: 'الفكرة الرئيسية للنص هي:',
              type: 'mcq',
              options: [
                'Modernisation and the oil industry have led to significant changes in eating habits and lifestyle.',
                'The traditional Kuwaiti diet suited the physical demands of pearl diving and fishing.',
                'The Kuwaiti diet has changed from simple, healthy meals to modern fast food.',
                'Nutrition educational programmes encourage healthier eating habits among students.'
              ],
              correctAnswer: 0,
              explanation: 'Paragraphs 1-4 cover the transition from traditional life through oil discovery, modern dietary shifts, and educational countermeasures.'
            },
            {
              id: 'u1-l2-t2',
              questionEn: 'The word ‘their’ in the 3rd paragraph ("modified some of their behaviours") refers to:',
              questionAr: 'كلمة "their" في الفقرة الثالثة تعود إلى:',
              type: 'mcq',
              options: ['positive attitudes', 'studies', 'students', 'eating habits'],
              correctAnswer: 2,
              explanation: 'In context: "Studies show that students who participated in the programme improved... They developed more positive attitudes and modified some of their behaviours."'
            },
            {
              id: 'u1-l2-t3',
              questionEn: 'What is the writing style of this passage?',
              questionAr: 'ما هو الأسلوب الكتابي المستخدم في المقال؟',
              type: 'mcq',
              options: ['expository', 'descriptive', 'persuasive', 'argumentative'],
              correctAnswer: 0,
              explanation: 'The text provides facts, historical timelines, and explanatory analysis, which is the expository style.'
            }
          ]
        }
      },
      {
        id: 'u1-l3',
        unitId: 1,
        lessonNumber: 3,
        type: 'Grammar',
        titleEn: 'Present Simple and Adverbs of Frequency',
        titleAr: 'المضارع البسيط وظروف التكرار',
        pageNumber: 20,
        newVocabulary: [],
        grammarFocus: 'Present Simple (Routines/Facts) & Position of Adverbs (always, usually, often, sometimes, hardly ever, never)',
        objectiveEn: 'Form affirmative sentences, negatives, questions, and position frequency adverbs correctly.',
        objectiveAr: 'صياغة الجمل المثبتة والمنفية والاستفهامية في المضارع البسيط واستخدام ظروف التكرار في مكانها الصحيح.',
        content: {
          summaryEn: 'Grammar rules for present simple and frequency adverbs with exercises from page 20 and Grammar File page 86.',
          summaryAr: 'شرح مفصل لصيغ المضارع البسيط ومواقع ظروف التكرار وتدريبات كتاب الطالب.',
          tasks: [
            {
              id: 'u1-l3-t1',
              questionEn: 'Rewrite with adverb: "Rashed stays at home at the weekends. (never)"',
              questionAr: 'أعد كتابة الجملة مع ظرف التكرار: Rashed stays at home at the weekends. (never)',
              type: 'mcq',
              options: [
                'Rashed never stays at home at the weekends.',
                'Rashed stays never at home at the weekends.',
                'Never Rashed stays at home at the weekends.',
                'Rashed stays at home never at the weekends.'
              ],
              correctAnswer: 0,
              explanation: 'Frequency adverbs are placed directly before the main verb (stays).'
            },
            {
              id: 'u1-l3-t2',
              questionEn: 'Rewrite with adverb: "My water bottle is full to ensure I stay hydrated. (always)"',
              questionAr: 'أعد كتابة الجملة مع ظرف التكرار: My water bottle is full to ensure I stay hydrated. (always)',
              type: 'mcq',
              options: [
                'My water bottle always is full.',
                'My water bottle is always full to ensure I stay hydrated.',
                'Always my water bottle is full.',
                'My water bottle is full always.'
              ],
              correctAnswer: 1,
              explanation: 'Adverbs of frequency are placed AFTER the verb "to be" (is always).'
            }
          ]
        }
      },
      {
        id: 'u1-l4',
        unitId: 1,
        lessonNumber: 4,
        type: 'Listening',
        titleEn: 'The Heritage Lunchbox',
        titleAr: 'صندوق الغداء التراثي الصحي',
        pageNumber: 21,
        newVocabulary: ['prioritise', 'soak', 'filling', 'aroma', 'preservatives'],
        objectiveEn: 'Identify main ideas and specific details in an audio conversation between two mothers about healthy school lunchboxes.',
        objectiveAr: 'استخراج الأفكار الرئيسية والتفاصيل الدقيقة من حوار صوتي بين أمهات حول صناديق الغداء المدرسية الصحية.',
        content: {
          summaryEn: 'Sara and Noor discuss swapping refined white bread and store-bought snacks with traditional whole-wheat Regag and cardamom-scented date bites.',
          summaryAr: 'حوار بين سارة ونور حول استبدال الخبز الأبيض والحلويات المصنعة بخبز الرقاق الأسمر وكرات التمر بالهيل.',
          listeningScript: `Sara: Good morning, Noor! I noticed you are packing lunchboxes for the kids early. What are you preparing today?
Noor: Good morning, Sara! I am prioritizing wholesome ingredients today. Instead of buying commercial white sandwich bread loaded with preservatives, I use whole-wheat Regag bread.
Sara: That sounds wonderful! But what about cheese? Kids often complain that traditional halloumi is too salty.
Noor: Exactly! The trick is to soak halloumi cheese in cool water for about twenty minutes beforehand. It cuts down the salt while keeping its rich texture.
Sara: Brilliant idea. And what sweet treat do you pack so they don’t feel deprived?
Noor: Instead of store-bought cookies filled with artificial sugars, I make Date Energy Bites with crushed walnuts and rolled oats. I add a pinch of freshly ground cardamom to give them that warm, authentic Kuwaiti aroma!
Sara: My kids would love that! It connects them to our heritage while avoiding harmful preservatives.`,
          tasks: [
            {
              id: 'u1-l4-t1',
              questionEn: 'According to Noor, how can parents reduce the salt in halloumi cheese?',
              questionAr: 'وفقاً لنور، كيف يمكن للأمهات تقليل الملح في جبن الحلوم؟',
              type: 'mcq',
              options: [
                'By soaking it in water before serving',
                'By frying it in vegetable oil',
                'By mixing it with mayonnaise',
                'By freezing it overnight'
              ],
              correctAnswer: 0,
              explanation: 'Noor explains that soaking halloumi in cool water reduces sodium content.'
            },
            {
              id: 'u1-l4-t2',
              questionEn: 'True or False: Noor uses store-bought mayonnaise in her children’s wraps.',
              questionAr: 'صح أم خطأ: تستخدم نور المايونيز الجاهز في لفائف أطفالها.',
              type: 'true_false',
              options: ['True', 'False'],
              correctAnswer: false,
              explanation: 'False. Noor avoids artificial preservatives and ultra-processed condiments.'
            }
          ]
        }
      },
      {
        id: 'u1-l5',
        unitId: 1,
        lessonNumber: 5,
        type: 'Speaking',
        titleEn: 'International School Meal Systems',
        titleAr: 'أنظمة الوجبات المدرسية حول العالم',
        pageNumber: 22,
        newVocabulary: ['subsidise', 'affordable', 'organisation', 'indeed', 'nutritional'],
        objectiveEn: 'Compare global school meal systems (Japan, USA, Finland) and present balanced arguments on school meals.',
        objectiveAr: 'المقارنة بين أنظمة الوجبات المدرسية العالمية (اليابان، أمريكا، فنلندا) والتحدث عن مزايا وعيوب كل نظام.',
        content: {
          summaryEn: 'Case studies: Japan’s Kyushoku educational lunches, Finland’s free meals since 1948, and USA’s packed lunches.',
          summaryAr: 'دراسة مقارنة لوجبات كيوشوكو في اليابان، والوجبات المجانية في فنلندا، والوجبات المحضرة منزلياً في أمريكا.',
          usefulLanguage: [
            {
              title: 'Introducing oneself & Expressing Opinion',
              expressions: [
                'Good morning, my name is…',
                'In my opinion, providing nutritious school meals is essential...',
                'I believe that teaching students to serve lunches builds responsibility.'
              ]
            },
            {
              title: 'Stating Advantages & Disadvantages',
              expressions: [
                'A major advantage is that it ensures all children are treated equitably.',
                'On the other hand, packed lunches require complex daily organisation by families.'
              ]
            }
          ],
          tasks: [
            {
              id: 'u1-l5-t1',
              questionEn: 'In Japan, why do students cook and serve the school lunch themselves?',
              questionAr: 'لماذا يقوم الطلاب في اليابان بإعداد وتقديم وجبات الغداء المدرسية بأنفسهم؟',
              type: 'mcq',
              options: [
                'To teach responsibility and teamwork as part of their education',
                'Because schools lack professional kitchen staff',
                'To save money on government subsidies',
                'Because it is an exam requirement'
              ],
              correctAnswer: 0,
              explanation: 'In Japan, Kyushoku is educational; students serve meals to cultivate responsibility and appreciation.'
            }
          ]
        }
      },
      {
        id: 'u1-l6',
        unitId: 1,
        lessonNumber: 6,
        type: 'Writing',
        titleEn: 'Smart Canteen Swaps',
        titleAr: 'خيارات ذكية للمقصف المدرسي',
        pageNumber: 23,
        newVocabulary: [],
        objectiveEn: 'Plan and write an expository paragraph of no fewer than 8 sentences explaining the benefits of healthy canteen options.',
        objectiveAr: 'تخطيط وكتابة فقرة تفسيرية متماسكة لا تقل عن 8 جمل لشرح فوائد الخيارات الصحية في المقصف المدرسي.',
        content: {
          summaryEn: 'Structure an expository paragraph: Introductory Sentence, Supporting Idea 1 (benefits), Supporting Idea 2 (healthy swaps), and Concluding Sentence.',
          summaryAr: 'هيكلة الفقرة التفسيرية: الجملة الافتتاحية، فكرتان داعمتان، أدوات الربط (furthermore, consequently, ultimately)، والجملة الختامية.',
          writingPrompt: {
            topic: 'Write a paragraph explaining the benefits of healthy canteen food options and suggesting alternative items.',
            requirements: [
              'No fewer than 8 sentences (approximately 90 words)',
              'Use linkers: furthermore, moreover, consequently, therefore, ultimately',
              'Organise into Introduction, Supporting Ideas, and Conclusion'
            ],
            linkers: ['furthermore', 'moreover', 'consequently', 'therefore', 'ultimately', 'in summary'],
            modelParagraph: 'Promoting healthy choices in the school canteen is essential for both academic performance and student well-being. When students consume nutritious meals, their cognitive focus improves significantly. Furthermore, reducing high-sugar sodas and snacks prevents energy crashes during long classroom hours. Consequently, replacing processed pastries with whole-wheat sandwiches and fresh fruit options helps students stay alert. Another excellent option is introducing chilled date-milk smoothies and unsalted nuts. Moreover, when schools subsidise these wholesome items, healthy eating becomes accessible to everyone. Therefore, investing in healthy canteen options shapes lifelong positive habits. Ultimately, nourishing students properly is the foundation of a thriving school community.'
          },
          tasks: [
            {
              id: 'u1-l6-t1',
              questionEn: 'Which transition word is best suited to introduce the concluding sentence of an essay?',
              questionAr: 'أي من أدوات الربط التالية هي الأنسب لبداية الجملة الختامية؟',
              type: 'mcq',
              options: ['Ultimately', 'Furthermore', 'Moreover', 'For example'],
              correctAnswer: 0,
              explanation: '"Ultimately" and "In summary" are standard conclusion linkers.'
            }
          ]
        }
      },
      {
        id: 'u1-l7',
        unitId: 1,
        lessonNumber: 7,
        type: 'Reading',
        titleEn: 'Personalised Nutrition',
        titleAr: 'التغذية المخصصة والشخصية',
        pageNumber: 24,
        newVocabulary: ['malnutrition', 'effective', 'personalised', 'biological', 'chemically', 'process', 'fatigue', 'inflammation', 'regulate', 'still'],
        objectiveEn: 'Deduce meaning from scientific texts and understand the link between genetics, the gut microbiome, and mental health.',
        objectiveAr: 'فهم النصوص العلمية حول العلاقة بين الجينات والميكروبيوم المعوي والصحة النفسية (الطب النفسي الغذائي).',
        content: {
          headline: 'One Size Does Not Fit All in Modern Dietary Science',
          summaryEn: 'Scientific breakdown of why universal food pyramids are being replaced by DNA-based and microbiome-tailored nutritional plans.',
          summaryAr: 'شرح علمي لأسباب تحول الطب الحديث عن الهرم الغذائي الموحد إلى خطط تغذية فردية مبنية على فحص الدم والحمض النووي.',
          readingText: `Have you seen the standard food pyramid? Or heard the “eat five portions of fruits and vegetables a day” rule? For a long time, dietary advice has been the same for everyone. These general guidelines were created to prevent malnutrition and promote basic health. However, science is now showing us that these broad rules may not be as effective as we once thought. Nutrition is becoming more personalised, moving away from a «one size fits all» approach toward strategies designed to suit our unique biological needs.

Personalised nutrition is based on the fact that every person is chemically unique. Factors like our genetics, our gut microbiome, which is the trillions of good bacteria in our digestive systems, and our daily habits affect how our bodies process food. For example, two people eating the same meal may have very different blood sugar responses. Using data from DNA and blood tests, scientists are helping people identify which foods give them energy and which might cause fatigue or inflammation.

This scientific shift is also revealing a strong connection between what we eat and our mental health. This field, called nutritional psychiatry, shows that our food choices are linked to how our brains function and how we feel. When we eat food that does not match our body's needs, it can cause inflammation. Research suggests that chronic inflammation may change the chemicals that regulate our mood and emotions. Therefore, a diet that works for one person might make another feel tired, anxious, or unable to focus.

Moving toward personalised nutrition is not just about avoiding disease; it is about using food to improve our mental well-being. When we view nutrition as self-care rather than a firm set of rules, we can better manage stress and think more clearly. While personalised nutrition is still a new field, the message is clear: the best diet is not one recommended for everyone, but one specially designed for your own body and mind. By listening to the unique signals our bodies send, we can look forward to a future where food is the foundation of both physical and mental strength.`,
          tasks: [
            {
              id: 'u1-l7-t1',
              questionEn: 'The word "personalised" in the 1st paragraph is an antonym (opposite) of:',
              questionAr: 'كلمة "personalised" في الفقرة الأولى هي مضاد (عكس) لكلمة:',
              type: 'mcq',
              options: ['standard', 'original', 'different', 'modern'],
              correctAnswer: 0,
              explanation: '"Personalised" means custom-tailored for an individual, opposite of "standard" (uniform for all).'
            },
            {
              id: 'u1-l7-t2',
              questionEn: 'What is the writer’s main purpose in writing this article?',
              questionAr: 'ما هو الهدف الرئيسي للكاتب من هذا المقال؟',
              type: 'mcq',
              options: [
                'To explain why general dietary advice is changing',
                'To persuade readers to buy expensive DNA tests',
                'To describe the ancient history of food pyramids',
                'To compare vegetarian diets with meat diets'
              ],
              correctAnswer: 0,
              explanation: 'The writer explains how modern science is moving from broad universal rules to tailored individual nutrition.'
            }
          ]
        }
      },
      {
        id: 'u1-l8',
        unitId: 1,
        lessonNumber: 8,
        type: 'Grammar',
        titleEn: 'Present Simple Continuous & the Order of Adjectives',
        titleAr: 'المضارع المستمر وترتيب الصفات (OSASCOMP)',
        pageNumber: 26,
        newVocabulary: [],
        grammarFocus: 'Present Continuous & OSASCOMP (Opinion, Size, Age, Shape, Colour, Origin, Material, Purpose)',
        objectiveEn: 'Order multiple adjectives correctly and construct grammatically accurate present continuous sentences.',
        objectiveAr: 'ترتيب الصفات المتعددة بدقة وفق قاعدة OSASCOMP وبناء جمل المضارع المستمر بشكل سليم.',
        content: {
          summaryEn: 'OSASCOMP sequence practice and present continuous affirmative/negative drills from page 26 and Grammar File page 87.',
          summaryAr: 'تمارين ترتيب الصفات وصياغة المضارع المستمر بالأمثلة التطبيقية.',
          tasks: [
            {
              id: 'u1-l8-t1',
              questionEn: 'Complete the sentence with the correct order: "Avoid __________ meals to protect your heart. (processed / oily / massive)"',
              questionAr: 'رتب الصفات بشكل صحيح: processed / oily / massive',
              type: 'mcq',
              options: [
                'massive oily processed',
                'oily massive processed',
                'processed massive oily',
                'massive processed oily'
              ],
              correctAnswer: 0,
              explanation: 'Size (massive) ➔ Opinion/Quality (oily) ➔ Purpose/Type (processed).'
            },
            {
              id: 'u1-l8-t2',
              questionEn: 'Currently, I __________ (consult) a nutritionist to design a tailored meal plan.',
              questionAr: 'أكمل بصيغة الفعل الصحيحة: Currently, I ... (consult)',
              type: 'mcq',
              options: ['consult', 'am consulting', 'consulted', 'was consulting'],
              correctAnswer: 1,
              explanation: '"Currently" indicates an ongoing present arrangement, requiring "am consulting".'
            }
          ]
        }
      },
      {
        id: 'u1-l9',
        unitId: 1,
        lessonNumber: 9,
        type: 'Listening',
        titleEn: 'The Mediterranean Secret',
        titleAr: 'سر حمية البحر الأبيض المتوسط',
        pageNumber: 27,
        newVocabulary: ['sustainable', 'legume', 'stroll', 'decade', 'overlook'],
        objectiveEn: 'Listen to a podcast about the Mediterranean lifestyle and analyze its three main pillars: Diet, Socialising, and Physical Activity.',
        objectiveAr: 'الاستماع إلى بودكاست حول نمط حياة حوض المتوسط وتحليل ركائزه الثلاث: الغذاء، التواصل الاجتماعي، والنشاط البدني.',
        content: {
          summaryEn: 'The podcast reveals that the secret is not just olive oil and legumes, but the culture of gathering around food and gentle daily strolling.',
          summaryAr: 'البودكاست يوضح أن سر الصحة في المتوسط لا يقتصر على البقول وزيت الزيتون بل يمتد للمشاركة المجتمعية والمشي اليومي الهادئ.',
          listeningScript: `Narrator: Welcome to Health Horizons. For the past decade, the Mediterranean diet has appeared to be the gold standard of well-being. But is it just about what is on the plate? Let us explore its three main pillars.
First is Diet: Meals are rich in legumes such as chickpeas and lentils, fresh leafy greens, nuts, and healthy fats like olive oil. Red meat is eaten only occasionally.
Second is Socialising: People usually overlook how we eat. In Mediterranean cultures, meals are communal celebrations. Habitually sharing a meal with family and friends lowers stress hormones and elevates happiness.
Third is Natural Physical Activity: Rather than grueling gym regimens, people integrate movement naturally into their day. They take an evening stroll through town, walk to local markets, and garden.
The key takeaway is that you do not need to live in Greece or Italy to benefit. Anyone can adopt these sustainable habits by eating whole foods, connecting with loved ones, and walking every day.`,
          tasks: [
            {
              id: 'u1-l9-t1',
              questionEn: 'True or False: According to the podcast, people usually overlook HOW they eat and only concentrate on WHAT they eat.',
              questionAr: 'صح أم خطأ: وفقاً للبودكاست، غالباً ما يغفل الناس عن "كيفية" تناول الطعام ويركزون فقط على "نوع" الطعام.',
              type: 'true_false',
              options: ['True', 'False'],
              correctAnswer: true,
              explanation: 'True. The podcast states: "People usually overlook how we eat; habitually sharing a meal with loved ones is essential."'
            },
            {
              id: 'u1-l9-t2',
              questionEn: 'What are the three pillars of the Mediterranean lifestyle highlighted in the audio?',
              questionAr: 'ما هي الركائز الثلاث لنمط الحياة المتوسطي المذكورة في التسجيل؟',
              type: 'mcq',
              options: [
                'Diet, Socialising, and Physical Activity',
                'Calorie counting, Strict fasting, and Weight lifting',
                'Fast food, Energy drinks, and Rest',
                'Supplements, Technology, and Isolation'
              ],
              correctAnswer: 0,
              explanation: 'The three pillars are Diet (legumes/olive oil), Socialising (communal eating), and Physical Activity (evening strolls).'
            }
          ]
        }
      },
      {
        id: 'u1-l10',
        unitId: 1,
        lessonNumber: 10,
        type: 'Speaking',
        titleEn: 'Food Marketing',
        titleAr: 'التسويق الغذائي والوعي الإعلاني',
        pageNumber: 28,
        newVocabulary: ['hurdle', 'wholesome', 'tempting', 'assign', 'break down'],
        objectiveEn: 'Identify advertising psychology techniques (Colour Psychology, Happiness Association, Health Trick) and critique marketing claims.',
        objectiveAr: 'التعرف على الحيل النفسية في الإعلانات الغذائية (سيكولوجية الألوان، ربط السعادة، خدعة الألفاظ الصحية) ونقدها.',
        content: {
          summaryEn: 'Unpack why red and yellow stimulate hunger, why commercials show laughing friends instead of real ingredients, and words like "farm-fresh".',
          summaryAr: 'تحليل أسباب استخدام اللونين الأحمر والأصفر لفتح الشهية، وربط الوجبات السريعة بمشاهد المرح، واستخدام كلمات مضللة.',
          usefulLanguage: [
            {
              title: 'Expressing Preferences & Reasons',
              expressions: [
                'The healthiest thing about homemade food is that you control the sugar.',
                'Because of colour psychology, fast food logos look exceptionally tempting.'
              ]
            },
            {
              title: 'Expressing Uncertainty',
              expressions: [
                'I am not sure about whether this snack is truly natural.',
                'It is difficult to say without checking the nutrition label.'
              ]
            }
          ],
          tasks: [
            {
              id: 'u1-l10-t1',
              questionEn: 'Which advertising technique involves placing words like "natural" or "wholesome" on heavily processed snacks?',
              questionAr: 'أي تقنية إعلانية تعتمد على وضع كلمات مثل "طبيعي" أو "صحي" على منتجات مصنعة للغاية؟',
              type: 'mcq',
              options: [
                'Health Trick',
                'Colour Psychology',
                'Happiness Association',
                'Portion Distortion'
              ],
              correctAnswer: 0,
              explanation: 'The textbook identifies the "Health Trick" as using buzzwords like natural, farm-fresh, or wholesome on processed food.'
            }
          ]
        }
      },
      {
        id: 'u1-l11',
        unitId: 1,
        lessonNumber: 11,
        type: 'Writing',
        titleEn: 'Mindful Eating',
        titleAr: 'الأكل الواعي وفوائده الأكاديمية والجسدية',
        pageNumber: 29,
        newVocabulary: [],
        objectiveEn: 'Compose a well-structured expository essay explaining the physical and academic benefits of mindful eating.',
        objectiveAr: 'كتابة مقال تفسيري متكامل يوضح الفوائد الجسدية والدراسية للأكل الواعي.',
        content: {
          summaryEn: 'Classify benefits into Physical (improved digestion, better sleep, increased energy) and Academic (improved concentration, better test performance, reduced stress).',
          summaryAr: 'تصنيف فوائد الأكل الواعي إلى جسدية وأكاديمية واستخدام أدوات الربط في مقال متكامل.',
          tasks: [
            {
              id: 'u1-l11-t1',
              questionEn: 'Which of the following is considered an ACADEMIC benefit of mindful eating?',
              questionAr: 'أي مما يلي يُعد من الفوائد الأكاديمية للأكل الواعي وفقاً لتصنيف الكتاب؟',
              type: 'mcq',
              options: [
                'Improved concentration and better test performance',
                'Improved digestion and no post-meal drowsiness',
                'Lower blood pressure'
              ],
              correctAnswer: 0,
              explanation: 'Improved concentration, reduced exam stress, and better test performance are classified as Academic benefits.'
            }
          ]
        }
      }
    ]
  },

  // ================= UNIT 2 =================
  {
    id: 2,
    moduleNameEn: 'Module One: The Sustainable Self',
    moduleNameAr: 'الوحدة النمطية الأولى: الذات المستدامة',
    titleEn: 'Unit Two: Choices & Change',
    titleAr: 'الوحدة الثانية: خيارات وتغيير',
    descriptionEn: 'Discover renewable energy initiatives in Kuwait (Shagaya Energy Park), waste management systems, thrifting, upcycling, and sustainable consumer choices.',
    descriptionAr: 'استكشاف مشاريع الطاقة المتجددة في الكويت (مجمع الشقايا)، إدارة النفايات، وإعادة التدوير الإبداعي والخيارات الاستهلاكية المستدامة.',
    themeColor: 'teal',
    educationalValues: [
      'Responsibility',
      'Eco-friendly behaviour',
      'Saving energy',
      'Reducing waste',
      'Caring for the environment',
      'Global awareness',
      'Responsible consumption',
      'Civic duty'
    ],
    centurySkills: [
      'Critical thinking',
      'Communication',
      'Creativity',
      'Collaboration',
      'Environmental literacy',
      'Problem-solving',
      'Citizenship'
    ],
    lessons: [
      {
        id: 'u2-l1',
        unitId: 2,
        lessonNumber: 1,
        type: 'Opener',
        titleEn: 'Sustainable Living',
        titleAr: 'العيش المستدام',
        pageNumber: 33,
        newVocabulary: ['wind turbine', 'reusable', 'second-hand', 'landfill', 'injure'],
        objectiveEn: 'Discuss eco-friendly topics and give useful advice using functional expressions.',
        objectiveAr: 'مناقشة قضايا الاستدامة وتقديم نصائح بيئية عملية باستخدام العبارات الوظيفية.',
        content: {
          summaryEn: 'Categorising environmental actions into Effects of Waste, Recycling Systems, Types of Energy, and Eco-habits.',
          summaryAr: 'تصنيف الأنشطة البيئية وتقديم حلول لمشاكل إهدار الطاقة والبلاستيك.',
          tasks: [
            {
              id: 'u2-l1-t1',
              questionEn: 'Which device harnesses the power of flowing wind to generate electricity without burning fuel?',
              questionAr: 'ما هو الجهاز الذي يستغل قوة الرياح لتوليد الكهرباء دون حرق الوقود؟',
              type: 'mcq',
              options: ['Wind turbine', 'Solar panel', 'Smart meter', 'Oil tank'],
              correctAnswer: 0,
              explanation: 'A wind turbine has blades turned by the wind to produce clean electricity.'
            }
          ]
        }
      },
      {
        id: 'u2-l2',
        unitId: 2,
        lessonNumber: 2,
        type: 'Reading',
        titleEn: 'The Shagaya Renewable Energy Park',
        titleAr: 'مجمع الشقايا للطاقة المتجددة في الكويت',
        pageNumber: 34,
        newVocabulary: ['emission', 'alternative', 'flowing', 'convert', 'entirely', 'run out', 'ecosystem', 'expertise', 'awareness', 'decisive'],
        objectiveEn: 'Analyse an expository text about Kuwait’s flagship renewable energy facility and describe the cause-and-effect relationship of clean power.',
        objectiveAr: 'تحليل نص معلوماتي عن مشروع الشقايا في الكويت وفهم علاقات السبب والنتيجة للتحول للطاقة النظيفة.',
        content: {
          headline: 'Kuwait’s National Journey Toward 15% Renewable Energy by 2030',
          summaryEn: 'Comprehensive FAQ page on the Shagaya Renewable Energy Park managed by the Kuwait Institute for Scientific Research (KISR).',
          summaryAr: 'دليل الأسئلة الشائعة لمشروع مجمع الشقايا التابع لمعهد الكويت للأبحاث العلمية ورؤية الكويت 2030.',
          readingText: `For many years, Kuwait has relied heavily on fossil fuels, such as oil and natural gas, to generate electricity. While oil has supported the country’s growth, it also produces harmful emissions that can damage the environment. These emissions add to air pollution and climate change. As a result, decision-makers in Kuwait have begun exploring cleaner alternatives to reduce environmental harm and protect natural resources.

Kuwait has introduced a national project called the Shagaya Renewable Energy Park, located in a desert area west of Kuwait City. The park is managed by the Kuwait Institute for Scientific Research (KISR). The park includes various renewable energy technologies. Wind turbines use the power of flowing air to generate energy. Solar panels collect energy (light and heat) from the sun and convert it into electricity.

The park aims to generate electricity from renewable energy sources, such as solar and wind, rather than relying entirely on oil. This is an important step towards reducing pollution and preparing for the future. This includes Kuwait achieving its national goal of producing 15% of its energy from renewable sources by the year 2030. These methods are sustainable because they do not run out like fossil fuels. Using clean energy reduces the need to burn oil, thereby lowering harmful emissions released into the air, and leading to a healthier environment for people and natural ecosystems.

In addition to producing clean energy, the Shagaya Renewable Energy Park helps develop expertise in renewable energy. Engineers, researchers, and students can study how these systems work and improve them over time. This supports innovation, raises awareness, and makes Kuwait independent in its energy production.

The Shagaya Renewable Energy Park shows how Kuwait is taking decisive actions towards a more sustainable future. By combining clean energy with responsible actions, the country can reduce pollution, protect resources, and create a better environment for future generations.`,
          tasks: [
            {
              id: 'u2-l2-t1',
              questionEn: 'The word ‘alternatives’ in the 1st section means:',
              questionAr: 'معنى كلمة alternatives في الفقرة الأولى هو:',
              type: 'mcq',
              options: ['locations', 'gases', 'problems', 'replacements'],
              correctAnswer: 3,
              explanation: 'Alternatives are choices or replacements for traditional fossil fuels.'
            },
            {
              id: 'u2-l2-t2',
              questionEn: 'What is Kuwait’s national goal for renewable energy by the year 2030?',
              questionAr: 'ما هو الهدف الوطني لدولة الكويت في مجال الطاقة المتجددة بحلول عام 2030؟',
              type: 'mcq',
              options: [
                'Producing 15% of its energy from renewable sources',
                'Shutting down all power plants entirely',
                'Relying 100% on imported electricity',
                'Exporting all solar panels overseas'
              ],
              correctAnswer: 0,
              explanation: 'The text specifies Kuwait’s national goal of producing 15% of its energy from renewable sources by 2030.'
            }
          ]
        }
      },
      {
        id: 'u2-l3',
        unitId: 2,
        lessonNumber: 3,
        type: 'Grammar',
        titleEn: 'Present Perfect Simple',
        titleAr: 'المضارع التام البسيط',
        pageNumber: 36,
        newVocabulary: [],
        grammarFocus: 'Present Perfect Simple (have/has + V3) with time markers: since, for, already, just, yet, lately',
        objectiveEn: 'Use the present perfect simple with appropriate time expressions to talk about achievements and ongoing experiences.',
        objectiveAr: 'استخدام زمن المضارع التام البسيط والكلمات الدالة عليه للتعبير عن الإنجازات والخبرات.',
        content: {
          summaryEn: 'Grammar rules from textbook page 36 and Grammar File page 87-88 on has/have + past participle.',
          summaryAr: 'شرح قاعدة have/has مع التصريف الثالث ومواقع الكلمات الدالة.',
          tasks: [
            {
              id: 'u2-l3-t1',
              questionEn: 'Researchers have studied energy alternatives __________ many years.',
              questionAr: 'اختر الكلمة الصحيحة: Researchers have studied energy alternatives ... many years.',
              type: 'mcq',
              options: ['for', 'since', 'already', 'yet'],
              correctAnswer: 0,
              explanation: 'We use "for" to indicate a period or duration of time (many years).'
            },
            {
              id: 'u2-l3-t2',
              questionEn: 'Kuwait __________ (reduce) harmful emissions since it started using renewable energy.',
              questionAr: 'صحح الفعل بين القوسين: Kuwait ... (reduce)',
              type: 'mcq',
              options: ['has reduced', 'have reduced', 'reduced', 'is reducing'],
              correctAnswer: 0,
              explanation: '"Kuwait" is singular (it), so it takes "has reduced" in the present perfect.'
            }
          ]
        }
      },
      {
        id: 'u2-l4',
        unitId: 2,
        lessonNumber: 4,
        type: 'Listening',
        titleEn: 'Smart Homes, Smart Choices',
        titleAr: 'المنازل الذكية والخيارات الرشيدة',
        pageNumber: 37,
        newVocabulary: ['unplug', 'combination', 'vacant', 'unnecessary', 'concept'],
        objectiveEn: 'Listen to an interview with Dr Khaled and match smart devices to their eco-friendly functions.',
        objectiveAr: 'الاستماع لمقابلة إذاعية مع د. خالد ومطابقة الأجهزة المنزلية الذكية بوظائفها البيئية.',
        content: {
          summaryEn: 'Dr Khaled emphasizes that smart devices only succeed when paired with mindful human conservation habits.',
          summaryAr: 'د. خالد يوضح أن المنازل الذكية تحتاج إلى وعي بشري وسلوكيات مسؤولة لتوفير الطاقة.',
          listeningScript: `Host: Welcome to Smart Living. Today we have Dr Khaled to talk about energy conservation at home. Dr Khaled, what really makes a home "smart"?
Dr Khaled: Thank you! Many people think buying gadgets makes a home smart. In reality, the true solution is a combination of smart technology and responsible human behaviour.
Host: Can you give us concrete examples of these smart devices?
Dr Khaled: Certainly. First, solar panels installed on rooftops can produce clean energy directly from Kuwait’s abundant sunlight. Second, smart lights equipped with sensors can turn off automatically in vacant rooms. Third, smart meters track how much electricity is consumed in real time, alerting families to waste. Finally, smart thermostats control air conditioning schedules and reduce unnecessary cooling when nobody is home.
Host: What simple action can every student take right now?
Dr Khaled: Simply unplug chargers and game consoles when not in use. You will prevent phantom power drain and protect our environment.`,
          tasks: [
            {
              id: 'u2-l4-t1',
              questionEn: 'According to Dr Khaled, what is the real solution to having a truly smart home?',
              questionAr: 'وفقاً للدكتور خالد، ما هو الحل الحقيقي للحصول على منزل ذكي بحق؟',
              type: 'mcq',
              options: [
                'A combination of smart technology and behaviour',
                'Buying as many gadgets as possible',
                'Installing only smart meters',
                'Living without electricity'
              ],
              correctAnswer: 0,
              explanation: 'Dr Khaled explicitly states that smart technology combined with conscious human habits provides the real solution.'
            }
          ]
        }
      },
      {
        id: 'u2-l5',
        unitId: 2,
        lessonNumber: 5,
        type: 'Speaking',
        titleEn: 'Powering a Greener GCC',
        titleAr: 'طاقة نظيفة لخليج أكثر اخضراراً',
        pageNumber: 38,
        newVocabulary: ['ideal', 'power', 'ambitious', 'tailor', 'power grid'],
        objectiveEn: 'Extract data from GCC renewable energy projects (Shagaya, Sakaka, Masdar City, Dhofar) and conduct simulated interviews.',
        objectiveAr: 'استخلاص معلومات مشاريع الطاقة النظيفة الخليجية (الشقايا، سكاكا، مدينة مصدر، ظفار) وإجراء حوار إذاعي.',
        content: {
          summaryEn: 'GCC Projects: Shagaya (Kuwait), Sakaka Solar (Saudi Arabia), Masdar City (UAE - zero emissions), and Dhofar Wind Farm (Oman - first wind farm in the Gulf).',
          summaryAr: 'مقارنة مشاريع الطاقة المتجددة في دول مجلس التعاون الخليجي وأهدافها الطموحة.',
          tasks: [
            {
              id: 'u2-l5-t1',
              questionEn: 'Which GCC project was the first wind farm established in the Arabian Gulf?',
              questionAr: 'أي مشروع خليجي كان أول مزرعة رياح تأسست في الخليج العربي؟',
              type: 'mcq',
              options: [
                'The Dhofar project in Oman',
                'The Sakaka Solar Plant in Saudi Arabia',
                'Masdar City in UAE',
                'The Shagaya Park in Kuwait'
              ],
              correctAnswer: 0,
              explanation: 'Fact File: "The Dhofar project is the first wind farm in the Arabian Gulf, taking advantage of Oman’s powerful winds."'
            }
          ]
        }
      },
      {
        id: 'u2-l6',
        unitId: 2,
        lessonNumber: 6,
        type: 'Writing',
        titleEn: 'Power With Purpose',
        titleAr: 'طاقة هادفة لمستقبل مستدام',
        pageNumber: 39,
        newVocabulary: [],
        objectiveEn: 'Write an 8-sentence expository paragraph explaining responsible home energy choices and smart technologies.',
        objectiveAr: 'كتابة فقرة من 8 جمل تشرح القرارات المسؤولة لتوفير الطاقة في المنزل والتقنيات الذكية.',
        content: {
          summaryEn: 'Organise writing using Topic Sentence, Supporting Ideas, and Concluding Sentence with suggestions: I suggest..., The best option would be...',
          summaryAr: 'تنظيم الكتابة في مقدمة وأفكار داعمة وخاتمة مع استخدام أساليب الاقتراح.',
          writingPrompt: {
            topic: 'Explain why making responsible choices at home is important and suggest smart technology to install.',
            requirements: ['At least 8 sentences', 'Include Topic Sentence, 2 Supporting Ideas, and Concluding Sentence'],
            linkers: ['In addition', 'Furthermore', 'Ultimately', 'Consequently'],
            modelParagraph: 'Caring for your home means caring for the planet and creating a better future. Renewable energy is one of the most important concepts of our time because it reduces harmful emissions. It helps protect ecosystems that are slowly running out of the resources they need to survive. Solar panels and wind turbines convert sunlight and wind into electricity without producing unnecessary pollution. In addition, renewable energy raises public awareness, encouraging people to make more decisive choices, such as using reusable products and reducing waste. Furthermore, installing smart thermostats and LED bulbs significantly lowers home energy consumption. Ultimately, renewable energy is not simply a scientific achievement; it is a promise of a healthier future that generations to come deserve.'
          },
          tasks: [
            {
              id: 'u2-l6-t1',
              questionEn: 'Which sentence serves as the Topic Sentence in the model paragraph?',
              questionAr: 'أي جملة تمثل الجملة الافتتاحية الرئيسية (Topic Sentence) في الفقرة النموذجية؟',
              type: 'mcq',
              options: [
                'Renewable energy is one of the most important concepts of our time because it reduces harmful emissions.',
                'Solar panels and wind turbines convert sunlight and wind.',
                'Ultimately, renewable energy is not simply a scientific achievement.',
                'In addition, renewable energy raises public awareness.'
              ],
              correctAnswer: 0,
              explanation: 'The topic sentence states the main idea: renewable energy is vital because it curtails emissions.'
            }
          ]
        }
      },
      {
        id: 'u2-l7',
        unitId: 2,
        lessonNumber: 7,
        type: 'Reading',
        titleEn: 'Think Before You Throw!',
        titleAr: 'فكر قبل أن ترمي! (دورة حياة المنتجات)',
        pageNumber: 40,
        newVocabulary: ['eventually', 'dispose of', 'enormous', 'upcycling', 'antique', 'directly', 'regard', 'make over', 'tablet', 'add up'],
        objectiveEn: 'Understand the product life cycle, distinguish thrifting from upcycling, and locate textual evidence.',
        objectiveAr: 'فهم دورة حياة المنتجات والتمييز بين شراء المستعمل (thrifting) وإعادة التدوير الإبداعي (upcycling).',
        content: {
          headline: 'Breaking the Waste Cycle Through Thrifting and Creative Upcycling',
          summaryEn: 'Explores raw material extraction, factory production, shipping, disposal, and sustainable alternatives in Kuwait.',
          summaryAr: 'شرح مراحل دورة حياة المنتج ومخاطر المكبات، والحلول في سوق الجمعة الكويتي والمتاجر الإلكترونية.',
          readingText: `Every item we own goes through what scientists call a life cycle. It begins with extracting raw materials from the earth. For example, cotton from fields, metal from mines, and plastic from oil are taken from the earth. These materials are then made into products in factories. After that, the products are transported by cargo ships, trucks, and planes before eventually reaching the shops where we buy them. Once used, we simply dispose of most items, ending up in landfills where they can take hundreds of years to break down. This cycle, repeated across the globe, places enormous pressure on our planet’s ecosystems.

The good news is that more people are choosing to break this cycle. Two of the most popular ways to do so are thrifting and upcycling. Thrifting means buying used or second-hand items instead of new ones. It is not simply about saving money, although that is one benefit. When you buy antiques or a second-hand jacket or book, you directly reduce the need for new production, which means using fewer raw materials and releasing fewer emissions into the atmosphere. Recently, in Kuwait and across the GCC, thrift markets such as Kuwait’s Friday Market and online second-hand shops have grown. This reflects a change in how younger generations regard consumption.

However, upcycling takes the idea one step further. Rather than simply reusing an item as it is, upcycling means changing it into something completely new and often more beautiful. An old blanket can be made over into a cosy, thick jacket. The yarn from old sweaters can be used for crochet or knitting projects. Old tablets can be reused as e-readers, reducing paper waste. Old electronics can be reused as decor, giving them a second life in a completely new form. These are not just hobbies; they are choices that reduce waste and lower the unnecessary use of new materials.

Indeed, understanding the life cycle of products is the first step towards making smarter, more sustainable choices. Whether you choose to thrift, upcycle, or simply think twice before throwing something away, every small action adds up. The planet does not need a handful of people making perfect choices; it needs millions of people making better ones.`,
          tasks: [
            {
              id: 'u2-l7-t1',
              questionEn: 'What is the correct sequential order of a product’s life cycle?',
              questionAr: 'ما هو الترتيب الصحيح لمراحل دورة حياة أي منتج؟',
              type: 'mcq',
              options: [
                'Extraction ➔ Production ➔ Transport ➔ Sale ➔ Disposal',
                'Production ➔ Extraction ➔ Disposal ➔ Transport ➔ Sale',
                'Disposal ➔ Extraction ➔ Production ➔ Sale ➔ Transport',
                'Sale ➔ Production ➔ Extraction ➔ Transport ➔ Disposal'
              ],
              correctAnswer: 0,
              explanation: 'Life cycle starts with raw material extraction from earth, factory production, transport, store sale, and eventual disposal.'
            },
            {
              id: 'u2-l7-t2',
              questionEn: 'What is the key difference between thrifting and upcycling?',
              questionAr: 'ما هو الفرق الجوهري بين شراء المستعمل (thrifting) وإعادة التدوير الإبداعي (upcycling)؟',
              type: 'mcq',
              options: [
                'Thrifting is buying used items as they are, while upcycling transforms items into something new and functional',
                'Thrifting is more expensive than buying brand-new items',
                'Upcycling involves throwing items into landfills directly',
                'There is no difference between them'
              ],
              correctAnswer: 0,
              explanation: 'Thrifting reuses items in their current form, whereas upcycling modifies and transforms an item into a new, often more beautiful product.'
            }
          ]
        }
      },
      {
        id: 'u2-l8',
        unitId: 2,
        lessonNumber: 8,
        type: 'Grammar',
        titleEn: '1st If Conditional and Modal Verbs',
        titleAr: 'الحالة الشرطية الأولى والأفعال الناقصة',
        pageNumber: 42,
        newVocabulary: [],
        grammarFocus: 'If + present simple, modal verb (will, can, may, should)',
        objectiveEn: 'Construct grammatically accurate conditional sentences and select appropriate modal verbs according to meaning.',
        objectiveAr: 'بناء جمل شرطية من النوع الأول واختيار الفعل الناقص المناسب (will للتأكيد، can للقدرة، may للاحتمال، should للنصيحة).',
        content: {
          summaryEn: 'Formulas and modal verb purposes: will (certainty), can (ability), may (probability), should (advice).',
          summaryAr: 'شرح صيغة if الشرطية الأولى ومعاني الأفعال الناقصة وتجنب الأخطاء الشائعة.',
          tasks: [
            {
              id: 'u2-l8-t1',
              questionEn: 'If we recycle our plastic bottles, we __________ certainly reduce waste.',
              questionAr: 'اختر الفعل الناقص الذي يعبر عن نتيجة مؤكدة (certain outcome):',
              type: 'mcq',
              options: ['will', 'may', 'should', 'might'],
              correctAnswer: 0,
              explanation: '"will" expresses a definite, certain outcome.'
            },
            {
              id: 'u2-l8-t2',
              questionEn: 'If you have old newspapers, you __________ use them to wrap gifts. I think it is a good idea.',
              questionAr: 'اختر الفعل الناقص الذي يعبر عن النصيحة (advice):',
              type: 'mcq',
              options: ['should', 'will', 'must', 'can'],
              correctAnswer: 0,
              explanation: '"should" is used to offer recommendations and advice.'
            }
          ]
        }
      },
      {
        id: 'u2-l9',
        unitId: 2,
        lessonNumber: 9,
        type: 'Listening',
        titleEn: 'Rethinking Waste Worldwide',
        titleAr: 'إعادة التفكير في إدارة النفايات عالمياً',
        pageNumber: 43,
        newVocabulary: ['bury', 'incineration', 'decompose', 'composting', 'densely'],
        objectiveEn: 'Analyze a documentary about waste management systems across five countries: USA, Japan, Germany, Singapore, Canada.',
        objectiveAr: 'الاستماع إلى فيلم وثائقي عن نظم معالجة النفايات في 5 دول: أمريكا، اليابان، ألمانيا، سنغافورة، كندا.',
        content: {
          summaryEn: 'Documentary covers: Waste Sorting (USA), Composting & Incineration (Singapore, Germany, Japan) and converting waste to electricity.',
          summaryAr: 'نظم فرز النفايات، التسميد العضوي، ومحطات تحويل النفايات إلى طاقة كهربائية.',
          listeningScript: `Speaker 1 (USA): In the United States, waste sorting at the household level is fundamental. Curbside recycling bins allow municipalities to collect plastic, aluminium, and paper separately.
Speaker 2 (Germany): In Germany, composting organic food scraps has become a nationwide discipline. Organic matter is allowed to decompose into nutrient-rich humus instead of sitting in landfills.
Speaker 3 (Singapore): Singapore is a densely populated island with limited land to bury garbage. Therefore, waste-to-energy incineration systems are used. Rubbish is incinerated at extreme temperatures to generate steam and electricity, while ash is safely contained.
Speaker 4 (Japan): In Japan, sorting regulations are strict and detailed. Families divide waste into over ten categories, ensuring optimal recycling and thermal energy recovery.`,
          tasks: [
            {
              id: 'u2-l9-t1',
              questionEn: 'Why does Singapore rely heavily on waste-to-energy incineration instead of landfills?',
              questionAr: 'لماذا تعتمد سنغافورة بشكل كبير على حرق النفايات لتوليد الطاقة بدلاً من طمرها؟',
              type: 'mcq',
              options: [
                'Because it is a densely populated island with very limited land to bury garbage',
                'Because incineration is completely free',
                'Because citizens refuse to sort rubbish',
                'Because it rains every day'
              ],
              correctAnswer: 0,
              explanation: 'Singapore’s limited geographic landmass makes landfilling unsustainable, necessitating high-tech incineration.'
            }
          ]
        }
      },
      {
        id: 'u2-l10',
        unitId: 2,
        lessonNumber: 10,
        type: 'Speaking',
        titleEn: 'Throw-away Culture',
        titleAr: 'ثقافة الاستهلاك السريع والرمي',
        pageNumber: 44,
        newVocabulary: ['brand-new', 'outlive', 'seldom', 'manufacture', 'strict'],
        objectiveEn: 'Examine product life cycles (t-shirt, mobile phone, paper cup) and deliver a 1-minute documentary-style speech.',
        objectiveAr: 'دراسة دورة حياة المنتجات وإلقاء خطاب وثائقي موجز لنقد ثقافة الاستهلاك المفرط واقتراح الحلول.',
        content: {
          summaryEn: 'Examining electronic waste that outlives human generations, fast fashion cotton-polyester blends, and single-use paper cups.',
          summaryAr: 'مناقشة النفايات الإلكترونية التي تعمر أطول من البشر، والأزياء السريعة، وأكواب الورق ذات الاستخدام الواحد.',
          tasks: [
            {
              id: 'u2-l10-t1',
              questionEn: 'Which common problem is associated with discarded mobile phones and electronics?',
              questionAr: 'ما هي المشكلة البيئية الشائعة المرتبطة بالأجهزة الإلكترونية والهواتف المرمية؟',
              type: 'mcq',
              options: [
                'Electronic waste contains rare minerals and toxic plastics that outlive humans in landfills',
                'They decompose into harmless compost within a week',
                'They dissolve in water easily'
              ],
              correctAnswer: 0,
              explanation: 'Textbook table: "A mobile phone: Rare earth minerals, electronic waste outlives humans."'
            }
          ]
        }
      },
      {
        id: 'u2-l11',
        unitId: 2,
        lessonNumber: 11,
        type: 'Writing',
        titleEn: 'Habits for a Better World',
        titleAr: 'عادات من أجل عالم أفضل',
        pageNumber: 45,
        newVocabulary: [],
        objectiveEn: 'Write an expository essay organizing eco-friendly habits inside the home and outside the home.',
        objectiveAr: 'كتابة مقال متكامل ينظم العادات الصديقة للبيئة داخل المنزل (ترشيد الطاقة) وخارجه (التسوق المسؤول).',
        content: {
          summaryEn: 'Linking words practice: On the one hand, On the other hand, However, For example, As a result.',
          summaryAr: 'استخدام أدوات الربط المنطقي والمقارنة في صياغة مقال الاستدامة.',
          tasks: [
            {
              id: 'u2-l11-t1',
              questionEn: 'Match the eco-friendly habit: "Choosing products with minimal or recyclable packaging" is an example of:',
              questionAr: 'طابق العادة البيئية: اختيار منتجات ذات تغليف قليل أو قابل للتدوير مثال على:',
              type: 'mcq',
              options: ['Responsible Shopping', 'Conserving Energy', 'Thrifting', 'Upcycling'],
              correctAnswer: 0,
              explanation: 'Selecting products with minimal packaging is categorized under Responsible Shopping.'
            }
          ]
        }
      }
    ]
  },

  // ================= UNIT 3 =================
  {
    id: 3,
    moduleNameEn: 'Module Two: Cultural Foundation & Civic Duty',
    moduleNameAr: 'الوحدة النمطية الثانية: الأسس الثقافية والواجب المدني',
    titleEn: 'Unit Three: Exploring Heritage',
    titleAr: 'الوحدة الثالثة: استكشاف التراث',
    descriptionEn: 'Celebrate Kuwait’s living heritage, iconic stamps, cultural ambassadors (Mohammad Al Sharekh & Hamza Al Khayat), historic GCC forts, and the art of Sadu weaving.',
    descriptionAr: 'الاحتفاء بتراث الكويت الحي، الطوابع التاريخية، رواد الثقافة (محمد الشارخ وحمزة الخياط)، القلاع التاريخية، وفن السدو.',
    themeColor: 'amber',
    educationalValues: [
      'Appreciation of traditions',
      'Respect for role models',
      'Pride in Kuwaiti identity',
      'Cultural awareness',
      'Respect for history',
      'Responsibility towards society',
      'Preserving culture',
      'Leadership'
    ],
    centurySkills: [
      'Communication',
      'Collaboration',
      'Critical thinking',
      'Creativity',
      'Cultural literacy',
      'Digital literacy',
      'Citizenship'
    ],
    lessons: [
      {
        id: 'u3-l1',
        unitId: 3,
        lessonNumber: 1,
        type: 'Opener',
        titleEn: 'Stamps That Tell Our Story',
        titleAr: 'طوابع تروي قصتنا الوطنية',
        pageNumber: 49,
        newVocabulary: ['evidence', 'artefact', 'stand for', 'pass down', 'illustrate'],
        objectiveEn: 'Identify cultural values depicted in Kuwaiti stamps and complete vocabulary context tasks.',
        objectiveAr: 'استكشاف القيم التراثية المصورة في الطوابع الكويتية واستخدام مفردات الدرس.',
        content: {
          summaryEn: 'Historic stamps illustrate pearl diving, falconry, dhow shipbuilding, and Failaka Bronze Age artefacts.',
          summaryAr: 'طوابع تاريخية توثق الغوص، الصيد بالصقور، صناعة السفن، وآثار جزيرة فيلكا.',
          tasks: [
            {
              id: 'u3-l1-t1',
              questionEn: 'The falcon in Kuwaiti commemorative stamps __________ strength, dignity, and national pride.',
              questionAr: 'طائر الصقر في الطوابع الكويتية يرمز إلى القوة والفخر:',
              type: 'mcq',
              options: ['stands for', 'passes down', 'illustrates', 'disposes of'],
              correctAnswer: 0,
              explanation: '"stands for" means represents or symbolises.'
            }
          ]
        }
      },
      {
        id: 'u3-l2',
        unitId: 3,
        lessonNumber: 2,
        type: 'Reading',
        titleEn: 'Cultural Ambassadors',
        titleAr: 'سفراء الثقافة (محمد الشارخ وحمزة الخياط)',
        pageNumber: 50,
        newVocabulary: ['creator', 'leading', 'automatic', 'translation', 'precisely', 'devote to', 'director', 'creativity', 'detailed', 'sadly'],
        objectiveEn: 'Distinguish facts from opinions in biographical texts celebrating two distinguished Kuwaiti pioneers.',
        objectiveAr: 'التمييز بين الحقائق والآراء في السير الذاتية لرائدين كويتيين: محمد الشارخ وأ. حمزة الخياط.',
        content: {
          headline: 'Honouring Kuwait’s Visionaries in Technology and Education',
          summaryEn: 'Profiles of Mohammad Al Sharekh (founder of Sakhr, pioneer of Arabic computing) and Hamza Al Khayat (master educator of Arabic language and spelling).',
          summaryAr: 'سيرة محمد الشارخ مؤسس صخر وأول من أدخل العربية للحاسوب، والمعلم حمزة الخياط وموسوعة الإملاء ومؤلفاته.',
          readingText: `Profile 1: A Leader in Arabic Computing
Mohammad Al Sharekh was a Kuwaiti businessman and creator in the field of Arabic computing. He was born in 1942 and helped introduce the Arabic language to computers for the first time in history.

In 1982, he founded Sakhr Company, which became a leading company in developing Arabic computer programmes. Through this company, he helped create Arabic keyboards, automatic translation programmes, and tools for reading and writing Arabic on computers. He also developed more than ninety educational and cultural programmes that supported learning and digital literacy. Some of his projects included a free online Arabic dictionary and a digital collection of Arabic literature. These projects show precisely how he supported the language and helped people use it in technology.

Al Sharekh received several local and international awards for his work. He passed away in 2024, but his work continues to influence technology and Arabic language learning today.

Profile 2: A Champion of Arabic Education
Hamza Al Khayat was a famous Kuwaiti language expert and teacher who devoted more than forty years to improving the teaching of Arabic. He was the director of the Linguistic Creativity Centre and became famous for his creative way of teaching spelling. He believed that traditional methods sometimes made students feel nervous, so he worked to make learning more enjoyable and motivating.

One of his most important achievements was his spelling encyclopaedia for primary school students. The book used fun activities and exercises to help students improve their spelling, reading, and writing skills. It also helped make Arabic more interesting and easier to understand for young students. In addition, he wrote Learn the Hamza with Hamza, a detailed book based on 15 years of research.

Al Khayat showed great commitment to education during his life. Despite health problems, he continued working hard and shared thousands of free copies of his books to support students in Kuwait and other countries. He sadly passed away in 2024, leaving a lasting impact on Arabic language teaching and learning. A primary school was named after him to honour his contributions to education.`,
          tasks: [
            {
              id: 'u3-l2-t1',
              questionEn: 'Which statement is a FACT rather than an opinion?',
              questionAr: 'أي من العبارات التالية تمثل حقيقة (Fact) وليست رأياً (Opinion)؟',
              type: 'mcq',
              options: [
                'Mohammad Al Sharekh founded Sakhr Company in 1982.',
                'Mohammad Al Sharekh’s work was the most fascinating project in history.',
                'Hamza Al Khayat was the most enjoyable teacher in the world.'
              ],
              correctAnswer: 0,
              explanation: 'Founding Sakhr in 1982 is a verifiable historical fact.'
            },
            {
              id: 'u3-l2-t2',
              questionEn: 'What did Hamza Al Khayat author based on 15 years of meticulous research?',
              questionAr: 'ما هو الكتاب الذي ألفه الأستاذ حمزة الخياط بعد 15 عاماً من البحث؟',
              type: 'mcq',
              options: [
                'Learn the Hamza with Hamza',
                'Digital Sadu Designer',
                'The Shagaya Guidebook',
                'The Ocean of Kuwait'
              ],
              correctAnswer: 0,
              explanation: 'The text states he wrote "Learn the Hamza with Hamza, a detailed book based on 15 years of research."'
            }
          ]
        }
      },
      {
        id: 'u3-l3',
        unitId: 3,
        lessonNumber: 3,
        type: 'Grammar',
        titleEn: 'Non-Defining Relative Pronouns and Clauses',
        titleAr: 'ضمائر وجمل الوصل غير المحددة',
        pageNumber: 52,
        newVocabulary: [],
        grammarFocus: 'who, which, whose, where, when (commas required, never use "that")',
        objectiveEn: 'Use non-defining relative pronouns to provide extra descriptive detail surrounded by commas.',
        objectiveAr: 'استخدام ضمائر الوصل (who, which, whose, where, when) وإحاطتها بفواصل دون استخدام that.',
        content: {
          summaryEn: 'The "Bread and Filling" metaphor from page 52 and Grammar File page 89.',
          summaryAr: 'قاعدة الساندويتش: الشطيرة والحشوة، وأمثلة المعالم والشخصيات الكويتية.',
          tasks: [
            {
              id: 'u3-l3-t1',
              questionEn: 'Choose the correct sentence following the non-defining relative clause rule:',
              questionAr: 'اختر الجملة الصحيحة لغوياً وقواعدياً وفق قاعدة جمل الوصل غير المحددة:',
              type: 'mcq',
              options: [
                'The Red Fort, where stories of the past are kept alive, is a symbol of national pride.',
                'The Red Fort that stories of the past are kept alive is a symbol of national pride.',
                'The Red Fort, which stories of the past are kept alive is a symbol of national pride.',
                'The Red Fort where stories of the past are kept alive, is a symbol.'
              ],
              correctAnswer: 0,
              explanation: 'Places take "where" and non-defining clauses must be enclosed in commas on both sides.'
            }
          ]
        }
      },
      {
        id: 'u3-l4',
        unitId: 3,
        lessonNumber: 4,
        type: 'Listening',
        titleEn: 'Stories Beyond The Walls',
        titleAr: 'قصص ما وراء الأسوار (القلاع الخليجية)',
        pageNumber: 53,
        newVocabulary: ['narrow', 'passage', 'surround', 'expand', 'watchtower'],
        objectiveEn: 'Listen to a podcast about GCC historic forts (The Bahla Fort, The Zubarah Fort, The Red Fort) and complete factual comparison tables.',
        objectiveAr: 'الاستماع لبودكاست عن قلاع الخليج التاريخية (بهلاء، الزبارة، القصر الأحمر بالجهراء).',
        content: {
          summaryEn: 'Bahla Fort in Oman (UNESCO World Heritage Site with narrow passages), Zubarah Fort in Qatar, and Kuwait’s iconic Red Fort in Al-Jahra.',
          summaryAr: 'قلعة بهلاء في عمان والمدرجة في اليونسكو، قلعة الزبارة في قطر، والقصر الأحمر في الجهراء بدولة الكويت.',
          tasks: [
            {
              id: 'u3-l4-t1',
              questionEn: 'Which of the historic forts discussed in the podcast is an officially recognized UNESCO World Heritage Site?',
              questionAr: 'أي من القلاع التاريخية المذكورة في البودكاست معتمدة رسمياً كموقع تراث عالمي في اليونسكو؟',
              type: 'mcq',
              options: ['The Bahla Fort in Oman', 'The Red Fort in Kuwait', 'The Souq Gate'],
              correctAnswer: 0,
              explanation: 'Textbook table page 53 confirms Bahla Fort (Oman) is a UNESCO World Heritage Site.'
            }
          ]
        }
      },
      {
        id: 'u3-l5',
        unitId: 3,
        lessonNumber: 5,
        type: 'Speaking',
        titleEn: 'Big Dreamers',
        titleAr: 'أصحاب الأحلام الكبرى',
        pageNumber: 54,
        newVocabulary: ['mechanical', 'award', 'conference', 'insightful', 'document'],
        objectiveEn: 'Present a 1-minute profile mapping out future accomplishments and advice for younger learners.',
        objectiveAr: 'تقديم ملف إنجاز مستقبلي وتدريب على الحديث لمدة دقيقة عن الطموحات والخدمة المجتمعية.',
        content: {
          summaryEn: 'Profiles of aspiring Kuwaitis: Sara (aerospace mechanical engineer), Nasser (humanitarian organizer), and Rashid (cultural filmmaker).',
          summaryAr: 'نماذج ملهمة: سارة (مهندسة فضاء وتكنولوجيا)، ناصر (قائد إنساني)، وراشد (صانع محتوى وثائقي).',
          tasks: [
            {
              id: 'u3-l5-t1',
              questionEn: 'What field does Sara specialize in, where she represented her nation at an international conference?',
              questionAr: 'ما هو التخصص الذي أبدعت فيه سارة ومثلت بلدها في مؤتمر دولي؟',
              type: 'mcq',
              options: [
                'Mechanical engineering and space science',
                'Fashion marketing and culinary arts',
                'Commercial banking and finance'
              ],
              correctAnswer: 0,
              explanation: 'Sara is an aerospace mechanical engineer who received an international award in space science.'
            }
          ]
        }
      },
      {
        id: 'u3-l6',
        unitId: 3,
        lessonNumber: 6,
        type: 'Writing',
        titleEn: 'Honour, Inspire, Remember',
        titleAr: 'تكريم الرواد وإلهام الأجيال',
        pageNumber: 55,
        newVocabulary: [],
        objectiveEn: 'Write a paragraph suggesting meaningful ways to honour distinguished Kuwaiti figures and preserve their legacy.',
        objectiveAr: 'كتابة فقرة متناسقة تقترح طرقاً لتكريم الشخصيات الكويتية المتميزة وتخليد ذكراهم.',
        content: {
          summaryEn: 'Techniques: Naming schools and public facilities after them, creating awards, building museum exhibitions, and hosting national remembrance events.',
          summaryAr: 'وسائل التكريم: إطلاق أسمائهم على المدارس والمباني، تخصيص جوائز باسمهم، وإقامة المعارض المتحفية.',
          writingPrompt: {
            topic: 'Suggest different ways to honour distinguished people in Kuwait with concrete examples.',
            requirements: ['At least 8 sentences', 'Include linkers: One common way, Another way, In addition, Therefore'],
            linkers: ['One common way', 'Another way', 'In addition', 'For example', 'Therefore'],
            modelParagraph: 'Distinguished people can be honoured in many meaningful ways in our country. One common way is by naming schools or buildings after them. This helps people remember their achievements and contributions. Another way is to create awards or prizes in their name to encourage others to follow their example. In addition, museums and exhibitions can display their work and tell their stories. Communities can also organise events or celebrations to recognise their efforts. For example, national days or special events can highlight their impact on society. Therefore, honouring distinguished people is important because it inspires future generations to achieve success and serve their country.'
          },
          tasks: [
            {
              id: 'u3-l6-t1',
              questionEn: 'Why is naming schools and public buildings after pioneers an effective tribute?',
              questionAr: 'لماذا يعتبر إطلاق أسماء الرواد على المدارس والمباني العامة وسيلة تكريم فعالة؟',
              type: 'mcq',
              options: [
                'It helps citizens remember their lasting achievements and motivates students to follow their footsteps',
                'It is cheaper than holding ceremonies',
                'It is required by municipal law'
              ],
              correctAnswer: 0,
              explanation: 'The model paragraph explains it keeps their achievements alive and inspires future generations.'
            }
          ]
        }
      },
      {
        id: 'u3-l7',
        unitId: 3,
        lessonNumber: 7,
        type: 'Reading',
        titleEn: 'Can Technology Save Heritage?',
        titleAr: 'هل يمكن للتكنولوجيا أن تحمي التراث؟',
        pageNumber: 56,
        newVocabulary: ['continuous', 'alive', 'ceremony', 'identify', 'patiently', 'view', 'educate', 'overseas', 'publish', 'root'],
        objectiveEn: 'Examine how Japan and other nations combine ancient traditions with cutting-edge technology to maintain cultural identity.',
        objectiveAr: 'دراسة كيفية دمج اليابان ودول العالم للتقنيات الحديثة مع الحفاظ على التقاليد والجذور الثقافية.',
        content: {
          headline: 'Modern Innovation in Service of Living Traditions',
          summaryEn: 'How robotics, apps, and digital platforms can preserve cultural arts like calligraphy, tea ceremonies, and respectful customs.',
          summaryAr: 'كيف تساهم الروبوتات المهذبة والتطبيقات والجولات الرقمية في إبقاء التراث حياً للأجيال القادمة والجمهور العالمي.',
          readingText: `How can a country stay modern without losing its heritage? In Japan, old traditions and modern technology live together. Japan is famous for its advanced technology, but it also protects its values and traditions. This is why Japan is a strong example of a continuous culture, where essential traditions remain alive.

Firstly, preserving heritage is important because it helps people understand who they are and connect with their history and values. In Japan, cultural practices such as the tea ceremony and respect for elders are still important today. They teach people to be calm, respectful, and disciplined. In addition, these traditions help people identify with their culture and understand why the past still has an important place in modern life. Secondly, preserving heritage keeps traditional skills and crafts alive. For example, arts such as kimono-making and calligraphy are passed down through families. Finally, traditional festivals bring people together because they create a feeling of connection.

However, modern life is changing quickly, especially for young people. Technology now plays a major role in daily life. Instead of ignoring this change, Japan uses technology to support its traditions and values. For example, engineers design robots that follow social rules. These robots keep a polite distance, wait patiently, and do not interrupt people. Many people view this as a respectful way to protect traditional culture. In addition, schools educate students about traditional arts and customs. Websites and apps also help people overseas view and learn about Japanese culture. Museums and cultural organisations publish videos and online tours, so people can explore Japan’s heritage.

In conclusion, preserving heritage does not mean stopping progress. By respecting its cultural roots and using modern tools, Japan keeps its culture alive for young people in the future.`,
          tasks: [
            {
              id: 'u3-l7-t1',
              questionEn: 'How do Japanese robotic engineers integrate traditional cultural values into technology?',
              questionAr: 'كيف يدمج مهندسو الروبوتات في اليابان القيم الثقافية والاجتماعية في أجهزتهم؟',
              type: 'mcq',
              options: [
                'By programming robots to follow social etiquette, maintain polite distance, and wait patiently',
                'By making robots replace all human teachers',
                'By dressing robots in expensive business suits',
                'By using robots only for manufacturing cars'
              ],
              correctAnswer: 0,
              explanation: 'Textbook page 56: "engineers design robots that follow social rules... keep polite distance, wait patiently, and do not interrupt."'
            }
          ]
        }
      },
      {
        id: 'u3-l8',
        unitId: 3,
        lessonNumber: 8,
        type: 'Grammar',
        titleEn: 'Past Simple and Past Continuous',
        titleAr: 'الماضي البسيط والماضي المستمر',
        pageNumber: 58,
        newVocabulary: [],
        grammarFocus: 'when (interrupted short action) vs while/as (parallel continuous actions)',
        objectiveEn: 'Differentiate between past simple and continuous forms and produce coherent narrative sentences.',
        objectiveAr: 'التفريق بين الماضي البسيط والمستمر والربط باستخدام when وwhile وas في سياق سردي.',
        content: {
          summaryEn: 'Rules and tour guide story about Ali Al-Shamlan Mosque (built 1920 in Al-Mirqab) from page 58 and Grammar File page 90.',
          summaryAr: 'شرح قاعدة الماضي البسيط والمستمر وقصة مسجد علي الشملان بالمرقاب الذي شيد عام 1920.',
          tasks: [
            {
              id: 'u3-l8-t1',
              questionEn: 'While the tourist __________ through the Al-Mirqab area, he saw an unusual mosque.',
              questionAr: 'اختر الفعل المناسب: While the tourist ... through Al-Mirqab',
              type: 'mcq',
              options: ['was walking', 'walked', 'walks', 'is walking'],
              correctAnswer: 0,
              explanation: 'After "While" describing an action in progress in the past, use past continuous: "was walking".'
            },
            {
              id: 'u3-l8-t2',
              questionEn: 'When the pearl divers returned, their families __________ on the shore.',
              questionAr: 'اختر صيغة الفعل المناسبة: When the pearl divers returned, their families ...',
              type: 'mcq',
              options: ['were waiting', 'waited', 'wait', 'are waiting'],
              correctAnswer: 0,
              explanation: 'The families were in the middle of waiting (ongoing) when the moment of return happened.'
            }
          ]
        }
      },
      {
        id: 'u3-l9',
        unitId: 3,
        lessonNumber: 9,
        type: 'Listening',
        titleEn: 'Continuous Culture: Sadu Weaving',
        titleAr: 'ثقافة متواصلة: فن حياكة السدو',
        pageNumber: 59,
        newVocabulary: ['identity', 'dye', 'decorative', 'classic', 'bridge'],
        objectiveEn: 'Extract main ideas and details about Bedouin Sadu weaving patterns and the role of the Sadu Society established in 1979.',
        objectiveAr: 'التعرف على نقوش السدو التراثية (النجوم، الماء، المقص، دروب الحية) وتأسيس جمعية السدو عام 1979.',
        content: {
          summaryEn: 'Sadu patterns (Stars, Water, Scissors, Snake paths), natural wool dyeing, and UNESCO recognition of Sadu weaving as intangible cultural heritage.',
          summaryAr: 'أنماط السدو الهندسية وصبغ الصوف ودور جمعية السدو الكويتية في صون هذا التراث العالمي.',
          tasks: [
            {
              id: 'u3-l9-t1',
              questionEn: 'In what year was the Sadu Society established in Kuwait to protect this ancient textile art?',
              questionAr: 'في أي عام تأسست جمعية السدو في دولة الكويت لحماية هذا الفن العريق؟',
              type: 'mcq',
              options: ['1979', '1961', '1990', '1982'],
              correctAnswer: 0,
              explanation: 'Textbook page 59 confirms: "The Sadu Society was established in 1979 in Kuwait."'
            }
          ]
        }
      },
      {
        id: 'u3-l10',
        unitId: 3,
        lessonNumber: 10,
        type: 'Speaking',
        titleEn: 'Hidden Gems',
        titleAr: 'جواهر خفية (الحديقة السرية في السالمية)',
        pageNumber: 60,
        newVocabulary: ['tuck away', 'amazingly', 'customise', 'walker', 'hidden'],
        objectiveEn: 'Discuss community initiatives like "The Secret Garden" and brainstorm apps promoting Kuwaiti cultural values.',
        objectiveAr: 'مناقشة المبادرات المجتمعية مثل الحديقة السرية في السالمية وجدار اللطف، واقتراح تطبيقات ذكية لنشر القيم.',
        content: {
          summaryEn: 'Community garden in Salmiya with a "Wall of Kindness", and app concepts: Shukran Wall, Kindness Tracker, Digital Sadu Designer, InnoSpark.',
          summaryAr: 'حديقة خفية بالسالمية وجدار العطاء، وأفكار تطبيقات تعزز الترابط المجتمعي مثل Digital Sadu Designer وShukran Wall.',
          tasks: [
            {
              id: 'u3-l10-t1',
              questionEn: 'Which app concept allows users to create modern digital designs inspired by traditional Bedouin weaving?',
              questionAr: 'أي فكرة تطبيق تتيح للمستخدمين ابتكار تصاميم رقمية مستوحاة من التراث النسيجي؟',
              type: 'mcq',
              options: ['Digital Sadu Designer', 'Kindness Tracker', 'WiseUp', 'Shukran Wall'],
              correctAnswer: 0,
              explanation: 'Matching exercise page 60: Digital Sadu Designer allows users to create modern patterns inspired by tradition.'
            }
          ]
        }
      },
      {
        id: 'u3-l11',
        unitId: 3,
        lessonNumber: 11,
        type: 'Writing',
        titleEn: 'Preserving Heritage',
        titleAr: 'صون التراث وحمايته',
        pageNumber: 61,
        newVocabulary: [],
        objectiveEn: 'Recognise hook strategies (Imaginative, Personal connection, Quote-style, Question, Statement) and write a RAFT report.',
        objectiveAr: 'التعرف على أنواع جمل جذب القارئ (Hooks) وكتابة تقرير أو مقال توعوي بأسلوب RAFT.',
        content: {
          summaryEn: 'Hook types: 1) Question ("Have you ever thought...?"), 2) Statement ("Traditional crafts are still important"), 3) Quote-style ("In every delay, there is a blessing"), 4) Imaginative ("Imagine a world without traditions").',
          summaryAr: 'استراتيجيات خطاف المقال، وأسلوب RAFT (الدور، الجمهور، الشكل، الموضوع) لكتابة تقرير صون التراث.',
          tasks: [
            {
              id: 'u3-l11-t1',
              questionEn: 'What type of hook is: "“In every delay, there is a blessing”"?',
              questionAr: 'ما نوع جملة الجذب (Hook) في: "In every delay, there is a blessing"؟',
              type: 'mcq',
              options: ['Quote-style Hook', 'Question Hook', 'Imaginative Hook', 'Statement Hook'],
              correctAnswer: 0,
              explanation: 'A traditional proverb or quoted saying is categorized as a Quote-style hook.'
            }
          ]
        }
      }
    ]
  },

  // ================= UNIT 4 =================
  {
    id: 4,
    moduleNameEn: 'Module Two: Cultural Foundation & Civic Duty',
    moduleNameAr: 'الوحدة النمطية الثانية: الأسس الثقافية والواجب المدني',
    titleEn: 'Unit Four: Citizenship',
    titleAr: 'الوحدة الرابعة: المواطنة الفاعلة',
    descriptionEn: 'Discover the foundations of Kuwaiti citizenship, the historical timeline of national growth, HH the Amir’s address, the social contract, and national duties.',
    descriptionAr: 'استكشاف معالم المواطنة الصالحة، خط الزمن التاريخي لنهضة الكويت، خطاب صاحب السمو الأمير، العقد الاجتماعي والواجبات الوطنية.',
    themeColor: 'blue',
    educationalValues: [
      'Justice',
      'Fairness',
      'Equality',
      'Freedom',
      'Order',
      'Respecting laws',
      'Loyalty to one’s country'
    ],
    centurySkills: [
      'Critical thinking',
      'Problem-solving',
      'Collaboration',
      'Communication',
      'Consensus-building',
      'Digital tooling',
      'Citizenship'
    ],
    lessons: [
      {
        id: 'u4-l1',
        unitId: 4,
        lessonNumber: 1,
        type: 'Opener',
        titleEn: 'What Makes a Good Citizen?',
        titleAr: 'ما الذي يجعل المواطن صالحاً؟',
        pageNumber: 65,
        newVocabulary: ['well-known', 'tie', 'site', 'continuously', 'citizenship'],
        objectiveEn: 'Discuss the qualities of active citizenship and describe Kuwait’s historical landmarks.',
        objectiveAr: 'مناقشة سمات المواطنة الصالحة واستخدام المفردات لوصف معالم الكويت التاريخية.',
        content: {
          summaryEn: 'Symbols of Kuwait: Souq Al-Mubarakiya, dhow maritime legacy, and Failaka Island settlement dating continuously back to 2000 BC.',
          summaryAr: 'سوق المباركية، إرث سفن البوم، ومستوطنات جزيرة فيلكا التي تعود إلى 2000 قبل الميلاد.',
          tasks: [
            {
              id: 'u4-l1-t1',
              questionEn: 'Archaeological excavations on Failaka Island prove that humans inhabited the site continuously as far back as:',
              questionAr: 'أثبتت التنقيبات في جزيرة فيلكا استقرار السكان في الموقع باستمرار منذ:',
              type: 'mcq',
              options: ['2000 BC', '1961 AD', '1899 AD', '1930 AD'],
              correctAnswer: 0,
              explanation: 'Textbook "Did You Know?" box confirms evidence of continuous habitation as far back as 2000 BC.'
            }
          ]
        }
      },
      {
        id: 'u4-l2',
        unitId: 4,
        lessonNumber: 2,
        type: 'Reading',
        titleEn: 'Timeless Growth',
        titleAr: 'نمو عبر الزمن (تاريخ الكويت المجيد)',
        pageNumber: 66,
        newVocabulary: ['transformation', 'collection', 'culturally', 'hub', 'nation', 'mark', 'sustain', 'rapidly', 'new-found', 'capacity'],
        objectiveEn: 'Trace Kuwait’s national historical evolution from 17th century Al-Kut, through 18th century trade, 1911 education, 1930s oil, to 1961 independence and the 1962 Constitution.',
        objectiveAr: 'تتبع مراحل نهضة الكويت: حصن الكوت بالقرن 17، التجارة بالقرن 18، مدرسة المباركية 1911، النفط بالثلاثينات، والاستقلال 1961 ودستور 1962.',
        content: {
          headline: 'Our Ancestors’ Ocean, Our Children’s Sky: Timeless Growth',
          summaryEn: 'A five-stage historical timeline detailing Kuwait’s growth into a constitutional state, humanitarian hub, and international peacemaker.',
          summaryAr: 'جدول زمني لخمس حقب مفصلية في تاريخ الكويت وتحولها إلى دولة دستورية ووسيط سلام إقليمي ودولي.',
          readingText: `The 17th Century:
Kuwait, which is located on the northern edge of the Arabian Gulf, emerged as a centre for global trade. The name itself is derived from ‘Al-Kut’, meaning a small fort built near the sea. In ancient times, different cultures gathered in this area to exchange not only goods but also ideas. Over the centuries, Kuwait underwent a remarkable transformation, evolving from a collection of small coastal villages into a culturally diverse country and a trading hub. This historical story shows the nation’s strength and its growth.

The 18th Century:
The 18th century marked a major turning point as the State of Kuwait evolved from a simple community into a well-known trading port. Its geographical location was useful in connecting major sea paths between the East and the West. As merchants traded items, the leadership of the Al Sabah family provided stability for growth. The family continues to govern the nation today with a vision of progress and national security.

The 19th Century:
Throughout the 19th century, Kuwait’s economy succeeded through sea skills, which are also known as maritime skills. The pearl-diving and shipbuilding industries sustained growth, rapidly becoming basic parts of the country. The year 1899 represents a turning point in Kuwait’s history. At the time, Sheikh Mubarak Al-Sabah, also known as ‘Mubarak the Great’, focused on state-building until 1911, when he established Al-Mubarakiya School. This marked the beginning of formal education in Kuwait.

The 1930s:
The 1930s represented a significant milestone with the discovery of oil, which completely changed the nation's path. Previously, it had relied heavily on maritime activities, but a massive transition soon began. This new-found wealth sped up modernisation. The government began giving funds to national foundations, resulting in the building of modern schools, advanced hospitals, and transportation networks that transformed Kuwait into a modern state.

1961 – Current:
Kuwait gained full independence in 1961, joining the global community as a free state. Afterwards, the year 1962 was a defining moment when Sheikh Abdullah Al-Salem signed the Constitution, a document that contains the written law of Kuwait. Today, the nation remains a key peacemaker in regional affairs. The state of Kuwait always carries a duty to maintain international peace, acting in its capacity as a regional mediator. Kuwait looks towards a bright future, working continuously in every field to grow as a modern nation while always keeping its traditions alive.`,
          tasks: [
            {
              id: 'u4-l2-t1',
              questionEn: 'What was the original etymological meaning of the name "Al-Kut"?',
              questionAr: 'ما هو المعنى اللغوي الأصلي لاسم "الكوت"؟',
              type: 'mcq',
              options: [
                'A small fort built near the sea',
                'A big sailing vessel',
                'A pearl diving oyster bed',
                'A freshwater desert well'
              ],
              correctAnswer: 0,
              explanation: 'Textbook timeline: "The name itself is derived from ‘Al-Kut’, meaning a small fort built near the sea."'
            },
            {
              id: 'u4-l2-t2',
              questionEn: 'Which year marked the signing of the Kuwaiti Constitution by Sheikh Abdullah Al-Salem?',
              questionAr: 'في أي عام تم توقيع دستور دولة الكويت من قِبل الشيخ عبد الله السالم؟',
              type: 'mcq',
              options: ['1962', '1961', '1899', '1911'],
              correctAnswer: 0,
              explanation: 'Kuwait gained independence in 1961 and the Constitution was signed in 1962.'
            }
          ]
        }
      },
      {
        id: 'u4-l3',
        unitId: 4,
        lessonNumber: 3,
        type: 'Grammar',
        titleEn: 'Reported Speech',
        titleAr: 'الكلام المنقول (غير المباشر)',
        pageNumber: 68,
        newVocabulary: [],
        grammarFocus: 'Backshifting tenses (Present -> Past -> Past Perfect), pronouns, and time/place transformations',
        objectiveEn: 'Convert direct quotations into reported speech accurately applying tense, pronoun, and time changes.',
        objectiveAr: 'تحويل الجمل المباشرة إلى كلام منقول مع ضبط الأزمنة والضمائر وظروف الزمان والمكان بدقة.',
        content: {
          summaryEn: 'Rules for reported statements and environmental expert talk on the Arfaj flower from page 68 and Grammar File page 91.',
          summaryAr: 'تحويل جمل المؤتمر البيئي عن زهرة العرفج الوطنية إلى الكلام غير المباشر.',
          tasks: [
            {
              id: 'u4-l3-t1',
              questionEn: 'Direct: “The government will always work hard to protect desert plants,” said the official. ➔ Reported:',
              questionAr: 'حول إلى كلام منقول: "The government will always work hard to protect desert plants," said the official.',
              type: 'mcq',
              options: [
                'The official said that the government would always work hard to protect desert plants.',
                'The official said that the government will always work hard to protect desert plants.',
                'The official said that the government would have worked hard.',
                'The official says that the government had worked hard.'
              ],
              correctAnswer: 0,
              explanation: 'In reported speech, modal "will" backshifts to "would".'
            }
          ]
        }
      },
      {
        id: 'u4-l4',
        unitId: 4,
        lessonNumber: 4,
        type: 'Listening',
        titleEn: 'An Address to the Nation',
        titleAr: 'خطاب سامٍ إلى الأمة (سمو أمير البلاد)',
        pageNumber: 69,
        newVocabulary: ['safeguard', 'stable', 'downplay', 'leader', 'defence'],
        objectiveEn: 'Listen to the address by His Highness Sheikh Meshal Al-Ahmad Al-Jaber Al-Sabah and analyse mutual trust between leadership and citizens.',
        objectiveAr: 'الاستماع لخطاب حضرة صاحب السمو الشيخ مشعل الأحمد الجابر الصباح أمير البلاد المفدى وتحليل ركائز الثقة الوطنية.',
        content: {
          summaryEn: 'Speech highlights: The Amir speaks as a responsible leader before Allah; trust between leadership and citizens is Kuwait’s foundation; national unity is the first line of defence.',
          summaryAr: 'محاور الخطاب السامي: المسؤولية أمام الله، الثقة المتبادلة بين الحاكم والشعب، والوحدة الوطنية كخط دفاع أول.',
          tasks: [
            {
              id: 'u4-l4-t1',
              questionEn: 'In his address, His Highness the Amir emphasizes that trust between __________ and __________ is what keeps Kuwait strong.',
              questionAr: 'في خطابه السامي، أكد سمو الأمير أن الثقة بين ... و ... هي ما يحفظ قوة الكويت ومنعتها:',
              type: 'mcq',
              options: [
                'the leadership and the people',
                'the traders and the divers',
                'the teachers and the schools',
                'the tourists and the hotels'
              ],
              correctAnswer: 0,
              explanation: 'Textbook page 69: "Trust between the leadership and the people is what keeps Kuwait strong."'
            }
          ]
        }
      },
      {
        id: 'u4-l5',
        unitId: 4,
        lessonNumber: 5,
        type: 'Speaking',
        titleEn: 'The Golden Rule',
        titleAr: 'القاعدة الذهبية (معاملة الآخرين كما تحب أن يعاملوك)',
        pageNumber: 70,
        newVocabulary: ['ancestor', 'altruism', 'loyal', 'comply', 'volunteer'],
        objectiveEn: 'Discuss the Golden Rule in modern school life and deliver group speeches for campaigns like "Altruism in Action".',
        objectiveAr: 'مناقشة القاعدة الذهبية في العمل التطوعي وتقديم خطة لحملة مدرسية مثل "Adopt a Corner" أو "The Kindness Wall".',
        content: {
          summaryEn: 'Campaign options: 1) Adopt a Corner (cleanliness), 2) The Kindness Wall (encouraging messages), 3) Academic Helper (peer tutoring).',
          summaryAr: 'خيارات المبادرات التطوعية في المدرسة والتعبير عن الالتزام بالواجب الأخلاقي.',
          usefulLanguage: [
            {
              title: 'Expressing Obligation & Necessity',
              expressions: [
                'It is necessary to support fellow students who are struggling.',
                'We must comply with community guidelines to keep everyone safe.',
                'We have an obligation to volunteer our time for societal good.'
              ]
            }
          ],
          tasks: [
            {
              id: 'u4-l5-t1',
              questionEn: 'What is the fundamental definition of "The Golden Rule"?',
              questionAr: 'ما هو التعريف الأساسي لـ "القاعدة الذهبية" في التعامل الإنساني؟',
              type: 'mcq',
              options: [
                'The principle of treating others as you would like to be treated yourself',
                'The rule that whoever finds gold keeps it',
                'The requirement to win a gold medal in sports'
              ],
              correctAnswer: 0,
              explanation: 'Textbook page 70: "The Golden Rule is the principle of treating others as you would like to be treated yourself."'
            }
          ]
        }
      },
      {
        id: 'u4-l6',
        unitId: 4,
        lessonNumber: 6,
        type: 'Writing',
        titleEn: 'The Digital Diwan',
        titleAr: 'الديوان الرقمي (توثيق الذاكرة الشفوية)',
        pageNumber: 71,
        newVocabulary: [],
        objectiveEn: 'Write a paragraph explaining the significance of designing a "Digital Diwan" app to document oral Kuwaiti memories and strengthen social bonds.',
        objectiveAr: 'كتابة فقرة متماسكة لشرح أهمية تطبيق "الديوان الرقمي" في توثيق ذكريات وتراث الأجداد الكويتيين.',
        content: {
          summaryEn: 'Interview story with a father remembering childhood games ("hay al-meed"), going to the Baqala with half a KD, and bicycle adventures.',
          summaryAr: 'قصة مقابلة مع الوالد عن ألعاب الطفولة وذكريات البقالة بنصف دينار، وأهمية توثيقها رقمياً.',
          tasks: [
            {
              id: 'u4-l6-t1',
              questionEn: 'What is the meaning of the Arabic word "Diwan" in this cultural context?',
              questionAr: 'ما هو معنى كلمة "الديوان" في هذا السياق الثقافي التوثيقي؟',
              type: 'mcq',
              options: [
                'A collection of stories, memories, or poems used to document heritage',
                'A type of traditional dessert',
                'A modern high-rise office building'
              ],
              correctAnswer: 0,
              explanation: 'Textbook note: "The Diwan: An Arabic word that means a collection of stories or poems used to document heritage."'
            }
          ]
        }
      },
      {
        id: 'u4-l7',
        unitId: 4,
        lessonNumber: 7,
        type: 'Reading',
        titleEn: 'Law, Values, and Universal Citizenship',
        titleAr: 'القانون، القيم، والمواطنة العالمية',
        pageNumber: 72,
        newVocabulary: ['contract', 'equality', 'formal', 'freedom', 'impose', 'informal', 'interestingly', 'respect', 'sentence', 'universal'],
        objectiveEn: 'Understand the concept of the "social contract", differentiate formal laws from informal folkways, and explore universal road regulations.',
        objectiveAr: 'فهم مفهوم العقد الاجتماعي والتمييز بين القوانين الرسمية والأعراف غير الرسمية (folkways).',
        content: {
          headline: 'Laws and Customs as the Living Backbone of Peaceful Civilisation',
          summaryEn: 'Examines why society needs laws, how norms emerge from core values (justice, equality, freedom), and universal traffic systems like the red stop light.',
          summaryAr: 'دراسة فلسفة القانون، العقد الاجتماعي، والإشارات العالمية الموحدة لحماية الأرواح.',
          readingText: `We see the law in our daily lives, from driving a car to renting a house to even going to school. Whether we are travelling, starting a new job, or using social media, we need rules to shape our actions. However, the law is more than just a list of ‘dos and don’ts’ or a duty imposed by the government. It is something that helps us connect our beliefs with the way we live together. This relationship is often called a ‘social contract’, in which citizens agree to follow rules to make sure everyone stays safe.

In many countries, the most important values are justice, equality, and freedom. These values create ‘norms’, which are the rules on how to act. For example, because we believe life is important, we have strict laws against hurting others. We also follow informal norms called ‘folkways.’ These are simple daily habits, such as being polite to a teacher or waiting your turn in line. Furthermore, while you will not go to prison for being rude, these customs help our society stay organised and friendly. Following these habits is a key part of being a good and responsible member of society.

Interestingly, the law does not always require a judge or a police officer. A famous researcher studied people living in the South Pacific who did not have written laws. Instead, they used a system of ‘exchange’. People swapped gifts, such as food or jewellery, to build strong friendships and maintain them. If someone were selfish, they would face ‘public embarrassment’ rather than a fine. This shows that in small groups, the ‘law’ is often about our duty to others and our relationships.

Today, our world is becoming smaller. Our countries are more connected through universal laws, such as traffic rules. Because of this, we have basic signs and signals that apply to everyone, regardless of where they drive. For example, a red light means ‘stop’ in every nation, allowing people to move safely. There are also international agreements that safeguard road safety. Police officers make sure that every person is treated fairly and that rules are being enforced. Moreover, they ensure that people face the results of their actions, from paying fines to being sentenced to prison.

To conclude, as a student and young citizen, it is important to understand how law and society work together. Laws are not just cold formal instructions. Rather, they show what we value most. When we respect laws and customs, we can live in a peaceful world. This helps us grow as global citizens. By learning how rules work, we can make our countries better places for everyone to live and work.`,
          tasks: [
            {
              id: 'u4-l7-t1',
              questionEn: 'According to the article, what is a "social contract"?',
              questionAr: 'وفقاً للنص، ما هو المقصود بـ "العقد الاجتماعي" (social contract)؟',
              type: 'mcq',
              options: [
                'An agreement where citizens agree to follow shared rules to ensure everyone stays safe',
                'A commercial contract to buy a new car or house',
                'A mobile phone internet service agreement',
                'An employment contract signed at an office'
              ],
              correctAnswer: 0,
              explanation: 'Textbook page 72: "a ‘social contract’, in which citizens agree to follow rules to make sure everyone stays safe."'
            },
            {
              id: 'u4-l7-t2',
              questionEn: 'What are "folkways" as explained in the text?',
              questionAr: 'ما هي الأعراف غير الرسمية (folkways) وفقاً للمقال؟',
              type: 'mcq',
              options: [
                'Simple informal daily habits, like being polite or waiting your turn in line',
                'Written constitutional laws punishable by imprisonment',
                'Ancient sailing navigation maps',
                'Secret corporate trade agreements'
              ],
              correctAnswer: 0,
              explanation: 'Folkways are informal customs that keep society friendly and courteous.'
            }
          ]
        }
      },
      {
        id: 'u4-l8',
        unitId: 4,
        lessonNumber: 8,
        type: 'Grammar',
        titleEn: 'Future & Countable and Uncountable Nouns',
        titleAr: 'صيغ المستقبل والأسماء المعدودة وغير المعدودة',
        pageNumber: 74,
        newVocabulary: [],
        grammarFocus: 'will (prediction) vs going to (intention) vs present continuous (arrangement) & Countable/Uncountable quantifiers',
        objectiveEn: 'Choose correct future verb forms and correctly classify countable vs uncountable nouns and their quantifiers.',
        objectiveAr: 'إتقان صيغ المستقبل والتفريق بين الأسماء المعدودة وغير المعدودة واستخدام many/few وmuch/little.',
        content: {
          summaryEn: 'Grammar rules from textbook page 74 and Grammar File page 91-92.',
          summaryAr: 'شرح قواعد المستقبل الثلاث والأسماء المعدودة وغير المعدودة وشواذ الجمع.',
          tasks: [
            {
              id: 'u4-l8-t1',
              questionEn: 'Next week, our class __________ (travel) to see the Colosseum using VR headsets. The tour is booked for 10 a.m.',
              questionAr: 'اختر الصيغة المستقبلية المناسبة لترتيب محدد مسبقاً في وقت محدد:',
              type: 'mcq',
              options: ['is travelling', 'will travel', 'travels', 'travelled'],
              correctAnswer: 0,
              explanation: 'Fixed future arrangements with planned times use the present continuous: "is travelling".'
            },
            {
              id: 'u4-l8-t2',
              questionEn: 'Which of the following nouns is UNCOUNTABLE in English?',
              questionAr: 'أي من الأسماء التالية يُعد اسماً غير معدود (Uncountable) في اللغة الإنجليزية؟',
              type: 'mcq',
              options: ['information', 'store', 'bus', 'monument'],
              correctAnswer: 0,
              explanation: '"information" is an uncountable noun that cannot take -s and takes singular verb agreement.'
            }
          ]
        }
      },
      {
        id: 'u4-l9',
        unitId: 4,
        lessonNumber: 9,
        type: 'Listening',
        titleEn: 'Living Monuments',
        titleAr: 'صروح وطنية حية (بيت القرين، المكتبة الوطنية، المتحف)',
        pageNumber: 75,
        newVocabulary: ['monument', 'skyline', 'symbolise', 'rare', 'showcase'],
        objectiveEn: 'Listen to a dialogue about Kuwait’s most famous landmarks and identify historical significance.',
        objectiveAr: 'الاستماع لحوار بين المعلمة أسماء وطالبتيها جمانة وياسمين عن صروح الكويت الوطنية.',
        content: {
          summaryEn: 'Ms Asmaa and students Jumana and Yasmin explore The Qurain Martyrs’ House (symbol of loyalty), The National Library (rare manuscripts), and The National Museum.',
          summaryAr: 'بيت شهداء القرين رمز التضحية والوفاء، المكتبة الوطنية بمخطوطاتها النادرة، والمتحف الوطني الكويتي.',
          tasks: [
            {
              id: 'u4-l9-t1',
              questionEn: 'Which national landmark is revered as a poignant "symbol of loyalty and sacrifice" whose walls are preserved exactly as they were?',
              questionAr: 'أي صرح وطني يُخلّد كرمز للتضحية والوفاء وحُفظت جدرانه تماماً كما كانت؟',
              type: 'mcq',
              options: [
                'The Qurain Martyrs’ House',
                'The National Library of Kuwait',
                'The Avenues Mall',
                'The Souq Al-Mubarakiya'
              ],
              correctAnswer: 0,
              explanation: 'Textbook page 75 highlights the Qurain Martyrs’ House as a sacred symbol of loyalty and sacrifice.'
            }
          ]
        }
      },
      {
        id: 'u4-l10',
        unitId: 4,
        lessonNumber: 10,
        type: 'Speaking',
        titleEn: 'The Invisible Safeguard',
        titleAr: 'الحصن الخفي (اللوائح السلوكية والناضجة)',
        pageNumber: 76,
        newVocabulary: ['regulation', 'character', 'record', 'lasting', 'mature'],
        objectiveEn: 'Discuss school rules as safeguards rather than punishment and deliver structured speeches on exam regulations.',
        objectiveAr: 'مناقشة اللائحة المدرسية كحماية للطلاب لا عقاب، وإلقاء خطابات توعوية حول لوائح الامتحانات.',
        content: {
          summaryEn: 'Why school behaviour shapes future character, the lasting value of a good record, and becoming mature citizens.',
          summaryAr: 'أثر السلوك المدرسي في بناء الشخصية الناضجة وأهمية السجل السلوكي النظيف في المستقبل.',
          tasks: [
            {
              id: 'u4-l10-t1',
              questionEn: 'How should responsible students view school and exam regulations?',
              questionAr: 'كيف يجب على الطالب الواعي والناضج أن ينظر إلى اللوائح المدرسية وقوانين الامتحانات؟',
              type: 'mcq',
              options: [
                'As an invisible safeguard that protects fairness and students’ safety',
                'As an unfair punishment intended to restrict freedom',
                'As suggestions that can be ignored anytime'
              ],
              correctAnswer: 0,
              explanation: 'Textbook page 76: "understanding school rules as a safeguard rather than a punishment."'
            }
          ]
        }
      },
      {
        id: 'u4-l11',
        unitId: 4,
        lessonNumber: 11,
        type: 'Writing',
        titleEn: 'National Duty',
        titleAr: 'الواجب الوطني وأقوال قادة الكويت',
        pageNumber: 77,
        newVocabulary: [],
        objectiveEn: 'Construct a cohesive essay on the responsibilities of good citizenship using paraphrased quotes from Kuwaiti leaders as hooks.',
        objectiveAr: 'صياغة مقال متكامل حول واجبات المواطن الصالح مع الاستشهاد بأقوال قادة وأمراء الكويت كخطاف مقدمة.',
        content: {
          summaryEn: 'Quotes by Kuwaiti leaders: HH Sheikh Jaber Al-Ahmad ("The love of Kuwait comes before love of self..."), HH Sheikh Sabah Al-Ahmad ("The wealth of a country is within its people..."), HH Sheikh Nawaf Al-Ahmad ("Kuwait gets its strength from the unity of its people").',
          summaryAr: 'أقوال حكام الكويت الراحلين: الشيخ جابر، الشيخ صباح، والشيخ نواف طيب الله ثراهم، وتقييم الجمل الختامية.',
          tasks: [
            {
              id: 'u4-l11-t1',
              questionEn: 'Which concluding sentence is rated EXCELLENT for an essay on citizenship?',
              questionAr: 'أي من الجمل الختامية التالية صُنّفت كـ "ممتازة" (Excellent) وفق معايير الكتاب لمقال المواطنة؟',
              type: 'mcq',
              options: [
                'Ultimately, by demonstrating civil responsibility, we play a critical role in shaping the future.',
                'In conclusion, I think that the national football team will win the upcoming matches.',
                'So, it is nice to be a good citizen all the time.'
              ],
              correctAnswer: 0,
              explanation: 'Textbook rating exercise page 77 rates: "Ultimately, by demonstrating civil responsibility, we play a critical role in shaping the future" as Excellent.'
            }
          ]
        }
      }
    ]
  }
];
