import { GrammarRule } from '../types';

export const GRAMMAR_RULES: GrammarRule[] = [
  // 1. Present Simple & Adverbs of Frequency
  {
    id: 'present-simple-adverbs',
    number: 1,
    unitId: 1,
    titleEn: 'Present Simple and Adverbs of Frequency',
    titleAr: 'المضارع البسيط وظروف التكرار',
    page: 86,
    summaryEn: 'Express routines, repeated actions, general truths, and scientific facts. Use adverbs of frequency to state how often things occur.',
    summaryAr: 'يُستخدم للتعبير عن العادات والروتين اليومي والحقائق العلمية الثابتة، مع بيان مدى تكرار الفعل باستخدام ظروف التكرار.',
    rules: [
      {
        heading: 'Uses and Meanings',
        details: 'We use the present simple for: 1) Habits and routines: "I pray five times everyday." 2) Permanent situations and truths: "Ten times ten makes one hundred." 3) True facts: "The sun rises from the east."',
        examples: [
          { sentence: 'They live in Kuwait.', note: 'Fact / Permanent state' },
          { sentence: 'She studies English every day.', note: 'Routine / Habit (adds -s for she)' },
          { sentence: 'Fast-food restaurants offer high-fat meals.', note: 'General fact' }
        ]
      },
      {
        heading: 'Sentence Forms (Affirmative, Negative & Questions)',
        formula: 'Affirmative: S + V1 (s/es with He/She/It) | Negative: S + don\'t/doesn\'t + V1 | Questions: Do/Does + S + V1?',
        details: 'With I/You/We/They use the base verb. With He/She/It add -s or -es. In negatives, use "don\'t" or "doesn\'t" followed by the bare infinitive.',
        examples: [
          { sentence: 'I don’t like coffee.', note: 'Negative with I' },
          { sentence: 'He doesn’t play video games.', note: 'Negative with He (doesn’t + base)' },
          { sentence: 'Where does she come from?', note: 'Wh- question with Does' },
          { sentence: 'Do they live near the school?', note: 'Yes/No question with Do' }
        ]
      },
      {
        heading: 'Adverbs of Frequency (The Frequency Ladder)',
        formula: 'Subject + [Adverb] + Main Verb  OR  Subject + Verb (to be) + [Adverb]',
        details: 'Frequency scale: Always (100%), Usually (80–90%), Often (50–70%), Sometimes (20–40%), Hardly ever (5–10%), Never (0%). Position: Before the main verb, but AFTER the verb to be (am/is/are).',
        examples: [
          { sentence: 'I usually drink a glass of water before the meal.', note: 'Before main verb "drink"' },
          { sentence: 'I am never late for school.', note: 'After auxiliary verb "am"' },
          { sentence: 'Rashed never stays at home at the weekends.', note: 'Before main verb "stays"' }
        ]
      }
    ],
    practiceQuestions: [
      {
        id: 'ps-1',
        question: 'Lulwa __________ (buy) ready-made meals after school.',
        options: ['buy', 'buys', 'is buying', 'bought'],
        correctAnswer: 1,
        explanation: 'With third-person singular "Lulwa" (she), we add -s to the base verb in present simple: "buys".'
      },
      {
        id: 'ps-2',
        question: 'Choose the correct position of the adverb: "My water bottle is __________ full."',
        options: ['always is', 'is always', 'always are', 'is never'],
        correctAnswer: 1,
        explanation: 'Adverbs of frequency come AFTER the verb to be (am/is/are): "is always".'
      },
      {
        id: 'ps-3',
        question: 'What food __________ Kuwaitis usually eat for lunch?',
        options: ['are', 'do', 'does', 'have'],
        correctAnswer: 1,
        explanation: 'Kuwaitis is plural (they), so the question auxiliary in the present simple is "do".'
      }
    ]
  },

  // 2. Present Simple Continuous
  {
    id: 'present-continuous',
    number: 2,
    unitId: 1,
    titleEn: 'Present Simple Continuous',
    titleAr: 'المضارع المستمر',
    page: 87,
    summaryEn: 'Used to describe actions happening right now, temporary situations, or definite future arrangements.',
    summaryAr: 'يُستخدم للتعبير عن أحداث تقع الآن لحظة الكلام، أو أوضاع مؤقتة، أو ترتيبات مستقبلية محددة.',
    rules: [
      {
        heading: 'When to Use Present Continuous',
        details: '1) Actions happening at this very moment (Listen! Look!). 2) Temporary ongoing situations (these days, currently). 3) Fixed future arrangements.',
        examples: [
          { sentence: 'The dietitian is composing a customised meal plan for the young man.', note: 'Action happening now' },
          { sentence: 'Nutrition programmes are helping students learn healthy habits.', note: 'Ongoing trend' },
          { sentence: 'I am drinking plenty of water to stay hydrated during class.', note: 'Happening now' }
        ]
      },
      {
        heading: 'Forms & Negatives',
        formula: 'Subject + am / is / are + (not) + verb-ing',
        details: 'I am | He/She/It is | We/You/They are + base verb + -ing. In negatives add "not" right after the auxiliary.',
        examples: [
          { sentence: 'I am not sitting with good posture throughout the school day.', note: 'Negative with I' },
          { sentence: 'Adolescents are not spending enough time practicing sports.', note: 'Negative with plural' },
          { sentence: 'Where are they going now?', note: 'Wh- question' }
        ]
      }
    ],
    practiceQuestions: [
      {
        id: 'pc-1',
        question: 'Look at Hamad’s lunch! He __________ (not eat) white bread anymore.',
        options: ['is not eating', 'does not eat', 'are not eating', 'was not eating'],
        correctAnswer: 0,
        explanation: '"Look!" signals an action occurring at the present moment, requiring present continuous: "is not eating".'
      },
      {
        id: 'pc-2',
        question: 'Listen! The teacher __________ the importance of sleep for our health.',
        options: ['explains', 'is explaining', 'explained', 'has explained'],
        correctAnswer: 1,
        explanation: '"Listen!" signals an action in progress right now: "is explaining".'
      }
    ]
  },

  // 3. The Order of Adjectives (OSASCOMP)
  {
    id: 'order-of-adjectives',
    number: 3,
    unitId: 1,
    titleEn: 'The Order of Adjectives (OSASCOMP)',
    titleAr: 'ترتيب الصفات (OSASCOMP)',
    page: 87,
    summaryEn: 'When using multiple adjectives before a noun, English follows the OSASCOMP sequence: Opinion, Size, Age, Shape, Colour, Origin, Material, Purpose.',
    summaryAr: 'عند استخدام أكثر من صفة لوصف الاسم، تُرتّب حسب قاعدة OSASCOMP: الرأي، الحجم، العمر، الشكل، اللون، الأصل، المادة، الغرض.',
    rules: [
      {
        heading: 'The OSASCOMP Mnemonic Sequence',
        formula: 'Opinion ➔ Size ➔ Age ➔ Shape ➔ Colour ➔ Origin ➔ Material ➔ Purpose + Noun',
        details: '1. Opinion: beautiful, delicious, interesting. 2. Size: large, tiny, short. 3. Age: ancient, modern, new. 4. Shape: square, thin, round. 5. Colour: red, silver, dark. 6. Origin: Kuwaiti, Italian. 7. Material: wooden, velvet, cotton. 8. Purpose: dining, running, gardening.',
        examples: [
          { sentence: 'Reading interesting short modern books improves mood.', note: 'Opinion (interesting) + Size (short) + Age (modern)' },
          { sentence: 'Avoid massive oily processed meals to protect your heart.', note: 'Size (massive) + Quality/Opinion (oily) + Purpose/Type (processed)' },
          { sentence: 'Joining a marathon requires comfortable new running trainers.', note: 'Opinion (comfortable) + Age (new) + Purpose (running)' }
        ]
      }
    ],
    specialSection: {
      title: 'OSASCOMP Breakdown Matrix',
      items: [
        { key: 'O', category: 'Opinion', examples: 'delicious, beautiful, wonderful, awful' },
        { key: 'S', category: 'Size', examples: 'large, tiny, massive, small, huge' },
        { key: 'A', category: 'Age', examples: 'ancient, modern, new, young, antique' },
        { key: 'S', category: 'Shape', examples: 'square, round, thin, rectangular, oval' },
        { key: 'C', category: 'Colour', examples: 'red, silver, golden, blue, green' },
        { key: 'O', category: 'Origin', examples: 'Kuwaiti, Italian, Japanese, Omani, British' },
        { key: 'M', category: 'Material', examples: 'wooden, cotton, velvet, leather, steel' },
        { key: 'P', category: 'Purpose', examples: 'running (trainers), dining (table), sleeping (bag)' }
      ]
    },
    practiceQuestions: [
      {
        id: 'adj-1',
        question: 'Which order is correct for describing the books?',
        options: [
          'modern interesting short books',
          'interesting short modern books',
          'short modern interesting books',
          'interesting modern short books'
        ],
        correctAnswer: 1,
        explanation: 'According to OSASCOMP: Opinion (interesting) comes before Size (short), which comes before Age (modern).'
      },
      {
        id: 'adj-2',
        question: 'He bought a __________ table.',
        options: [
          'wooden beautiful round',
          'beautiful round wooden',
          'round beautiful wooden',
          'wooden round beautiful'
        ],
        correctAnswer: 1,
        explanation: 'Opinion (beautiful) ➔ Shape (round) ➔ Material (wooden).'
      }
    ]
  },

  // 4. The Present Perfect Simple
  {
    id: 'present-perfect-simple',
    number: 4,
    unitId: 2,
    titleEn: 'The Present Perfect Simple',
    titleAr: 'المضارع التام البسيط',
    page: 87,
    summaryEn: 'Connects past actions and experiences with the present. Employs time markers: since, for, already, just, yet, and lately.',
    summaryAr: 'يربط أحداث وتجارب الماضي بالحاضر، مع استخدام الكلمات الدالة ومواضعها: since, for, already, just, yet, lately.',
    rules: [
      {
        heading: 'Structure & Primary Uses',
        formula: 'Subject + have / has + Past Participle (V3)',
        details: 'Uses: 1) Past actions with present results: "Kuwait has reduced its carbon emissions." 2) Unspecified past experiences: "Scientists have discovered clean energy." 3) Unfinished situations: "Researchers have worked on this for years." 4) Recent events: "Engineers have just completed the phase." 5) Negative states up to now: "Many haven\'t switched yet."',
        examples: [
          { sentence: 'Kuwait has begun using renewable energy.', note: 'Action started in past, impact felt now' },
          { sentence: 'Scientists have worked on this project for many years.', note: 'Unfinished action continuing to present' },
          { sentence: 'Many families have already started making responsible choices.', note: 'Completed sooner than expected' }
        ]
      },
      {
        heading: 'Placement of Time Expressions',
        details: '• The Middle (between has/have and V3): "just", "already" (We have just made plans / She has already left).\n• Close to the End (before a point or duration): "for" (length of time: for hours) and "since" (exact starting point: since 2010).\n• The End (at sentence conclusion): "yet" (in negatives & questions) and "lately" (recent ongoing period).',
        examples: [
          { sentence: 'Kuwait has set up many new environmental projects since 2010.', note: '"since" marks the starting year' },
          { sentence: 'Researchers have studied energy alternatives for many years.', note: '"for" marks duration of time' },
          { sentence: 'She has not done her work yet.', note: '"yet" at the end of a negative sentence' }
        ]
      }
    ],
    practiceQuestions: [
      {
        id: 'pp-1',
        question: 'Kuwait has set up environmental projects __________ 2010.',
        options: ['since', 'for', 'already', 'yet'],
        correctAnswer: 0,
        explanation: 'We use "since" with a specific starting date/year in the past (2010).'
      },
      {
        id: 'pp-2',
        question: 'Few schools have not focused on environmental awareness __________.',
        options: ['already', 'since', 'yet', 'just'],
        correctAnswer: 2,
        explanation: '"yet" is placed at the end of negative sentences and questions in the present perfect.'
      },
      {
        id: 'pp-3',
        question: 'My older brother has __________ installed solar panels on our roof.',
        options: ['yet', 'since', 'just', 'for'],
        correctAnswer: 2,
        explanation: '"just" goes between "has" and the past participle "installed" to indicate a very recent action.'
      }
    ]
  },

  // 5. 1st If Conditional and Modal Verbs
  {
    id: 'first-conditional-modals',
    number: 5,
    unitId: 2,
    titleEn: '1st If Conditional and Modal Verbs',
    titleAr: 'الحالة الشرطية الأولى والأفعال الناقصة',
    page: 88,
    summaryEn: 'Discuss real and likely future outcomes using modal verbs: will (certain outcome), can (ability), may (probability), and should (advice).',
    summaryAr: 'الحديث عن مواقف ونتائج مستقبلية محتملة وواقعية باستخدام الأفعال الناقصة المناسبة للمعنى.',
    rules: [
      {
        heading: 'Form and Sentence Structure',
        formula: 'If + Present Simple, Subject + Modal Verb + Base Verb',
        details: 'The if-clause can come first or second. A comma is required ONLY when the if-clause comes first. Negatives use do/does not in the if-clause, or modal + not in the main clause.',
        examples: [
          { sentence: 'If the mobile phone battery dies, the phone will stop working.', note: 'Certain outcome (will)' },
          { sentence: 'If you take it to a repair shop, they can replace the battery.', note: 'Ability / possibility (can)' },
          { sentence: 'If the parts are available, the repair may take an hour.', note: 'Probability / uncertainty (may)' },
          { sentence: 'If the model is new, you should try to fix it instead of buying a new one.', note: 'Advice (should)' }
        ]
      },
      {
        heading: 'Common Mistakes to Avoid',
        details: '1. Do NOT put "will" in the if-clause! (INCORRECT: If it will rain... | CORRECT: If it rains...).\n2. Do NOT mix with 2nd conditional "would" (INCORRECT: If I would go...).\n3. Match the modal to your intent: will = certainty, can = ability, may = probability, should = advice.',
        examples: [
          { sentence: 'If we recycle our plastic bottles, we will certainly reduce waste.', note: 'Certainty' },
          { sentence: 'If she collects glass jars, she can easily turn them into beautiful vases.', note: 'Ability' },
          { sentence: 'If you have old newspapers, you should use them to wrap gifts.', note: 'Advice' }
        ]
      }
    ],
    practiceQuestions: [
      {
        id: 'cond-1',
        question: 'If more people try thrifting, they __________ save money. However, this is not certain.',
        options: ['will', 'may', 'should', 'must'],
        correctAnswer: 1,
        explanation: 'Because it is not certain, "may" expresses probability and uncertainty.'
      },
      {
        id: 'cond-2',
        question: 'Identify the error: "If the weather will be hot tomorrow, we will stay indoors."',
        options: [
          'Change "will be" to "is"',
          'Change "stay" to "staying"',
          'Remove "indoors"',
          'Change "we" to "they"'
        ],
        correctAnswer: 0,
        explanation: 'Never use "will" in the if-clause of the 1st conditional; use the present simple ("is").'
      }
    ]
  },

  // 6. Non-Defining Relative Pronouns & Clauses
  {
    id: 'non-defining-relative-clauses',
    number: 6,
    unitId: 3,
    titleEn: 'Non-Defining Relative Pronouns & Clauses',
    titleAr: 'ضمائر وجمل الوصل غير المحددة',
    page: 89,
    summaryEn: 'Adds non-essential extra information about people, places, things, times, or possessions. Always surrounded by commas, and never uses "that".',
    summaryAr: 'تضيف معلومات إضافية غير أساسية عن الأشخاص أو الأماكن أو الأشياء، وتُفصل دائماً بفواصل ولا تستخدم "that" أبداً.',
    rules: [
      {
        heading: 'Meaning & The "Bread and Filling" Concept',
        formula: 'Noun, relative pronoun + clause, rest of sentence',
        details: 'Non-defining relative clauses provide extra background or descriptive information. If removed, the main sentence remains complete and meaningful.\n• The Bread: The boy wants to travel a lot.\n• The Filling: His father is a pilot.\n• The Sandwich: The boy, whose father is a pilot, wants to travel a lot.',
        examples: [
          { sentence: 'Ahmed bin Salman Al-Ustath, who was a master shipbuilder, built 20 dhows.', note: 'who = people' },
          { sentence: 'Al Salam Palace Museum, which includes three unique sections, is unforgettable.', note: 'which = things/places' },
          { sentence: 'The Red Fort, where stories of the past are kept alive, is a symbol of national pride.', note: 'where = place' },
          { sentence: 'Sheikha Intisar Al Sabah, whose latest project was a history book, tells Kuwait’s story.', note: 'whose = possession' },
          { sentence: 'The year 1963, when Kuwait joined the United Nations, was a turning point.', note: 'when = time' }
        ]
      },
      {
        heading: 'Crucial Rules from Grammar File',
        details: '1. Use commas (,): This is essential! ("My car, which is very old, still works.")\n2. Do NOT use "that" in non-defining clauses! (INCORRECT: My friend, that lives near me... | CORRECT: My friend, who lives near me, is funny).',
        examples: [
          { sentence: 'Kuwait, which is in the Gulf, is very hot in summer.', note: 'Surrounded by commas' },
          { sentence: 'Mr Jamal, who really enjoys his job, is a history teacher.', note: 'Uses "who", not "that"' }
        ]
      }
    ],
    practiceQuestions: [
      {
        id: 'rel-1',
        question: 'Zoomorphic calligraphy, __________ is a special type of Arabic art, combines writing with animal shapes.',
        options: ['who', 'which', 'that', 'where'],
        correctAnswer: 1,
        explanation: 'We refer to an art form (a thing) in a non-defining clause surrounded by commas, so we use "which" (never "that").'
      },
      {
        id: 'rel-2',
        question: 'The author, __________ latest historical novel won an award, visited our school.',
        options: ['who', 'which', 'whose', 'when'],
        correctAnswer: 2,
        explanation: '"whose" indicates possession of the novel.'
      }
    ]
  },

  // 7. Past Simple & Past Continuous (when / while / as)
  {
    id: 'past-simple-continuous',
    number: 7,
    unitId: 3,
    titleEn: 'Past Simple & Past Continuous (when / while / as)',
    titleAr: 'الماضي البسيط والماضي المستمر (when / while / as)',
    page: 90,
    summaryEn: 'Express completed short past actions (V2) versus ongoing background actions (was/were + V-ing). Connect them with when, while, and as.',
    summaryAr: 'التمييز بين الأحداث المكتملة اللحظية (الماضي البسيط) والأحداث الممتدة في الماضي (الماضي المستمر) والربط بينها.',
    rules: [
      {
        heading: 'Tenses Difference',
        details: '• Past Simple (Verb 2): Finished short or sudden action that interrupts. ("I saw a bird", "She opened the door").\n• Past Continuous (was/were + verb-ing): Action in progress (long background action). ("I was walking", "They were playing football").',
        examples: [
          { sentence: 'I was exploring Failaka Island when I found artefacts.', note: 'Long action interrupted by short action' },
          { sentence: 'While the children were watching a folk dance, the music stopped.', note: 'Short action interrupting continuous state' }
        ]
      },
      {
        heading: 'Connecting with "When", "While", and "As"',
        formula: 'When + Past Simple (V2), Past Continuous (was/were + V-ing)  OR  While/As + Past Continuous, Past Simple',
        details: '• "When": short action interrupts long action: "I was cooking when the lights went out."\n• "While / As": two actions happening simultaneously in parallel: "While I was studying, my brother was watching TV." / "As they were walking, they were listening to music."',
        examples: [
          { sentence: 'As a tourist was walking through Al-Mirqab, he saw an unusual mosque.', note: 'As + continuous, past simple' },
          { sentence: 'When he entered the mosque, people were praying quietly inside.', note: 'When + past simple, continuous' }
        ]
      }
    ],
    practiceQuestions: [
      {
        id: 'past-1',
        question: 'While I __________ (look) at the photo, I recognised my friend.',
        options: ['looked', 'was looking', 'am looking', 'have looked'],
        correctAnswer: 1,
        explanation: 'After "While" describing an action in progress, we use the past continuous: "was looking".'
      },
      {
        id: 'past-2',
        question: 'When the pearl divers returned, their families __________ on the shore.',
        options: ['waited', 'were waiting', 'wait', 'are waiting'],
        correctAnswer: 1,
        explanation: 'The families were already in the process of waiting when the divers arrived: "were waiting".'
      }
    ]
  },

  // 8. Reported Speech
  {
    id: 'reported-speech',
    number: 8,
    unitId: 4,
    titleEn: 'Reported Speech',
    titleAr: 'الكلام المنقول (غير المباشر)',
    page: 91,
    summaryEn: 'Report what someone else said by shifting verb tenses backwards, updating pronouns, and modifying time and place indicators.',
    summaryAr: 'نقل كلام المتحدثين مع تحويل الأزمنة خطوة إلى الماضي، وتغيير الضمائر، والظروف المكانية والزمانية بدقة.',
    rules: [
      {
        heading: 'Verb Tense Shifts (Backshifting)',
        formula: 'Present Simple ➔ Past Simple | Past Simple ➔ Past Perfect | Future (will) ➔ Would',
        details: 'When reporting statements, shift the tense one step back into the past:\n• "I work in Kuwait City now" ➔ She said she worked in Kuwait City then.\n• "We visited the museum yesterday" ➔ They said they had visited the museum the day before.\n• "I will help you tomorrow" ➔ She said she would help me the next day.',
        examples: [
          { sentence: 'Direct: "The government will always work hard to protect flowers," said the official.', note: 'will ➔ would' },
          { sentence: 'Reported: The official said that the government would always work hard to protect flowers.', note: 'Tense shifted to would' },
          { sentence: 'He claimed that officials had made the right choice in selecting it.', note: 'Past perfect after reporting verb "claimed"' }
        ]
      },
      {
        heading: 'Pronoun and Time/Place Transformations',
        details: 'Pronouns: I ➔ he/she | you ➔ I/me/they | we ➔ they | us ➔ them | my ➔ his/her | your ➔ their/my.\nTime/Place: here ➔ there | now ➔ then / at that moment | tomorrow ➔ the next day / following day | tonight ➔ that night | next week ➔ the following week | yesterday ➔ the day before | last week ➔ the week before.',
        examples: [
          { sentence: '"I will meet my friends tomorrow" ➔ Ahmad said he would meet his friends the next day.', note: 'Pronoun: I ➔ he, will ➔ would, tomorrow ➔ the next day' }
        ]
      }
    ],
    practiceQuestions: [
      {
        id: 'rep-1',
        question: '“The Omani Rose was the finest flower last year,” said the speaker. ➔ He said that the Omani Rose __________ the finest flower the year before.',
        options: ['is', 'was', 'had been', 'would be'],
        correctAnswer: 2,
        explanation: 'Past simple ("was") shifts back to past perfect ("had been") in reported speech.'
      },
      {
        id: 'rep-2',
        question: '“I will help you tomorrow,” said Dana. ➔ Dana said that she would help me __________.',
        options: ['tomorrow', 'the next day', 'yesterday', 'then'],
        correctAnswer: 1,
        explanation: 'In reported speech, "tomorrow" transforms into "the next day" or "the following day".'
      }
    ]
  },

  // 9. Future Forms & Countable / Uncountable Nouns
  {
    id: 'future-countable-uncountable',
    number: 9,
    unitId: 4,
    titleEn: 'Future Forms & Countable and Uncountable Nouns',
    titleAr: 'صيغ المستقبل والأسماء المعدودة وغير المعدودة',
    page: 91,
    summaryEn: 'Master the three future expressions (will, be going to, present continuous) and understand countable/uncountable rules and quantifiers.',
    summaryAr: 'إتقان صيغ المستقبل الثلاث (التنبؤ، النية، الترتيب المسبق) والتفريق بين الأسماء المعدودة وغير المعدودة ومحددات الكمية.',
    rules: [
      {
        heading: 'Three Forms for the Future',
        formula: 'will + base | (be) going to + base | (be) + verb-ing',
        details: '1) "will + base": Predictions of the future based on belief/opinion ("The weather will be hot tomorrow" / "The new airport will open next year").\n2) "(be) going to + base": Intentions and predictions based on present evidence ("I think it is going to rain tomorrow" / "They are going to present their final project").\n3) "Present Continuous (be + V-ing)": Fixed arrangements with people or dates ("He is inviting his friends tomorrow night" / "We are driving to Al-Khafji this weekend").',
        examples: [
          { sentence: 'The bus is leaving at 8:00 a.m.', note: 'Fixed arrangement (present continuous)' },
          { sentence: 'It will be sunny.', note: 'Prediction (will)' },
          { sentence: 'I am going to take photographs.', note: 'Intention (be going to)' }
        ]
      },
      {
        heading: 'Countable vs. Uncountable Nouns',
        details: '• Countable (How many...?): store/stores, bus/buses. Irregular plurals: child/children, foot/feet, man/men, woman/women, tooth/teeth, person/people. Quantifiers: many (large) / few (small).\n• Uncountable (How much...?): advice, bread, fruit, furniture, hair, homework, information, money, news, paper, rice, work. Followed by a singular verb ("The news is very interesting"). Plural exceptions: clothes and jeans ("Your clean clothes are on the bed"). Quantifiers: much (large) / little (small).',
        examples: [
          { sentence: 'We need some money for next week’s school trip.', note: 'Uncountable noun' },
          { sentence: 'Her hair looks very healthy.', note: 'Takes singular verb "looks"' },
          { sentence: 'How many books did you read?', note: 'Countable with "how many"' },
          { sentence: 'How much water do you drink?', note: 'Uncountable with "how much"' }
        ]
      }
    ],
    practiceQuestions: [
      {
        id: 'fut-1',
        question: 'Next Tuesday at 10 a.m., a historian __________ a talk on the Pyramids.',
        options: ['will give', 'is giving', 'gives', 'gave'],
        correctAnswer: 1,
        explanation: 'A fixed arrangement scheduled at a specific time (Tuesday at 10 a.m.) uses the present continuous: "is giving".'
      },
      {
        id: 'fut-2',
        question: 'Our teacher gave us some good __________ before the exam.',
        options: ['advices', 'advice', 'an advice', 'many advices'],
        correctAnswer: 1,
        explanation: '"advice" is an uncountable noun in English; it cannot be made plural with -s and takes no "an".'
      },
      {
        id: 'fut-3',
        question: 'There were very __________ people at the historical museum today.',
        options: ['little', 'few', 'much', 'less'],
        correctAnswer: 1,
        explanation: '"people" is a countable plural noun, so we use "few" for a small number.'
      }
    ]
  }
];

export const IRREGULAR_VERBS = [
  { base: 'be', past: 'was/were', pp: 'been' },
  { base: 'beat', past: 'beat', pp: 'beaten' },
  { base: 'become', past: 'became', pp: 'become' },
  { base: 'begin', past: 'began', pp: 'begun' },
  { base: 'bend', past: 'bent', pp: 'bent' },
  { base: 'bite', past: 'bit', pp: 'bitten' },
  { base: 'blow', past: 'blew', pp: 'blown' },
  { base: 'break', past: 'broke', pp: 'broken' },
  { base: 'bring', past: 'brought', pp: 'brought' },
  { base: 'build', past: 'built', pp: 'built' },
  { base: 'buy', past: 'bought', pp: 'bought' },
  { base: 'catch', past: 'caught', pp: 'caught' },
  { base: 'choose', past: 'chose', pp: 'chosen' },
  { base: 'come', past: 'came', pp: 'come' },
  { base: 'cost', past: 'cost', pp: 'cost' },
  { base: 'cut', past: 'cut', pp: 'cut' },
  { base: 'do', past: 'did', pp: 'done' },
  { base: 'draw', past: 'drew', pp: 'drawn' },
  { base: 'drink', past: 'drank', pp: 'drunk' },
  { base: 'drive', past: 'drove', pp: 'driven' },
  { base: 'eat', past: 'ate', pp: 'eaten' },
  { base: 'fall', past: 'fell', pp: 'fallen' },
  { base: 'feed', past: 'fed', pp: 'fed' },
  { base: 'feel', past: 'felt', pp: 'felt' },
  { base: 'fight', past: 'fought', pp: 'fought' },
  { base: 'find', past: 'found', pp: 'found' },
  { base: 'fly', past: 'flew', pp: 'flown' },
  { base: 'forget', past: 'forgot', pp: 'forgotten' },
  { base: 'freeze', past: 'froze', pp: 'frozen' },
  { base: 'get', past: 'got', pp: 'gotten' },
  { base: 'give', past: 'gave', pp: 'given' },
  { base: 'go', past: 'went', pp: 'gone' },
  { base: 'grow', past: 'grew', pp: 'grown' },
  { base: 'have', past: 'had', pp: 'had' },
  { base: 'hear', past: 'heard', pp: 'heard' },
  { base: 'hide', past: 'hid', pp: 'hidden' },
  { base: 'hold', past: 'held', pp: 'held' },
  { base: 'keep', past: 'kept', pp: 'kept' },
  { base: 'know', past: 'knew', pp: 'known' },
  { base: 'lead', past: 'led', pp: 'led' },
  { base: 'leave', past: 'left', pp: 'left' },
  { base: 'lose', past: 'lost', pp: 'lost' },
  { base: 'make', past: 'made', pp: 'made' },
  { base: 'mean', past: 'meant', pp: 'meant' },
  { base: 'meet', past: 'met', pp: 'met' },
  { base: 'pay', past: 'paid', pp: 'paid' },
  { base: 'put', past: 'put', pp: 'put' },
  { base: 'read', past: 'read', pp: 'read' },
  { base: 'ride', past: 'rode', pp: 'ridden' },
  { base: 'run', past: 'ran', pp: 'run' },
  { base: 'say', past: 'said', pp: 'said' },
  { base: 'see', past: 'saw', pp: 'seen' },
  { base: 'sell', past: 'sold', pp: 'sold' },
  { base: 'send', past: 'sent', pp: 'sent' },
  { base: 'speak', past: 'spoke', pp: 'spoken' },
  { base: 'spend', past: 'spent', pp: 'spent' },
  { base: 'stand', past: 'stood', pp: 'stood' },
  { base: 'take', past: 'took', pp: 'taken' },
  { base: 'teach', past: 'taught', pp: 'taught' },
  { base: 'tell', past: 'told', pp: 'told' },
  { base: 'think', past: 'thought', pp: 'thought' },
  { base: 'throw', past: 'threw', pp: 'thrown' },
  { base: 'understand', past: 'understood', pp: 'understood' },
  { base: 'write', past: 'wrote', pp: 'written' }
];

export const STATIVE_VERBS = [
  { category: 'Thoughts & Opinions', verbs: ['agree', 'disagree', 'doubt', 'forget', 'know', 'recognise', 'remember', 'support', 'suppose', 'think', 'understand'] },
  { category: 'Emotions & Feelings', verbs: ['envy', 'fear', 'hate', 'hope', 'like', 'dislike', 'love', 'need', 'prefer', 'value', 'want', 'wish'] },
  { category: 'Senses & Perception', verbs: ['appear', 'feel', 'hear', 'look', 'see', 'seem', 'sense', 'smell', 'sound', 'taste'] },
  { category: 'Possession & Relation', verbs: ['belong', 'comprise', 'consist', 'contain', 'has/have', 'include', 'own', 'possess'] },
  { category: 'States, Cost & Measure', verbs: ['be/is/are', 'cost', 'depend', 'involve', 'measure', 'owe', 'resemble', 'span', 'weigh'] }
];
