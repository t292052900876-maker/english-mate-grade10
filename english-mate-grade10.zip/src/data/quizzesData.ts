import { QuizQuestion } from '../types';

export interface UnitQuiz {
  unitId: number;
  titleEn: string;
  titleAr: string;
  timeMinutes: number;
  questions: QuizQuestion[];
}

export const UNIT_QUIZZES: UnitQuiz[] = [
  // UNIT 1 QUIZ
  {
    unitId: 1,
    titleEn: 'Unit 1 Comprehensive Assessment: The Science of Nutrition',
    titleAr: 'اختبار تقويمي شامل للوحدة الأولى: علم التغذية',
    timeMinutes: 15,
    questions: [
      {
        id: 'q1-1',
        unitId: 1,
        type: 'vocab',
        question: 'Drinking sufficient water and eating vegetables provide __________ benefits for teenagers.',
        questionAr: 'شرب كميات كافية من الماء وتناول الخضراوات يقدم فوائد غذائية للمراهقين:',
        options: ['nutritional', 'inactive', 'decorative', 'unnecessary'],
        correctAnswer: 0,
        explanation: '"Nutritional" is an adjective meaning connected with the nourishing substances in food.'
      },
      {
        id: 'q1-2',
        unitId: 1,
        type: 'vocab',
        question: 'The Kuwait Flour Mills programme aims to __________ healthier lifestyles among students.',
        questionAr: 'يهدف برنامج شركة مطاحن الدقيق الكويتية إلى تحفيز نمط حياة صحي بين الطلاب:',
        options: ['stimulate', 'bury', 'dispose of', 'injure'],
        correctAnswer: 0,
        explanation: '"stimulate" means to encourage activity, growth, or enthusiasm.'
      },
      {
        id: 'q1-3',
        unitId: 1,
        type: 'grammar',
        question: 'Hamad always __________ (eat) balanced meals to stay energized.',
        questionAr: 'اختر تصريف المضارع البسيط الصحيح مع الفاعل المفرد Hamad:',
        options: ['eat', 'eats', 'is eating', 'ate'],
        correctAnswer: 1,
        explanation: 'In the present simple, verbs take -s/-es with third-person singular subjects (he/she/it).'
      },
      {
        id: 'q1-4',
        unitId: 1,
        type: 'grammar',
        question: 'Identify the correct order of adjectives according to OSASCOMP:',
        questionAr: 'حدد الترتيب الصحيح للصفات وفق قاعدة OSASCOMP:',
        options: [
          'She bought a comfortable new running shoe.',
          'She bought a running new comfortable shoe.',
          'She bought a new running comfortable shoe.',
          'She bought a comfortable running new shoe.'
        ],
        correctAnswer: 0,
        explanation: 'OSASCOMP: Opinion (comfortable) ➔ Age (new) ➔ Purpose (running).'
      },
      {
        id: 'q1-5',
        unitId: 1,
        type: 'reading',
        question: 'In the past, why were obesity and food-related illnesses rare in Kuwait?',
        questionAr: 'لماذا كانت السمنة والأمراض المرتبطة بالغذاء نادرة في الكويت قديماً؟',
        options: [
          'Because the pearl-diving and fishing lifestyle was physically active and based on simple seafood and dates',
          'Because people never ate lunch',
          'Because supermarkets were free',
          'Because fast food was banned'
        ],
        correctAnswer: 0,
        explanation: 'The reading passage explains that the active maritime lifestyle and natural diet of fish, dates, and rice kept people healthy.'
      },
      {
        id: 'q1-6',
        unitId: 1,
        type: 'function',
        question: 'Your friend wants to skip breakfast before a strenuous exam. What do you say to give advice?',
        questionAr: 'صديقك يريد تفويت وجبة الإفطار قبل امتحان صعب. ماذا تقول لتقديم النصيحة؟',
        options: [
          'If I were you, I would eat a wholesome snack like dates and nuts to keep your brain focused.',
          'Good morning, allow me to introduce myself.',
          'I am tired of exams.',
          'That car is very expensive.'
        ],
        correctAnswer: 0,
        explanation: '"If I were you, I would..." is the standard function phrase for giving advice.'
      }
    ]
  },

  // UNIT 2 QUIZ
  {
    unitId: 2,
    titleEn: 'Unit 2 Comprehensive Assessment: Choices & Change',
    titleAr: 'اختبار تقويمي شامل للوحدة الثانية: خيارات وتغيير',
    timeMinutes: 15,
    questions: [
      {
        id: 'q2-1',
        unitId: 2,
        type: 'vocab',
        question: 'Solar panels and wind turbines are clean __________ to burning fossil fuels.',
        questionAr: 'الألواح الشمسية وتوربينات الرياح هي ... نظيفة لحرق الوقود الأحفوري:',
        options: ['alternatives', 'emissions', 'landfills', 'tablets'],
        correctAnswer: 0,
        explanation: '"alternatives" are cleaner replacement options for fossil fuels.'
      },
      {
        id: 'q2-2',
        unitId: 2,
        type: 'vocab',
        question: 'Rather than throw old sweaters away, she transformed them by creative __________ into wool blankets.',
        questionAr: 'بدلاً من رمي السترات القديمة، قامت بتحويلها إلى بطانيات عبر:',
        options: ['upcycling', 'incineration', 'emission', 'mining'],
        correctAnswer: 0,
        explanation: '"upcycling" means transforming used materials into products of higher artistic or practical value.'
      },
      {
        id: 'q2-3',
        unitId: 2,
        type: 'grammar',
        question: 'Kuwait __________ (launch) several solar projects since 2015.',
        questionAr: 'اختر الصيغة الصحيحة للمضارع التام مع since 2015:',
        options: ['has launched', 'have launched', 'launched', 'is launching'],
        correctAnswer: 0,
        explanation: 'Present perfect with singular subject: "has launched".'
      },
      {
        id: 'q2-4',
        unitId: 2,
        type: 'grammar',
        question: 'If people take reusable bags to the supermarket, they __________ plastic waste.',
        questionAr: 'أكمل جملة الحالة الشرطية الأولى للتعبير عن نتيجة مؤكدة:',
        options: ['will reduce', 'reduced', 'would reduce', 'are reducing'],
        correctAnswer: 0,
        explanation: '1st conditional: If + present simple, will + base verb.'
      },
      {
        id: 'q2-5',
        unitId: 2,
        type: 'reading',
        question: 'Where is Kuwait’s Shagaya Renewable Energy Park located?',
        questionAr: 'أين يقع مجمع الشقايا للطاقة المتجددة في دولة الكويت؟',
        options: [
          'In a desert area west of Kuwait City',
          'On Failaka Island',
          'In the center of Souq Al-Mubarakiya',
          'Inside Kuwait Towers'
        ],
        correctAnswer: 0,
        explanation: 'Textbook page 34: "located in a desert area west of Kuwait City."'
      },
      {
        id: 'q2-6',
        unitId: 2,
        type: 'function',
        question: 'Your sibling leaves all room lights on during sunny daylight hours. How do you warn them?',
        questionAr: 'أخوك يترك أنوار الغرفة مضاءة نهاراً. كيف توجه له تحذيراً ونصحاً؟',
        options: [
          'Be careful! Leaving appliances on wastes electricity and increases unnecessary carbon emissions.',
          'My favourite food is grilled fish.',
          'Allow me to introduce my sister.',
          'I am going to buy a new laptop.'
        ],
        correctAnswer: 0,
        explanation: '"Be careful! Leaving... wastes..." functions as an appropriate warning.'
      }
    ]
  },

  // UNIT 3 QUIZ
  {
    unitId: 3,
    titleEn: 'Unit 3 Comprehensive Assessment: Exploring Heritage',
    titleAr: 'اختبار تقويمي شامل للوحدة الثالثة: استكشاف التراث',
    timeMinutes: 15,
    questions: [
      {
        id: 'q3-1',
        unitId: 3,
        type: 'vocab',
        question: 'The museum curator carefully showcased ancient Bronze Age __________ discovered on Failaka Island.',
        questionAr: 'عرض أمين المتحف بعناية ... الأثرية القديمة المكتشفة في جزيرة فيلكا:',
        options: ['artefacts', 'preservatives', 'turbines', 'linkers'],
        correctAnswer: 0,
        explanation: '"artefacts" are historical objects made by humans in antiquity.'
      },
      {
        id: 'q3-2',
        unitId: 3,
        type: 'vocab',
        question: 'Mohammad Al Sharekh __________ his life and resources to bringing Arabic into modern computing.',
        questionAr: 'كرّس محمد الشارخ حياته وموارده لإدخال اللغة العربية في الحاسوب:',
        options: ['devoted', 'buried', 'converted', 'consumed'],
        correctAnswer: 0,
        explanation: '"devoted" means gave all his time and energy to a noble cause.'
      },
      {
        id: 'q3-3',
        unitId: 3,
        type: 'grammar',
        question: 'Al Salam Palace Museum, __________ includes three unique historical sections, is unforgettable.',
        questionAr: 'اختر ضمير الوصل المناسب لجملة الوصل غير المحددة الخاصة بالأشياء:',
        options: ['which', 'who', 'whose', 'where'],
        correctAnswer: 0,
        explanation: '"which" is used for things in non-defining relative clauses.'
      },
      {
        id: 'q3-4',
        unitId: 3,
        type: 'grammar',
        question: 'While the tourists __________ (walk) around the Red Fort, they saw the historical watchtowers.',
        questionAr: 'اختر صيغة الماضي المناسبة بعد While:',
        options: ['were walking', 'walked', 'are walking', 'have walked'],
        correctAnswer: 0,
        explanation: 'Past continuous ("were walking") expresses an action in progress interrupted by seeing the towers.'
      },
      {
        id: 'q3-5',
        unitId: 3,
        type: 'reading',
        question: 'What educational company did Mohammad Al Sharekh found in 1982?',
        questionAr: 'ما هي الشركة الرائدة التي أسسها محمد الشارخ عام 1982؟',
        options: ['Sakhr Company', 'KISR', 'Sadu Society', 'Shagaya Energy'],
        correctAnswer: 0,
        explanation: 'In 1982, Mohammad Al Sharekh founded Sakhr Company for Arabic software and computing.'
      },
      {
        id: 'q3-6',
        unitId: 3,
        type: 'function',
        question: 'How would you express admiration for teacher Hamza Al Khayat’s contributions to Kuwaiti education?',
        questionAr: 'كيف تعبر عن إعجابك وتقديرك لإسهامات المعلم حمزة الخياط في التعليم الكويتي؟',
        options: [
          'What I find impressive is his dedication to writing "Learn the Hamza with Hamza" after 15 years of research.',
          'I doubt whether he lived in Kuwait.',
          'You should never write in Arabic.',
          'It is unlikely that books help.'
        ],
        correctAnswer: 0,
        explanation: '"What I find impressive is..." expresses admiration.'
      }
    ]
  },

  // UNIT 4 QUIZ
  {
    unitId: 4,
    titleEn: 'Unit 4 Comprehensive Assessment: Citizenship',
    titleAr: 'اختبار تقويمي شامل للوحدة الرابعة: المواطنة الفاعلة',
    timeMinutes: 15,
    questions: [
      {
        id: 'q4-1',
        unitId: 4,
        type: 'vocab',
        question: 'Active __________ entails respecting the law, volunteering in the community, and protecting public heritage.',
        questionAr: 'تتطلب ... الفاعلة احترام القانون والتطوع في المجتمع وصون التراث العام:',
        options: ['citizenship', 'malnutrition', 'incineration', 'stroll'],
        correctAnswer: 0,
        explanation: '"citizenship" is the state of being a citizen with duties and rights.'
      },
      {
        id: 'q4-2',
        unitId: 4,
        type: 'vocab',
        question: 'Mutual trust between the leadership and the people keeps Kuwait secure and __________.',
        questionAr: 'الثقة المتبادلة بين القيادة والشعب تبقي الكويت آمنة و ... :',
        options: ['stable', 'inactive', 'unnecessary', 'vacant'],
        correctAnswer: 0,
        explanation: '"stable" means firm, steady, and secure.'
      },
      {
        id: 'q4-3',
        unitId: 4,
        type: 'grammar',
        question: '“I will meet my friends at the Avenues tomorrow,” said Fahad. In reported speech:',
        questionAr: 'حول إلى كلام منقول: “I will meet my friends at the Avenues tomorrow,” said Fahad.',
        options: [
          'Fahad said that he would meet his friends at the Avenues the next day.',
          'Fahad said that I will meet my friends at the Avenues tomorrow.',
          'Fahad said that he meets his friends yesterday.',
          'Fahad said that he had met friends today.'
        ],
        correctAnswer: 0,
        explanation: 'I ➔ he, will ➔ would, tomorrow ➔ the next day.'
      },
      {
        id: 'q4-4',
        unitId: 4,
        type: 'grammar',
        question: 'Which of the following is correct regarding countable and uncountable nouns?',
        questionAr: 'أي من الجمل التالية صحيحة نحوياً بخصوص الأسماء المعدودة وغير المعدودة؟',
        options: [
          'The ministry provided schools with many buses for educational trips.',
          'The ministry provided schools with many advices.',
          'There are much books on the desk.',
          'She drank many water.'
        ],
        correctAnswer: 0,
        explanation: '"buses" is countable plural used correctly with "many". "Advice" and "water" are uncountable and cannot take -s or "many".'
      },
      {
        id: 'q4-5',
        unitId: 4,
        type: 'reading',
        question: 'In what year was the historic Constitution of the State of Kuwait signed by Sheikh Abdullah Al-Salem?',
        questionAr: 'في أي عام تم توقيع دستور دولة الكويت التاريخي من قبل الشيخ عبد الله السالم؟',
        options: ['1962', '1961', '1930', '1899'],
        correctAnswer: 0,
        explanation: 'Timeline page 66 confirms Sheikh Abdullah Al-Salem signed the Constitution in 1962.'
      },
      {
        id: 'q4-6',
        unitId: 4,
        type: 'function',
        question: 'Someone suggests that exam regulations are too strict. How do you disagree politely and justify?',
        questionAr: 'شخص يقول إن لوائح الامتحانات صارمة جداً. كيف تختلف معه بأدب وتعطيه تبريراً؟',
        options: [
          'I respect your opinion, but these regulations safeguard fairness and academic integrity for every student.',
          'You are completely wrong and I will not speak to you.',
          'Hello, my name is Bader.',
          'I prefer drinking cold tea.'
        ],
        correctAnswer: 0,
        explanation: '"I respect your opinion, but..." is the textbook standard for disagreeing politely with justification.'
      }
    ]
  }
];

export const FINAL_MOCK_EXAM: UnitQuiz = {
  unitId: 99,
  titleEn: 'Origin to Outlook (Grade 10A) – Comprehensive Final Examination',
  titleAr: 'الاختبار النهائي الشامل لمنهج الصف العاشر (Origin to Outlook - 2026/2027)',
  timeMinutes: 45,
  questions: [
    {
      id: 'fe-1',
      unitId: 1,
      type: 'vocab',
      question: 'Doctors advise patients to __________ halloumi cheese in water before cooking to reduce sodium.',
      options: ['soak', 'subsidise', 'manufacture', 'bury'],
      correctAnswer: 0,
      explanation: '"soak" means to immerse in water.'
    },
    {
      id: 'fe-2',
      unitId: 1,
      type: 'grammar',
      question: 'Which of the following is the correct order of adjectives for a traditional Kuwaiti item?',
      options: [
        'a beautiful small antique Kuwaiti wooden box',
        'a wooden antique beautiful small Kuwaiti box',
        'a Kuwaiti small antique beautiful wooden box',
        'a small beautiful wooden antique Kuwaiti box'
      ],
      correctAnswer: 0,
      explanation: 'Opinion (beautiful) ➔ Size (small) ➔ Age (antique) ➔ Origin (Kuwaiti) ➔ Material (wooden).'
    },
    {
      id: 'fe-3',
      unitId: 2,
      type: 'vocab',
      question: 'Kuwait aims to produce 15% of its power from renewable sources before fossil fuels __________ completely.',
      options: ['run out', 'add up', 'make over', 'pass down'],
      correctAnswer: 0,
      explanation: '"run out" means to become exhausted or completely used up.'
    },
    {
      id: 'fe-4',
      unitId: 2,
      type: 'grammar',
      question: 'If organisations invest in solar technology, they __________ save millions in fuel costs.',
      options: ['can', 'could have', 'would', 'are'],
      correctAnswer: 0,
      explanation: '1st conditional expresses real ability/outcome with "can" or "will".'
    },
    {
      id: 'fe-5',
      unitId: 3,
      type: 'vocab',
      question: 'Ancient maritime traditions are __________ from grandfathers to grandsons in Kuwait.',
      options: ['passed down', 'tucked away', 'disposed of', 'broken down'],
      correctAnswer: 0,
      explanation: '"passed down" means transmitted across generations.'
    },
    {
      id: 'fe-6',
      unitId: 3,
      type: 'grammar',
      question: 'Failaka Island, __________ is an ancient archaeological site, has evidence of human life since 2000 BC.',
      options: ['which', 'that', 'who', 'whose'],
      correctAnswer: 0,
      explanation: 'Non-defining relative clauses describing things/places surrounded by commas must use "which", never "that".'
    },
    {
      id: 'fe-7',
      unitId: 4,
      type: 'vocab',
      question: 'The surviving structure of the Qurain Martyrs’ House is an immortal __________ of heroic sacrifice.',
      options: ['monument', 'emission', 'legume', 'incineration'],
      correctAnswer: 0,
      explanation: 'A "monument" commemorates historical sacrifice and national heroes.'
    },
    {
      id: 'fe-8',
      unitId: 4,
      type: 'grammar',
      question: '“We visited the national museum yesterday,” said the students. ➔ The students said that they __________ the museum the day before.',
      options: ['had visited', 'visited', 'visit', 'would visit'],
      correctAnswer: 0,
      explanation: 'Past simple ("visited") shifts to past perfect ("had visited") in reported speech.'
    },
    {
      id: 'fe-9',
      unitId: 4,
      type: 'grammar',
      question: 'Can you give me __________ on how to write the expository essay?',
      options: ['some advice', 'an advice', 'many advices', 'few advices'],
      correctAnswer: 0,
      explanation: '"advice" is uncountable and cannot take an indefinite article or plural -s.'
    },
    {
      id: 'fe-10',
      unitId: 4,
      type: 'function',
      question: 'What do you say when you want to express strong obligation towards your country?',
      options: [
        'We have an obligation and duty to safeguard Kuwait’s safety and unity.',
        'I am not sure if that is a good plan.',
        'It is very cold outside.',
        'Would you like some tea?'
      ],
      correctAnswer: 0,
      explanation: '"We have an obligation and duty to..." expresses civic necessity and obligation.'
    }
  ]
};
