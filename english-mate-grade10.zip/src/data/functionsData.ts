import { LanguageFunction } from '../types';

export const LANGUAGE_FUNCTIONS: LanguageFunction[] = [
  {
    id: 'intro-oneself',
    categoryEn: 'Introducing oneself',
    categoryAr: 'التعريف بالنفس',
    page: 93,
    expressions: [
      'Good morning, my name is...',
      'Hello, I would like to introduce myself. I am...',
      'Allow me to introduce myself, my name is...'
    ],
    exampleDialogue: {
      speakerA: 'Student',
      textA: 'Good morning, my name is Salem from Grade 10A.',
      speakerB: 'Teacher',
      textB: 'Welcome Salem! We are thrilled to hear your presentation on Kuwaiti heritage today.'
    }
  },
  {
    id: 'expr-opinion',
    categoryEn: 'Expressing opinion',
    categoryAr: 'إبداء الرأي',
    page: 93,
    expressions: [
      'I think it’s incredible...',
      'In my opinion…',
      'Personally, I believe that…',
      'From my point of view, ...',
      'It seems to me that...'
    ],
    exampleDialogue: {
      speakerA: 'Ahmad',
      textA: 'In my opinion, renewable solar energy is essential for Kuwait’s future.',
      speakerB: 'Bader',
      textB: 'Personally, I believe that combining solar panels with wind turbines provides the best balance.'
    }
  },
  {
    id: 'expr-pref',
    categoryEn: 'Expressing preferences',
    categoryAr: 'التعبير عن التفضيلات',
    page: 93,
    expressions: [
      'I prefer to... because...',
      'I choose... because...',
      'The best thing about…',
      'It is my favourite…',
      'I always come back to... because…'
    ],
    exampleDialogue: {
      speakerA: 'Maryam',
      textA: 'I prefer to pack fresh fruit instead of processed snacks because it keeps my energy steady.',
      speakerB: 'Haya',
      textB: 'Dates with almonds are my favourite choice for a healthy school lunchbox.'
    }
  },
  {
    id: 'adv-disadv',
    categoryEn: 'Stating advantages and disadvantages',
    categoryAr: 'ذكر المزايا والعيوب',
    page: 93,
    expressions: [
      'This choice is/ isn’t...',
      'The best… / the worst…',
      'A major advantage/ disadvantage is...'
    ],
    exampleDialogue: {
      speakerA: 'Khaled',
      textA: 'A major advantage of school-provided lunches is ensuring equality among all pupils.',
      speakerB: 'Omar',
      textB: 'On the other hand, the disadvantage is that it leaves less room for personalized diets.'
    }
  },
  {
    id: 'expand-ideas',
    categoryEn: 'Expanding on ideas',
    categoryAr: 'التوسع في طرح الأفكار',
    page: 93,
    expressions: [
      'Another important point is…',
      'A further example is…',
      'An additional idea is…',
      'It is also important to note…',
      'Another way to look at this is…',
      'This can be explained by…'
    ],
    exampleDialogue: {
      speakerA: 'Fatima',
      textA: 'Thrifting reduces industrial emissions. Another important point is that it saves household money.',
      speakerB: 'Nouf',
      textB: 'A further example is upcycling discarded furniture into modern decorative art.'
    }
  },
  {
    id: 'giving-advice',
    categoryEn: 'Giving advice',
    categoryAr: 'تقديم النصيحة',
    page: 93,
    expressions: [
      'I would advise you to...',
      'If I were you, I would...',
      'We should...',
      'We can...',
      'This will help because...'
    ],
    exampleDialogue: {
      speakerA: 'Tariq',
      textA: 'I often feel drowsy after eating lunch during study time.',
      speakerB: 'Doctor',
      textB: 'I would advise you to swap greasy fast food with a balanced salad and grilled chicken.'
    }
  },
  {
    id: 'making-decision',
    categoryEn: 'Making a decision',
    categoryAr: 'اتخاذ قرار',
    page: 93,
    expressions: [
      'We have decided to…',
      'The most realistic change is…',
      'After careful thinking, I have decided to…',
      'This choice makes sense because…'
    ],
    exampleDialogue: {
      speakerA: 'Student Council',
      textA: 'After careful thinking, we have decided to install recycling bins across all school floors.',
      speakerB: 'Principal',
      textB: 'This choice makes sense because it actively engages students in environmental responsibility.'
    }
  },
  {
    id: 'giving-suggestions',
    categoryEn: 'Giving suggestions',
    categoryAr: 'تقديم الاقتراحات',
    page: 93,
    expressions: [
      'I/ we suggest (that)…',
      'The best option would be to…',
      'We should all consider…',
      'A better suggestion is…',
      'We could try...'
    ],
    exampleDialogue: {
      speakerA: 'Yousef',
      textA: 'We could try creating an online digital diwan for recording our grandparents’ stories.',
      speakerB: 'Zaid',
      textB: 'That sounds great! I suggest we also film short clips for school social media.'
    }
  },
  {
    id: 'agree-suggest',
    categoryEn: 'Agreeing with a suggestion',
    categoryAr: 'الموافقة على اقتراح',
    page: 93,
    expressions: [
      'That’s a good idea.',
      'That sounds great!',
      'I agree with you.',
      'Brilliant idea!'
    ],
    exampleDialogue: {
      speakerA: 'Dana',
      textA: 'Why don’t we organize a clean-up campaign at Shuwaikh beach this Saturday?',
      speakerB: 'Lulwa',
      textB: 'Brilliant idea! I will invite the environmental club members.'
    }
  },
  {
    id: 'expr-obligation',
    categoryEn: 'Expressing obligation and necessity',
    categoryAr: 'التعبير عن الإلزام والضرورة',
    page: 93,
    expressions: [
      'It is necessary to…',
      'We must/have to protect…',
      'We have an obligation to…',
      'We have a responsibility to...'
    ],
    exampleDialogue: {
      speakerA: 'Speaker',
      textA: 'We have an obligation to safeguard our historic architecture and oral traditions.',
      speakerB: 'Listener',
      textB: 'Indeed, it is necessary to teach younger generations the values of our ancestors.'
    }
  },
  {
    id: 'stating-purpose',
    categoryEn: 'Stating purpose',
    categoryAr: 'بيان الهدف والغاية',
    page: 94,
    expressions: [
      'The aim is to…',
      'I plan to...',
      'I want to reduce...',
      'I will try to stop...',
      'My goal is...'
    ],
    exampleDialogue: {
      speakerA: 'Researcher',
      textA: 'The aim is to achieve 15% renewable energy production in Kuwait by 2030.',
      speakerB: 'Engineer',
      textB: 'Our goal is to expand solar and wind facilities at Shagaya Energy Park.'
    }
  },
  {
    id: 'giving-warning',
    categoryEn: 'Giving a warning',
    categoryAr: 'توجيه التحذير',
    page: 94,
    expressions: [
      'Be careful...',
      'Watch out for...',
      'You should never...',
      'Avoid... or you will regret it.',
      'It’s better not to...'
    ],
    exampleDialogue: {
      speakerA: 'Nutritionist',
      textA: 'Watch out for food advertisements using health tricks like "farm-fresh" on high-sugar items.',
      speakerB: 'Teenager',
      textB: 'Thank you! It is better to read the nutrition facts label carefully.'
    }
  },
  {
    id: 'disagree-politely',
    categoryEn: 'To disagree politely',
    categoryAr: 'الاختلاف بأدب ولباقة',
    page: 94,
    expressions: [
      'I respect your opinion, but...',
      'I see your point, however...',
      'I can see your idea, but I believe...',
      'That may be true, but let me explain...'
    ],
    exampleDialogue: {
      speakerA: 'Ali',
      textA: 'Traditional diets are outdated and no longer fit our modern lifestyle.',
      speakerB: 'Hamad',
      textB: 'I respect your opinion, but the pearl-divers’ balanced diet of fish, dates, and rice was much healthier.'
    }
  },
  {
    id: 'agree-justify',
    categoryEn: 'To agree and give justification',
    categoryAr: 'الموافقة مع التعليل',
    page: 94,
    expressions: [
      'I agree with you because...',
      'You are right about...',
      'That is true because...'
    ],
    exampleDialogue: {
      speakerA: 'Nour',
      textA: 'School regulations are vital for creating a secure learning atmosphere.',
      speakerB: 'Sara',
      textB: 'You are right about that, because without clear guidelines, chaos would disrupt our studies.'
    }
  },
  {
    id: 'expr-admiration',
    categoryEn: 'Expressing admiration',
    categoryAr: 'التعبير عن الإعجاب والتقدير',
    page: 94,
    expressions: [
      'I admire... because...',
      'What I find impressive is...',
      'I really appreciate how...',
      'This inspires me because...',
      'This motivates me because...',
      'This encourages me because...'
    ],
    exampleDialogue: {
      speakerA: 'Student',
      textA: 'I really admire Mohammad Al Sharekh because he brought the Arabic language to digital computing.',
      speakerB: 'Teacher',
      textB: 'What I find impressive is his dedication to publishing free cultural encyclopedias for all.'
    }
  },
  {
    id: 'asking-clarification',
    categoryEn: 'Asking for clarification',
    categoryAr: 'طلب التوضيح والاستفسار',
    page: 94,
    expressions: [
      'Can you explain more about...?',
      'Could you make this point clearer?',
      'What do you mean by...?',
      'Sorry, could you explain...?',
      'Do you mean that...?'
    ],
    exampleDialogue: {
      speakerA: 'Student',
      textA: 'Could you make this point clearer? What do you mean by "nutritional psychiatry"?',
      speakerB: 'Teacher',
      textB: 'Certainly! It refers to the scientific relationship between food quality and brain and emotional health.'
    }
  }
];
