/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { Dashboard } from './components/Dashboard';
import { UnitsView } from './components/UnitsView';
import { GlossaryView } from './components/GlossaryView';
import { GrammarCenterView } from './components/GrammarCenterView';
import { LanguageFunctionsView } from './components/LanguageFunctionsView';
import { SkillsHubView } from './components/SkillsHubView';
import { QuizzesView } from './components/QuizzesView';
import { ReviewExamView } from './components/ReviewExamView';
import { StudentProfileView } from './components/StudentProfileView';
import { AiTutorModal } from './components/AiTutorModal';
import { Bot, Sparkles } from 'lucide-react';

const MainContent: React.FC = () => {
  const { currentSection, setIsAiModalOpen, language } = useApp();
  const isAr = language === 'ar';

  const renderSection = () => {
    switch (currentSection) {
      case 'dashboard':
        return <Dashboard />;
      case 'units':
        return <UnitsView />;
      case 'glossary':
        return <GlossaryView />;
      case 'grammar':
        return <GrammarCenterView />;
      case 'functions':
        return <LanguageFunctionsView />;
      case 'skills':
        return <SkillsHubView />;
      case 'quizzes':
        return <QuizzesView />;
      case 'review':
        return <ReviewExamView />;
      case 'profile':
        return <StudentProfileView />;
      default:
        return <Dashboard />;
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 transition-colors">
      <Navbar />

      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {renderSection()}
      </main>

      {/* Floating AI Assistant Button */}
      <aside aria-label="AI Assistant Quick Access">
        <button
          onClick={() => setIsAiModalOpen(true)}
          className="fixed bottom-6 right-6 z-30 flex items-center gap-2.5 px-4 py-3 rounded-2xl bg-gradient-to-r from-violet-600 via-indigo-600 to-purple-600 hover:from-violet-500 hover:to-indigo-500 text-white font-bold text-xs sm:text-sm shadow-xl shadow-indigo-600/30 hover:shadow-indigo-600/50 hover:scale-105 active:scale-95 transition-all cursor-pointer"
          aria-label={isAr ? 'المساعد الذكي للغة الإنجليزية' : 'AI Tutor'}
        >
          <Bot className="w-5 h-5 text-amber-300" />
          <span className="hidden sm:inline">{isAr ? 'اسأل المساعد الذكي' : 'AI English Tutor'}</span>
          <span className="flex h-2 w-2 rounded-full bg-emerald-400 animate-ping" />
        </button>
      </aside>

      <AiTutorModal />
      <Footer />
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <MainContent />
    </AppProvider>
  );
}
