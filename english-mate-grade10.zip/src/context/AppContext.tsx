import React, { createContext, useContext, useState, useEffect } from 'react';
import { Language, Theme, StudentProgress } from '../types';

export type AppSection =
  | 'dashboard'
  | 'units'
  | 'glossary'
  | 'grammar'
  | 'functions'
  | 'skills'
  | 'quizzes'
  | 'review'
  | 'profile'
  | 'ai-tutor';

interface AppContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  theme: Theme;
  toggleTheme: () => void;
  currentSection: AppSection;
  setCurrentSection: (section: AppSection) => void;
  selectedUnitId: number;
  setSelectedUnitId: (id: number) => void;
  selectedLessonId: string | null;
  setSelectedLessonId: (id: string | null) => void;
  student: StudentProgress;
  updateStudent: (updates: Partial<StudentProgress>) => void;
  markLessonComplete: (lessonId: string) => void;
  saveQuizScore: (quizId: string, score: number, total: number) => void;
  toggleBookmark: (id: string) => void;
  speakText: (text: string, lang?: string) => void;
  isAiModalOpen: boolean;
  setIsAiModalOpen: (open: boolean) => void;
}

const DEFAULT_STUDENT: StudentProgress = {
  name: 'طالب الصف العاشر',
  school: 'منطقة العاصمة التعليمية - دولة الكويت',
  avatar: '🎓',
  completedLessons: ['u1-l1', 'u1-l2'],
  completedQuizzes: {},
  savedNotes: {},
  bookmarks: ['nutritious', 'present-simple-adverbs'],
  totalScore: 120,
};

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [language, setLanguageState] = useState<Language>(() => {
    const saved = localStorage.getItem('em_lang');
    return saved === 'en' ? 'en' : 'ar';
  });

  const [theme, setThemeState] = useState<Theme>(() => {
    const saved = localStorage.getItem('em_theme');
    if (saved === 'dark' || saved === 'light') return saved;
    return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
  });

  const [currentSection, setCurrentSection] = useState<AppSection>('dashboard');
  const [selectedUnitId, setSelectedUnitId] = useState<number>(1);
  const [selectedLessonId, setSelectedLessonId] = useState<string | null>(null);
  const [isAiModalOpen, setIsAiModalOpen] = useState<boolean>(false);

  const [student, setStudent] = useState<StudentProgress>(() => {
    const saved = localStorage.getItem('em_student_progress');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error(e);
      }
    }
    return DEFAULT_STUDENT;
  });

  // Keep localStorage & document root updated
  useEffect(() => {
    localStorage.setItem('em_lang', language);
    document.documentElement.lang = language;
    document.documentElement.dir = language === 'ar' ? 'rtl' : 'ltr';
  }, [language]);

  useEffect(() => {
    localStorage.setItem('em_theme', theme);
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [theme]);

  useEffect(() => {
    localStorage.setItem('em_student_progress', JSON.stringify(student));
  }, [student]);

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
  };

  const toggleTheme = () => {
    setThemeState((prev) => (prev === 'light' ? 'dark' : 'light'));
  };

  const updateStudent = (updates: Partial<StudentProgress>) => {
    setStudent((prev) => ({ ...prev, ...updates }));
  };

  const markLessonComplete = (lessonId: string) => {
    setStudent((prev) => {
      if (prev.completedLessons.includes(lessonId)) return prev;
      return {
        ...prev,
        completedLessons: [...prev.completedLessons, lessonId],
        totalScore: prev.totalScore + 15,
      };
    });
  };

  const saveQuizScore = (quizId: string, score: number, total: number) => {
    setStudent((prev) => {
      const currentQuiz = prev.completedQuizzes[quizId];
      const highestScore = currentQuiz ? Math.max(currentQuiz.score, score) : score;
      const additionalPoints = Math.round((score / total) * 50);

      return {
        ...prev,
        completedQuizzes: {
          ...prev.completedQuizzes,
          [quizId]: {
            score: highestScore,
            total,
            date: new Date().toLocaleDateString(language === 'ar' ? 'ar-KW' : 'en-GB'),
          },
        },
        totalScore: prev.totalScore + additionalPoints,
      };
    });
  };

  const toggleBookmark = (id: string) => {
    setStudent((prev) => {
      const exists = prev.bookmarks.includes(id);
      return {
        ...prev,
        bookmarks: exists ? prev.bookmarks.filter((b) => b !== id) : [...prev.bookmarks, id],
      };
    });
  };

  // Text-to-Speech function for pronunciation practice
  const speakText = (text: string, lang = 'en-US') => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = lang;
      utterance.rate = 0.9; // clear educational cadence
      window.speechSynthesis.speak(utterance);
    }
  };

  return (
    <AppContext.Provider
      value={{
        language,
        setLanguage,
        theme,
        toggleTheme,
        currentSection,
        setCurrentSection,
        selectedUnitId,
        setSelectedUnitId,
        selectedLessonId,
        setSelectedLessonId,
        student,
        updateStudent,
        markLessonComplete,
        saveQuizScore,
        toggleBookmark,
        speakText,
        isAiModalOpen,
        setIsAiModalOpen,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) throw new Error('useApp must be used within an AppProvider');
  return context;
};
