import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { UNIT_QUIZZES } from '../data/quizzesData';
import {
  CheckCircle2,
  XCircle,
  HelpCircle,
  RotateCcw,
  Trophy,
  Award,
  Sparkles,
  ArrowRight,
  ArrowLeft,
} from 'lucide-react';
import confetti from 'canvas-confetti';

export const QuizzesView: React.FC = () => {
  const { language, saveQuizScore, student, setCurrentSection } = useApp();
  const isAr = language === 'ar';
  const ArrowIcon = isAr ? ArrowLeft : ArrowRight;

  const [activeUnitId, setActiveUnitId] = useState<number>(1);
  const [userAnswers, setUserAnswers] = useState<Record<string, number>>({});
  const [isSubmitted, setIsSubmitted] = useState<boolean>(false);

  const currentQuiz = UNIT_QUIZZES.find((q) => q.unitId === activeUnitId) || UNIT_QUIZZES[0];

  const handleSelectOption = (questionId: string, optionIdx: number) => {
    if (isSubmitted) return;
    setUserAnswers((prev) => ({ ...prev, [questionId]: optionIdx }));
  };

  const calculateScore = () => {
    let score = 0;
    currentQuiz.questions.forEach((q) => {
      if (userAnswers[q.id] === q.correctAnswer) {
        score += 1;
      }
    });
    return score;
  };

  const handleSubmit = () => {
    const score = calculateScore();
    setIsSubmitted(true);
    saveQuizScore(`quiz-u${currentQuiz.unitId}`, score, currentQuiz.questions.length);

    if (score >= currentQuiz.questions.length * 0.7) {
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 },
      });
    }
  };

  const handleReset = () => {
    setUserAnswers({});
    setIsSubmitted(false);
  };

  const score = calculateScore();
  const total = currentQuiz.questions.length;
  const percentage = Math.round((score / total) * 100);

  return (
    <div className="space-y-8 animate-fadeIn">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-100 dark:bg-emerald-950/80 text-emerald-800 dark:text-emerald-300 text-xs font-bold border border-emerald-300 dark:border-emerald-800 mb-2">
            <Trophy className="w-3.5 h-3.5" />
            <span>{isAr ? 'اختبارات تقييمية تفاعلية لكل وحدة' : 'Interactive Unit Assessments'}</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white">
            {isAr ? 'منصة الاختبارات والتقييم' : 'Unit Quizzes & Assessments'}
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400">
            {isAr
              ? 'اختبارات تشمل المفردات، القواعد، أسئلة الفهم والوظائف اللغوية مع التصحيح الفوري'
              : 'Assessments covering Vocabulary, Grammar, Reading Comprehension, and Functions with instant feedback'}
          </p>
        </div>

        <button
          onClick={() => {
            setCurrentSection('review');
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 text-slate-800 dark:text-slate-200 text-xs font-bold hover:bg-white dark:hover:bg-slate-800 transition-colors cursor-pointer self-start sm:self-auto"
        >
          <span>{isAr ? 'الانتقال للاختبار النهائي الشامل' : 'Full Final Mock Exam'}</span>
          <ArrowIcon className="w-4 h-4" />
        </button>
      </div>

      {/* Unit Selector Tabs */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {UNIT_QUIZZES.map((quiz) => {
          const isSelected = quiz.unitId === activeUnitId;
          const savedResult = student.completedQuizzes[`quiz-u${quiz.unitId}`];
          return (
            <button
              key={quiz.unitId}
              onClick={() => {
                setActiveUnitId(quiz.unitId);
                handleReset();
              }}
              className={`p-4 rounded-2xl text-start transition-all cursor-pointer border ${
                isSelected
                  ? 'bg-emerald-600 text-white border-emerald-600 shadow-lg shadow-emerald-600/20'
                  : 'bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-800 hover:border-emerald-500/50'
              }`}
            >
              <div className="flex items-center justify-between mb-1">
                <span className={`text-[11px] font-black uppercase ${isSelected ? 'text-emerald-200' : 'text-slate-400'}`}>
                  {isAr ? `الوحدة ${quiz.unitId}` : `Unit ${quiz.unitId}`}
                </span>
                {savedResult && (
                  <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded-full ${isSelected ? 'bg-white/20 text-white' : 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'}`}>
                    {savedResult.score}/{savedResult.total}
                  </span>
                )}
              </div>
              <h3 className="font-extrabold text-xs sm:text-sm line-clamp-1">
                {isAr ? quiz.titleAr : quiz.titleEn}
              </h3>
            </button>
          );
        })}
      </div>

      {/* Results Banner if Submitted */}
      {isSubmitted && (
        <div className="p-6 sm:p-8 rounded-3xl bg-gradient-to-r from-emerald-600 via-teal-600 to-cyan-600 text-white shadow-xl flex flex-col sm:flex-row items-center justify-between gap-6 animate-fadeIn">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-2xl bg-white/20 backdrop-blur-md flex items-center justify-center text-white flex-shrink-0">
              <Trophy className="w-9 h-9 text-amber-300" />
            </div>
            <div>
              <span className="text-xs font-bold text-emerald-200 uppercase tracking-widest block">
                {isAr ? 'نتيجة الاختبار' : 'Quiz Result'}
              </span>
              <h3 className="text-2xl sm:text-3xl font-black">
                {score} / {total} ({percentage}%)
              </h3>
              <p className="text-xs text-emerald-100 mt-1">
                {percentage >= 90
                  ? (isAr ? 'ممتاز وعبقري! لقد حصلت على الدرجة الكاملة تقريباً 🌟' : 'Outstanding mastery! Near perfect score 🌟')
                  : percentage >= 70
                  ? (isAr ? 'أحسنت! أداء رائع جداً، راجع التوضيحات بالأسفل لتقوية نقاطك.' : 'Great performance! Review the explanations below.')
                  : (isAr ? 'أداء جيد، ننصحك بمراجعة نصوص وقواعد الوحدة وإعادة المحاولة.' : 'Good effort, consider reviewing the unit materials and retrying.')}
              </p>
            </div>
          </div>

          <button
            onClick={handleReset}
            className="inline-flex items-center gap-2 px-5 py-3 rounded-2xl bg-white text-slate-900 font-black text-xs sm:text-sm hover:bg-slate-100 shadow-md cursor-pointer transition-transform active:scale-95 flex-shrink-0"
          >
            <RotateCcw className="w-4 h-4" />
            <span>{isAr ? 'إعادة المحاولة' : 'Retake Quiz'}</span>
          </button>
        </div>
      )}

      {/* Questions List */}
      <div className="space-y-6">
        {currentQuiz.questions.map((q, idx) => {
          const selected = userAnswers[q.id];
          const isCorrect = selected === q.correctAnswer;

          return (
            <div
              key={q.id}
              className={`p-6 sm:p-7 rounded-3xl bg-white dark:bg-slate-900 border transition-all ${
                isSubmitted
                  ? isCorrect
                    ? 'border-emerald-500/50 dark:border-emerald-500/40 bg-emerald-50/10'
                    : 'border-rose-500/50 dark:border-rose-500/40 bg-rose-50/10'
                  : 'border-slate-200 dark:border-slate-800'
              }`}
            >
              <div className="flex items-start justify-between gap-3 mb-4">
                <div className="flex items-start gap-3">
                  <span className="w-7 h-7 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-black text-xs flex items-center justify-center flex-shrink-0">
                    {idx + 1}
                  </span>
                  <div>
                    <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 text-slate-500 mb-1 inline-block">
                      {q.type}
                    </span>
                    <h3 className="text-sm sm:text-base font-bold text-slate-900 dark:text-white">
                      {q.question}
                    </h3>
                    {isAr && q.questionAr && (
                      <p className="text-xs text-slate-400 mt-1">{q.questionAr}</p>
                    )}
                  </div>
                </div>

                {isSubmitted && (
                  <div className="flex-shrink-0">
                    {isCorrect ? (
                      <span className="inline-flex items-center gap-1 text-xs font-black text-emerald-600 dark:text-emerald-400">
                        <CheckCircle2 className="w-5 h-5" />
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 text-xs font-black text-rose-600 dark:text-rose-400">
                        <XCircle className="w-5 h-5" />
                      </span>
                    )}
                  </div>
                )}
              </div>

              {/* Options */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-2">
                {q.options.map((opt, oIdx) => {
                  const isThisSelected = selected === oIdx;
                  let btnStyle =
                    'bg-slate-50 dark:bg-slate-800/60 border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-200 hover:border-emerald-500';

                  if (isThisSelected) {
                    btnStyle = 'bg-emerald-100 dark:bg-emerald-950/80 border-emerald-500 text-emerald-900 dark:text-emerald-100 font-bold';
                  }

                  if (isSubmitted) {
                    if (oIdx === q.correctAnswer) {
                      btnStyle = 'bg-emerald-500 text-white border-emerald-600 font-bold';
                    } else if (isThisSelected && !isCorrect) {
                      btnStyle = 'bg-rose-500 text-white border-rose-600 font-bold';
                    } else {
                      btnStyle = 'bg-slate-100 dark:bg-slate-800 text-slate-400 border-transparent opacity-60';
                    }
                  }

                  return (
                    <button
                      key={oIdx}
                      disabled={isSubmitted}
                      onClick={() => handleSelectOption(q.id, oIdx)}
                      className={`p-3.5 rounded-2xl text-xs sm:text-sm text-start font-medium border transition-all cursor-pointer ${btnStyle}`}
                    >
                      <div className="flex items-center gap-2">
                        <span className="w-5 h-5 rounded-full border border-current flex items-center justify-center text-[10px] flex-shrink-0">
                          {String.fromCharCode(65 + oIdx)}
                        </span>
                        <span>{opt}</span>
                      </div>
                    </button>
                  );
                })}
              </div>

              {/* Detailed Explanation on submit */}
              {isSubmitted && (
                <div
                  className={`mt-4 p-4 rounded-2xl text-xs leading-relaxed ${
                    isCorrect
                      ? 'bg-emerald-100/70 text-emerald-900 dark:bg-emerald-950/40 dark:text-emerald-200 border border-emerald-200 dark:border-emerald-800'
                      : 'bg-rose-100/70 text-rose-900 dark:bg-rose-950/40 dark:text-rose-200 border border-rose-200 dark:border-rose-800'
                  }`}
                >
                  <p className="font-bold mb-1">
                    {isCorrect
                      ? (isAr ? 'إجابة صحيحة! أحسنت:' : 'Correct Answer:')
                      : (isAr ? 'توضيح الإجابة الصحيحة من كتاب الطالب:' : 'Explanation from Textbook:')}
                  </p>
                  <p>{q.explanation}</p>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Submit Button */}
      {!isSubmitted && (
        <div className="sticky bottom-6 z-20 flex justify-center">
          <button
            onClick={handleSubmit}
            disabled={Object.keys(userAnswers).length === 0}
            className={`inline-flex items-center gap-2 px-8 py-4 rounded-2xl text-sm font-black shadow-xl transition-all cursor-pointer ${
              Object.keys(userAnswers).length === currentQuiz.questions.length
                ? 'bg-emerald-500 hover:bg-emerald-400 text-slate-950 shadow-emerald-500/30 scale-105 active:scale-95'
                : 'bg-slate-900 hover:bg-slate-800 text-white dark:bg-emerald-600 dark:hover:bg-emerald-500'
            }`}
          >
            <CheckCircle2 className="w-5 h-5" />
            <span>
              {isAr
                ? `تسليم الإجابات وعرض النتيجة (${Object.keys(userAnswers).length} من ${total})`
                : `Submit Quiz & View Results (${Object.keys(userAnswers).length}/${total})`}
            </span>
          </button>
        </div>
      )}
    </div>
  );
};
