import React, { useState } from 'react';
import { useApp, AppSection } from '../context/AppContext';
import {
  Home,
  BookOpen,
  BookA,
  Sparkles,
  MessageSquare,
  PenTool,
  CheckCircle,
  FileText,
  User,
  Bot,
  Sun,
  Moon,
  Languages,
  Menu,
  X,
} from 'lucide-react';

export const Navbar: React.FC = () => {
  const {
    language,
    setLanguage,
    theme,
    toggleTheme,
    currentSection,
    setCurrentSection,
    setIsAiModalOpen,
    student,
  } = useApp();

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const isAr = language === 'ar';

  const navItems: { id: AppSection; labelEn: string; labelAr: string; icon: any }[] = [
    { id: 'dashboard', labelEn: 'Dashboard', labelAr: 'الرئيسية', icon: Home },
    { id: 'units', labelEn: 'Units & Lessons', labelAr: 'الوحدات والدروس', icon: BookOpen },
    { id: 'glossary', labelEn: 'Glossary', labelAr: 'القاموس', icon: BookA },
    { id: 'grammar', labelEn: 'Grammar Center', labelAr: 'مركز القواعد (9)', icon: Sparkles },
    { id: 'functions', labelEn: 'Functions Bank', labelAr: 'الوظائف اللغوية', icon: MessageSquare },
    { id: 'skills', labelEn: 'Skills Hub', labelAr: 'المهارات الأربع', icon: PenTool },
    { id: 'quizzes', labelEn: 'Interactive Quizzes', labelAr: 'الاختبارات', icon: CheckCircle },
    { id: 'review', labelEn: 'Comprehensive Review', labelAr: 'المراجعة الشاملة', icon: FileText },
    { id: 'profile', labelEn: 'Student Profile', labelAr: 'حساب الطالب', icon: User },
  ];

  const handleNavClick = (sectionId: AppSection) => {
    setCurrentSection(sectionId);
    setMobileMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <header className="sticky top-0 z-40 w-full border-b border-slate-200/80 dark:border-slate-800/80 bg-white/90 dark:bg-slate-900/90 backdrop-blur-md transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-20">
          {/* Logo & Brand */}
          <button
            onClick={() => handleNavClick('dashboard')}
            className="flex items-center gap-3 text-start group cursor-pointer focus:outline-none"
          >
            <div className="w-10 h-10 sm:w-11 sm:h-11 rounded-xl bg-gradient-to-tr from-emerald-600 via-teal-600 to-cyan-600 flex items-center justify-center text-white shadow-md shadow-emerald-600/20 group-hover:scale-105 transition-transform">
              <span className="font-black text-lg">10A</span>
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-extrabold text-base sm:text-lg tracking-tight text-slate-900 dark:text-white">
                  English Mate
                </span>
                <span className="text-xs px-2 py-0.5 rounded-md font-bold bg-emerald-100 text-emerald-800 dark:bg-emerald-950/80 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-800">
                  Grade 10
                </span>
              </div>
              <p className="text-[11px] text-slate-500 dark:text-slate-400 font-medium">
                {isAr ? 'منهج Origin to Outlook – دولة الكويت' : 'Kuwait Curriculum 2026/2027'}
              </p>
            </div>
          </button>

          {/* Desktop Navigation */}
          <nav className="hidden xl:flex items-center gap-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = currentSection === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => handleNavClick(item.id)}
                  className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                    isActive
                      ? 'bg-emerald-500 text-white shadow-sm shadow-emerald-500/25'
                      : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800/60'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span>{isAr ? item.labelAr : item.labelEn}</span>
                </button>
              );
            })}
          </nav>

          {/* Controls: AI Assistant, Lang, Theme, Mobile toggle */}
          <div className="flex items-center gap-2">
            {/* AI Tutor Button */}
            <button
              onClick={() => setIsAiModalOpen(true)}
              className="relative inline-flex items-center gap-2 px-3 sm:px-4 py-2 rounded-xl text-xs sm:text-sm font-black bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-500 hover:to-indigo-500 text-white shadow-md shadow-indigo-600/20 active:scale-95 transition-all cursor-pointer"
              title={isAr ? 'المساعد الذكي للغة الإنجليزية' : 'AI English Tutor'}
            >
              <Bot className="w-4 h-4 text-amber-300 animate-pulse" />
              <span className="hidden sm:inline">{isAr ? 'المساعد الذكي' : 'AI Tutor'}</span>
              <span className="inline sm:hidden">AI</span>
              <span className="absolute -top-1 -right-1 flex h-2.5 w-2.5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-amber-500"></span>
              </span>
            </button>

            {/* Language Switch */}
            <button
              onClick={() => setLanguage(isAr ? 'en' : 'ar')}
              className="flex items-center gap-1 px-2.5 py-2 rounded-xl border border-slate-200 dark:border-slate-800 text-xs font-bold text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
              title={isAr ? 'Switch to English' : 'التحويل إلى العربية'}
            >
              <Languages className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
              <span>{isAr ? 'EN' : 'عربي'}</span>
            </button>

            {/* Theme Switch */}
            <button
              onClick={toggleTheme}
              className="p-2 rounded-xl border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
              title={theme === 'dark' ? 'Light Mode' : 'Dark Mode'}
            >
              {theme === 'dark' ? (
                <Sun className="w-4 h-4 text-amber-400" />
              ) : (
                <Moon className="w-4 h-4 text-slate-600" />
              )}
            </button>

            {/* Mobile Hamburger Menu Toggle */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="xl:hidden p-2 rounded-xl border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
              aria-label="Toggle navigation menu"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="xl:hidden border-t border-slate-200 dark:border-slate-800 bg-white/95 dark:bg-slate-900/95 backdrop-blur-xl px-4 py-4 space-y-1.5 shadow-xl animate-fadeIn">
          {/* Student quick card on mobile */}
          <div className="flex items-center justify-between p-3 mb-2 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60">
            <div className="flex items-center gap-2.5">
              <span className="text-2xl">{student.avatar}</span>
              <div>
                <p className="text-xs font-bold text-slate-900 dark:text-white">{student.name}</p>
                <p className="text-[11px] text-slate-500 dark:text-slate-400">{student.school}</p>
              </div>
            </div>
            <div className="text-end">
              <span className="text-xs font-black text-emerald-600 dark:text-emerald-400">
                {student.totalScore} {isAr ? 'نقطة' : 'pts'}
              </span>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-1.5">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = currentSection === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => handleNavClick(item.id)}
                  className={`flex items-center gap-2 p-2.5 rounded-xl text-xs font-bold transition-all text-start cursor-pointer ${
                    isActive
                      ? 'bg-emerald-500 text-white shadow-sm'
                      : 'text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800'
                  }`}
                >
                  <Icon className="w-4 h-4 flex-shrink-0" />
                  <span className="truncate">{isAr ? item.labelAr : item.labelEn}</span>
                </button>
              );
            })}
          </div>
        </div>
      )}
    </header>
  );
};
