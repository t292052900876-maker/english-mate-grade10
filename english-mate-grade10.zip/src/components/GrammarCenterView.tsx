import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { GRAMMAR_RULES, IRREGULAR_VERBS, STATIVE_VERBS } from '../data/grammarData';
import { GrammarRule } from '../types';
import {
  Sparkles,
  CheckCircle2,
  HelpCircle,
  Layers,
  ChevronDown,
  ChevronUp,
  Table,
  BookOpen,
  Volume2,
  Search,
} from 'lucide-react';
import confetti from 'canvas-confetti';

export const GrammarCenterView: React.FC = () => {
  const { language, speakText } = useApp();
  const isAr = language === 'ar';

  const [selectedRuleId, setSelectedRuleId] = useState<string>(GRAMMAR_RULES[0].id);
  const [activeTab, setActiveTab] = useState<'rules' | 'osascomp' | 'irregular' | 'stative'>('rules');
  const [userAnswers, setUserAnswers] = useState<Record<string, number>>({});
  const [submittedQuestions, setSubmittedQuestions] = useState<Record<string, boolean>>({});
  const [irregularSearch, setIrregularSearch] = useState('');

  const currentRule = GRAMMAR_RULES.find((r) => r.id === selectedRuleId) || GRAMMAR_RULES[0];

  const handleSelectAnswer = (qId: string, optIdx: number, correctIdx: number) => {
    setUserAnswers((prev) => ({ ...prev, [qId]: optIdx }));
    setSubmittedQuestions((prev) => ({ ...prev, [qId]: true }));
    if (optIdx === correctIdx) {
      confetti({ particleCount: 30, spread: 50, origin: { y: 0.8 } });
    }
  };

  // OSASCOMP interactive builder state
  const [osascompBuilder, setOsascompBuilder] = useState<{
    opinion: string;
    size: string;
    age: string;
    shape: string;
    colour: string;
    origin: string;
    material: string;
    purpose: string;
    noun: string;
  }>({
    opinion: 'beautiful',
    size: 'small',
    age: 'antique',
    shape: 'square',
    colour: 'red',
    origin: 'Kuwaiti',
    material: 'wooden',
    purpose: 'jewelry',
    noun: 'box',
  });

  const filteredIrregulars = IRREGULAR_VERBS.filter(
    (v) =>
      v.base.toLowerCase().includes(irregularSearch.toLowerCase()) ||
      v.past.toLowerCase().includes(irregularSearch.toLowerCase()) ||
      v.pp.toLowerCase().includes(irregularSearch.toLowerCase())
  );

  return (
    <div className="space-y-8 animate-fadeIn">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-100 dark:bg-amber-950/80 text-amber-800 dark:text-amber-300 text-xs font-bold border border-amber-300 dark:border-amber-800 mb-2">
            <Sparkles className="w-3.5 h-3.5" />
            <span>{isAr ? 'ملف القواعد المعتمد (Grammar File pp. 86–92)' : 'Official Grammar File pp. 86–92'}</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white">
            {isAr ? 'مركز القواعد التسع (Grammar Center)' : 'Core 9 Grammar Hub'}
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400">
            {isAr
              ? 'شرح شامل لقواعد الكتاب التسع مع القوانين والصيغ وتدريبات تفاعلية وجداول الأفعال'
              : 'Full explanations, formulas, OSASCOMP builder, and interactive exercises'}
          </p>
        </div>

        {/* Tab switcher */}
        <div className="flex items-center gap-1.5 p-1 rounded-2xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold">
          <button
            onClick={() => setActiveTab('rules')}
            className={`px-3 py-2 rounded-xl transition-all cursor-pointer ${
              activeTab === 'rules'
                ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-sm'
                : 'text-slate-600 dark:text-slate-400'
            }`}
          >
            {isAr ? 'القواعد التسع' : 'The 9 Rules'}
          </button>
          <button
            onClick={() => setActiveTab('osascomp')}
            className={`px-3 py-2 rounded-xl transition-all cursor-pointer ${
              activeTab === 'osascomp'
                ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-sm'
                : 'text-slate-600 dark:text-slate-400'
            }`}
          >
            {isAr ? 'أداة OSASCOMP' : 'OSASCOMP Tool'}
          </button>
          <button
            onClick={() => setActiveTab('irregular')}
            className={`px-3 py-2 rounded-xl transition-all cursor-pointer ${
              activeTab === 'irregular'
                ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-sm'
                : 'text-slate-600 dark:text-slate-400'
            }`}
          >
            {isAr ? 'الأفعال الشاذة' : 'Irregular Verbs'}
          </button>
          <button
            onClick={() => setActiveTab('stative')}
            className={`px-3 py-2 rounded-xl transition-all cursor-pointer ${
              activeTab === 'stative'
                ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-sm'
                : 'text-slate-600 dark:text-slate-400'
            }`}
          >
            {isAr ? 'الأفعال الجامدة' : 'Stative Verbs'}
          </button>
        </div>
      </div>

      {/* TAB 1: 9 RULES */}
      {activeTab === 'rules' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Sidebar rule selector (4 cols on lg) */}
          <div className="lg:col-span-4 space-y-2">
            <h3 className="text-xs font-black uppercase text-slate-400 tracking-wider mb-2">
              {isAr ? 'قائمة القواعد التسع من كتاب الطالب:' : 'Textbook Grammar Rules (1-9):'}
            </h3>
            {GRAMMAR_RULES.map((rule) => {
              const isSelected = rule.id === currentRule.id;
              return (
                <button
                  key={rule.id}
                  onClick={() => setSelectedRuleId(rule.id)}
                  className={`w-full p-4 rounded-2xl text-start transition-all cursor-pointer border flex items-center justify-between gap-3 ${
                    isSelected
                      ? 'bg-amber-500 text-slate-950 border-amber-600 shadow-md shadow-amber-500/10'
                      : 'bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-200 border-slate-200 dark:border-slate-800 hover:border-amber-500/50'
                  }`}
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-black ${isSelected ? 'bg-slate-950 text-white' : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400'}`}>
                        {rule.number}
                      </span>
                      <span className={`text-[11px] font-bold ${isSelected ? 'text-slate-900' : 'text-slate-400'}`}>
                        {isAr ? `الوحدة ${rule.unitId} • ص ${rule.page}` : `Unit ${rule.unitId} • p. ${rule.page}`}
                      </span>
                    </div>
                    <h4 className="font-extrabold text-xs sm:text-sm">
                      {isAr ? rule.titleAr : rule.titleEn}
                    </h4>
                  </div>
                  <ChevronDown className="w-4 h-4 opacity-50 flex-shrink-0" />
                </button>
              );
            })}
          </div>

          {/* Main Rule Viewer (8 cols on lg) */}
          <div className="lg:col-span-8 space-y-6">
            <div className="p-6 sm:p-8 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-6">
              {/* Header */}
              <div className="space-y-2 border-b border-slate-100 dark:border-slate-800 pb-5">
                <div className="flex items-center gap-2">
                  <span className="px-3 py-1 rounded-full text-xs font-black bg-amber-100 text-amber-800 dark:bg-amber-950/80 dark:text-amber-300 border border-amber-300 dark:border-amber-800">
                    {isAr ? `القاعدة رقم ${currentRule.number}` : `Rule #${currentRule.number}`}
                  </span>
                  <span className="text-xs text-slate-400">
                    {isAr ? `الوحدة ${currentRule.unitId} • كتاب الطالب ص ${currentRule.page}` : `Unit ${currentRule.unitId} • Student's Book p. ${currentRule.page}`}
                  </span>
                </div>
                <h2 className="text-2xl font-black text-slate-900 dark:text-white">
                  {isAr ? currentRule.titleAr : currentRule.titleEn}
                </h2>
                <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
                  {isAr ? currentRule.summaryAr : currentRule.summaryEn}
                </p>
              </div>

              {/* Sub-rules & Formulas */}
              <div className="space-y-6">
                {currentRule.rules.map((item, rIdx) => (
                  <div
                    key={rIdx}
                    className="p-5 rounded-2xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-700/60 space-y-3"
                  >
                    <h3 className="text-sm font-black text-slate-900 dark:text-white flex items-center gap-2">
                      <Sparkles className="w-4 h-4 text-amber-500" />
                      <span>{item.heading}</span>
                    </h3>

                    {/* Formula if present */}
                    {item.formula && (
                      <div
                        dir="ltr"
                        className="p-3 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800/60 text-xs font-mono font-bold text-amber-900 dark:text-amber-200"
                      >
                        {item.formula}
                      </div>
                    )}

                    <p className="text-xs text-slate-700 dark:text-slate-300 leading-relaxed whitespace-pre-line">
                      {item.details}
                    </p>

                    {/* Examples from book */}
                    {item.examples.length > 0 && (
                      <div className="space-y-1.5 pt-2">
                        <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
                          {isAr ? 'أمثلة كتاب الطالب المعتمدة:' : 'Official Textbook Examples:'}
                        </span>
                        {item.examples.map((ex, eIdx) => (
                          <div
                            key={eIdx}
                            dir="ltr"
                            className="flex items-start justify-between gap-2 p-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs text-slate-800 dark:text-slate-200"
                          >
                            <span className="font-sans font-medium">{ex.sentence}</span>
                            {ex.note && (
                              <span className="text-[11px] text-emerald-600 dark:text-emerald-400 font-semibold flex-shrink-0">
                                ({ex.note})
                              </span>
                            )}
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
              </div>

              {/* Special Section if any (like OSASCOMP Matrix) */}
              {currentRule.specialSection && (
                <div className="p-5 rounded-2xl bg-amber-50/50 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-900/40 space-y-3">
                  <h3 className="text-sm font-black text-amber-900 dark:text-amber-200">
                    {currentRule.specialSection.title}
                  </h3>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                    {currentRule.specialSection.items.map((it: any, idx: number) => (
                      <div
                        key={idx}
                        className="p-3 rounded-xl bg-white dark:bg-slate-800 border border-amber-200 dark:border-amber-800 text-center"
                      >
                        <span className="text-lg font-black text-amber-500 block">{it.key}</span>
                        <span className="text-xs font-bold text-slate-900 dark:text-white block">
                          {it.category}
                        </span>
                        <span className="text-[10px] text-slate-400 block truncate mt-1">
                          {it.examples}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Interactive Practice Questions */}
              {currentRule.practiceQuestions.length > 0 && (
                <div className="space-y-4 pt-4 border-t border-slate-100 dark:border-slate-800">
                  <h3 className="text-base font-black text-slate-900 dark:text-white flex items-center gap-2">
                    <HelpCircle className="w-5 h-5 text-emerald-500" />
                    <span>{isAr ? 'تدريبات تطبيقية على هذه القاعدة' : 'Practice Exercises'}</span>
                  </h3>

                  <div className="space-y-4">
                    {currentRule.practiceQuestions.map((q, qIdx) => {
                      const isAnswered = submittedQuestions[q.id];
                      const selected = userAnswers[q.id];
                      const isCorrect = selected === q.correctAnswer;

                      return (
                        <div
                          key={q.id}
                          className="p-5 rounded-2xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-700/80 space-y-3"
                        >
                          <div className="flex items-start gap-2.5">
                            <span className="w-6 h-6 rounded-full bg-amber-500/20 text-amber-600 dark:text-amber-400 font-bold text-xs flex items-center justify-center flex-shrink-0">
                              {qIdx + 1}
                            </span>
                            <p className="text-xs sm:text-sm font-bold text-slate-900 dark:text-white">
                              {q.question}
                            </p>
                          </div>

                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
                            {q.options.map((opt, oIdx) => {
                              const isThisSelected = selected === oIdx;
                              let btnClass =
                                'bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200 border-slate-200 dark:border-slate-700 hover:border-amber-500';

                              if (isAnswered) {
                                if (oIdx === q.correctAnswer) {
                                  btnClass = 'bg-emerald-500 text-white border-emerald-600 font-bold';
                                } else if (isThisSelected && !isCorrect) {
                                  btnClass = 'bg-rose-500 text-white border-rose-600 font-bold';
                                }
                              }

                              return (
                                <button
                                  key={oIdx}
                                  onClick={() => handleSelectAnswer(q.id, oIdx, q.correctAnswer)}
                                  className={`p-3 rounded-xl text-xs text-start font-medium border transition-all cursor-pointer ${btnClass}`}
                                >
                                  {opt}
                                </button>
                              );
                            })}
                          </div>

                          {isAnswered && (
                            <div
                              className={`p-3 rounded-xl text-xs ${
                                isCorrect
                                  ? 'bg-emerald-100 text-emerald-900 dark:bg-emerald-950/60 dark:text-emerald-200'
                                  : 'bg-rose-100 text-rose-900 dark:bg-rose-950/60 dark:text-rose-200'
                              }`}
                            >
                              <p className="font-bold mb-0.5">
                                {isCorrect ? 'إجابة صحيحة ممتاز! 🌟' : 'توضيح الإجابة:'}
                              </p>
                              <p>{q.explanation}</p>
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: INTERACTIVE OSASCOMP BUILDER */}
      {activeTab === 'osascomp' && (
        <div className="p-6 sm:p-10 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-8 animate-fadeIn">
          <div>
            <span className="text-xs font-black text-amber-500 uppercase tracking-wider block mb-1">
              Interactive Grammar Lab
            </span>
            <h2 className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white">
              {isAr ? 'أداة ترتيب الصفات التفاعلية (OSASCOMP Builder)' : 'OSASCOMP Adjective Builder'}
            </h2>
            <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
              {isAr
                ? 'اختر الصفات حسب الترتيب الدقيق وشاهد كيف تترتب الجملة الإنجليزية وفق القاعدة المعتمدة ص 87'
                : 'Select or modify adjectives across the 8 categories to see proper textbook ordering'}
            </p>
          </div>

          {/* Resulting Sentence Display Banner */}
          <div className="p-6 rounded-2xl bg-gradient-to-r from-amber-500/10 via-teal-500/10 to-emerald-500/10 border-2 border-amber-500/30 text-center space-y-2">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-widest block">
              {isAr ? 'الجملة الإنجليزية الناتجة بالترتيب الصحيح:' : 'Resulting English Sentence:'}
            </span>
            <p dir="ltr" className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white font-sans">
              " I bought a{' '}
              <span className="text-amber-600 dark:text-amber-400">{osascompBuilder.opinion}</span>{' '}
              <span className="text-teal-600 dark:text-teal-400">{osascompBuilder.size}</span>{' '}
              <span className="text-blue-600 dark:text-blue-400">{osascompBuilder.age}</span>{' '}
              <span className="text-purple-600 dark:text-purple-400">{osascompBuilder.shape}</span>{' '}
              <span className="text-rose-600 dark:text-rose-400">{osascompBuilder.colour}</span>{' '}
              <span className="text-emerald-600 dark:text-emerald-400">{osascompBuilder.origin}</span>{' '}
              <span className="text-orange-600 dark:text-orange-400">{osascompBuilder.material}</span>{' '}
              <span className="text-cyan-600 dark:text-cyan-400">{osascompBuilder.purpose}</span>{' '}
              <span className="font-extrabold underline">{osascompBuilder.noun}</span>. "
            </p>

            <button
              onClick={() =>
                speakText(
                  `I bought a ${osascompBuilder.opinion} ${osascompBuilder.size} ${osascompBuilder.age} ${osascompBuilder.shape} ${osascompBuilder.colour} ${osascompBuilder.origin} ${osascompBuilder.material} ${osascompBuilder.purpose} ${osascompBuilder.noun}`
                )
              }
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white dark:bg-slate-800 text-xs font-bold text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-700 shadow-sm cursor-pointer hover:border-amber-500"
            >
              <Volume2 className="w-3.5 h-3.5 text-amber-500" />
              <span>{isAr ? 'استمع لنطق الجملة كاملة' : 'Listen to Sentence'}</span>
            </button>
          </div>

          {/* Interactive controls */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            {[
              { key: 'opinion', label: '1. Opinion (رأي)', options: ['beautiful', 'delicious', 'comfortable', 'lovely'] },
              { key: 'size', label: '2. Size (حجم)', options: ['small', 'large', 'tiny', 'massive', 'short'] },
              { key: 'age', label: '3. Age (عمر)', options: ['antique', 'modern', 'new', 'ancient'] },
              { key: 'shape', label: '4. Shape (شكل)', options: ['square', 'round', 'thin', 'rectangular'] },
              { key: 'colour', label: '5. Colour (لون)', options: ['red', 'silver', 'golden', 'blue', 'green'] },
              { key: 'origin', label: '6. Origin (أصل)', options: ['Kuwaiti', 'Italian', 'Japanese', 'Omani'] },
              { key: 'material', label: '7. Material (مادة)', options: ['wooden', 'velvet', 'cotton', 'leather'] },
              { key: 'purpose', label: '8. Purpose (غرض)', options: ['dining', 'running', 'jewelry', 'gardening'] },
            ].map((col) => (
              <div key={col.key} className="space-y-1.5 p-3 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-700/60">
                <label className="text-[11px] font-black text-slate-700 dark:text-slate-300 block">
                  {col.label}
                </label>
                <select
                  value={(osascompBuilder as any)[col.key]}
                  onChange={(e) =>
                    setOsascompBuilder((prev) => ({ ...prev, [col.key]: e.target.value }))
                  }
                  className="w-full p-2 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-900 dark:text-white"
                >
                  {col.options.map((opt) => (
                    <option key={opt} value={opt}>
                      {opt}
                    </option>
                  ))}
                </select>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 3: IRREGULAR VERBS TABLE */}
      {activeTab === 'irregular' && (
        <div className="p-6 sm:p-8 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-6 animate-fadeIn">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <span className="text-xs font-black text-emerald-500 uppercase tracking-wider block mb-1">
                Grammar Reference
              </span>
              <h2 className="text-2xl font-black text-slate-900 dark:text-white">
                {isAr ? 'قائمة الأفعال الشاذة (Irregular Verbs List)' : 'Irregular Verbs (pp. 95–96)'}
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {isAr
                  ? 'جميع الأفعال الشاذة الواردة في ملحق كتاب الطالب مع التصريف الثاني والثالث'
                  : 'Complete irregular verbs list from Student Book pages 95-96'}
              </p>
            </div>

            <div className="relative w-full sm:w-64">
              <Search className="absolute right-3 top-2.5 w-4 h-4 text-slate-400 rtl:right-3 ltr:left-3" />
              <input
                type="text"
                value={irregularSearch}
                onChange={(e) => setIrregularSearch(e.target.value)}
                placeholder={isAr ? 'ابحث عن فعل...' : 'Search verb...'}
                className="w-full py-2 px-9 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>
          </div>

          <div className="overflow-x-auto rounded-2xl border border-slate-200 dark:border-slate-800">
            <table className="w-full text-start text-xs font-sans">
              <thead className="bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 border-b border-slate-200 dark:border-slate-700">
                <tr>
                  <th className="p-3 text-start font-black">Base Form (V1)</th>
                  <th className="p-3 text-start font-black">Past Simple (V2)</th>
                  <th className="p-3 text-start font-black">Past Participle (V3)</th>
                  <th className="p-3 text-center font-black">Pronounce</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {filteredIrregulars.map((v, i) => (
                  <tr
                    key={i}
                    className="hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition-colors"
                  >
                    <td className="p-3 font-bold text-slate-900 dark:text-white">{v.base}</td>
                    <td className="p-3 text-emerald-600 dark:text-emerald-400 font-semibold">{v.past}</td>
                    <td className="p-3 text-amber-600 dark:text-amber-400 font-semibold">{v.pp}</td>
                    <td className="p-3 text-center">
                      <button
                        onClick={() => speakText(`${v.base}, ${v.past}, ${v.pp}`)}
                        className="p-1 text-slate-400 hover:text-emerald-500 cursor-pointer"
                        title="Pronounce"
                      >
                        <Volume2 className="w-4 h-4 mx-auto" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 4: STATIVE VERBS TABLE */}
      {activeTab === 'stative' && (
        <div className="p-6 sm:p-8 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-6 animate-fadeIn">
          <div>
            <span className="text-xs font-black text-cyan-500 uppercase tracking-wider block mb-1">
              Grammar Reference
            </span>
            <h2 className="text-2xl font-black text-slate-900 dark:text-white">
              {isAr ? 'قائمة الأفعال الجامدة (Stative Verbs List)' : 'Stative Verbs (Page 97)'}
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              {isAr
                ? 'أفعال الحالة والمشاعر والإدراك والملكية التي لا تأتي عادة في صيغة الاستمرار (ing)'
                : 'Verbs of cognition, emotion, perception, and possession rarely used in continuous forms'}
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {STATIVE_VERBS.map((grp, gIdx) => (
              <div
                key={gIdx}
                className="p-5 rounded-2xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-700 space-y-3"
              >
                <h3 className="text-sm font-black text-slate-900 dark:text-white border-b border-slate-200 dark:border-slate-700 pb-2">
                  {grp.category}
                </h3>
                <div className="flex flex-wrap gap-1.5">
                  {grp.verbs.map((verb, vIdx) => (
                    <button
                      key={vIdx}
                      onClick={() => speakText(verb)}
                      className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-semibold bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200 border border-slate-200 dark:border-slate-700 hover:border-cyan-500 transition-colors cursor-pointer"
                    >
                      <span>{verb}</span>
                      <Volume2 className="w-3 h-3 text-slate-400" />
                    </button>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
