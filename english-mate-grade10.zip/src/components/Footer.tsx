import React from 'react';
import { useApp } from '../context/AppContext';
import { BookOpen, Award, ShieldCheck, Heart, Sparkles } from 'lucide-react';

export const Footer: React.FC = () => {
  const { language } = useApp();
  const isAr = language === 'ar';

  return (
    <footer className="mt-20 border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900/90 transition-colors">
      {/* Official Kuwait Education Supervision Banner */}
      <div className="relative overflow-hidden bg-gradient-to-r from-emerald-800 via-teal-800 to-slate-900 text-white py-12 px-4 sm:px-6 lg:px-8 shadow-inner">
        {/* Kuwait subtle flag colored border accents */}
        <div className="absolute top-0 left-0 right-0 h-1.5 flex">
          <div className="h-full w-1/3 bg-emerald-500" />
          <div className="h-full w-1/3 bg-white" />
          <div className="h-full w-1/3 bg-rose-500" />
        </div>

        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-8">
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/10 backdrop-blur-md text-emerald-300 text-xs sm:text-sm font-semibold mb-3 border border-white/15">
              <Sparkles className="w-4 h-4 text-amber-300" />
              <span>{isAr ? 'وزارة التربية – دولة الكويت' : 'Ministry of Education – State of Kuwait'}</span>
              <span className="text-white/40">•</span>
              <span>{isAr ? 'منهج Origin to Outlook (Grade 10A) – 2026/2027' : 'Curriculum 2026/2027'}</span>
            </div>

            <h3 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white mb-2">
              {isAr ? 'إعداد وإشراف' : 'Prepared & Supervised By'}
            </h3>
            <p className="text-slate-300 text-sm max-w-xl mx-auto">
              {isAr
                ? 'تم تصميم هذا التطبيق التعليمي دعماً لطلبة الصف العاشر في دولة الكويت وتمكينهم من إتقان مهارات اللغة الإنجليزية.'
                : 'Designed and developed to empower Kuwait Grade 10 secondary students in mastering modern English language skills.'}
            </p>
          </div>

          {/* Strict required names card grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto">
            {/* Card 1: Teacher Sharifa */}
            <div className="relative group bg-white/10 hover:bg-white/15 backdrop-blur-md border border-white/20 rounded-2xl p-6 text-center transition-all duration-300 shadow-lg hover:shadow-emerald-500/10">
              <div className="w-14 h-14 mx-auto mb-4 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-400 flex items-center justify-center text-white shadow-md shadow-emerald-900/30">
                <BookOpen className="w-7 h-7" />
              </div>
              <p className="text-xs font-medium text-emerald-300 uppercase tracking-wider mb-1">
                {isAr ? 'إعداد وتصميم' : 'Prepared & Designed By'}
              </p>
              <h4 className="text-lg sm:text-xl font-black text-white">
                أ. شريفه سالم المويزري
              </h4>
              <p className="text-xs text-slate-300 mt-1">
                {isAr ? 'معلمة لغة إنجليزية' : 'English Language Educator'}
              </p>
            </div>

            {/* Card 2: Supervisor Alanoud */}
            <div className="relative group bg-white/10 hover:bg-white/15 backdrop-blur-md border border-white/20 rounded-2xl p-6 text-center transition-all duration-300 shadow-lg hover:shadow-teal-500/10">
              <div className="w-14 h-14 mx-auto mb-4 rounded-2xl bg-gradient-to-tr from-teal-500 to-cyan-400 flex items-center justify-center text-white shadow-md shadow-teal-900/30">
                <ShieldCheck className="w-7 h-7" />
              </div>
              <p className="text-xs font-medium text-teal-300 uppercase tracking-wider mb-1">
                {isAr ? 'الموجهه الفنية' : 'ELT Technical Supervisor'}
              </p>
              <h4 className="text-lg sm:text-xl font-black text-white">
                أ. العنود الدغيم
              </h4>
              <p className="text-xs text-slate-300 mt-1">
                {isAr ? 'التوجيه الفني للغة الإنجليزية' : 'English Language Supervision'}
              </p>
            </div>

            {/* Card 3: Principal Salima */}
            <div className="relative group bg-white/10 hover:bg-white/15 backdrop-blur-md border border-white/20 rounded-2xl p-6 text-center transition-all duration-300 shadow-lg hover:shadow-amber-500/10">
              <div className="w-14 h-14 mx-auto mb-4 rounded-2xl bg-gradient-to-tr from-amber-500 to-orange-400 flex items-center justify-center text-white shadow-md shadow-amber-900/30">
                <Award className="w-7 h-7" />
              </div>
              <p className="text-xs font-medium text-amber-300 uppercase tracking-wider mb-1">
                {isAr ? 'مديرة المدرسة' : 'School Principal'}
              </p>
              <h4 className="text-lg sm:text-xl font-black text-white">
                أ. سليمه العنزي
              </h4>
              <p className="text-xs text-slate-300 mt-1">
                {isAr ? 'الإدارة المدرسية المتميزة' : 'School Administration'}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Secondary Bottom Links */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500 dark:text-slate-400">
          <div className="flex items-center gap-2">
            <span className="font-bold text-slate-800 dark:text-slate-200">English Mate – Grade 10</span>
            <span>•</span>
            <span>{isAr ? 'كتاب الطالب 10A (2026/2027)' : "Student's Book 10A (2026/2027)"}</span>
          </div>
          <div className="flex items-center gap-1">
            <span>{isAr ? 'صُنع بحب وعناية لطلبة الكويت' : 'Crafted with care for Kuwait students'}</span>
            <Heart className="w-3.5 h-3.5 text-rose-500 fill-rose-500" />
          </div>
        </div>
      </div>
    </footer>
  );
};
