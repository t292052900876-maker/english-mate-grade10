import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { UNITS_DATA } from '../data/unitsData';
import {
  BookOpen,
  Headphones,
  Mic,
  PenTool,
  Volume2,
  CheckCircle2,
  Sparkles,
  ArrowRight,
  ArrowLeft,
  FileCheck,
} from 'lucide-react';
import confetti from 'canvas-confetti';

export const SkillsHubView: React.FC = () => {
  const { language, speakText } = useApp();
  const isAr = language === 'ar';
  const ArrowIcon = isAr ? ArrowLeft : ArrowRight;

  const [activeSkill, setActiveSkill] = useState<'reading' | 'listening' | 'speaking' | 'writing'>('reading');
  const [selectedReadingUnit, setSelectedReadingUnit] = useState<number>(1);
  const [selectedListeningUnit, setSelectedListeningUnit] = useState<number>(1);
  const [writtenEssay, setWrittenEssay] = useState<string>('');
  const [checklist, setChecklist] = useState<Record<string, boolean>>({});

  // Collect reading and listening lessons across units
  const currentReadingUnit = UNITS_DATA.find((u) => u.id === selectedReadingUnit) || UNITS_DATA[0];
  const readingLessons = currentReadingUnit.lessons.filter((l) => l.type === 'Reading');

  const currentListeningUnit = UNITS_DATA.find((u) => u.id === selectedListeningUnit) || UNITS_DATA[0];
  const listeningLessons = currentListeningUnit.lessons.filter((l) => l.type === 'Listening');

  const toggleCheck = (key: string) => {
    setChecklist((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  return (
    <div className="space-y-8 animate-fadeIn">
      {/* Header */}
      <div>
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-100 dark:bg-cyan-950/80 text-cyan-800 dark:text-cyan-300 text-xs font-bold border border-cyan-300 dark:border-cyan-800 mb-2">
          <Sparkles className="w-3.5 h-3.5" />
          <span>{isAr ? 'المهارات اللغوية الأربع المعتمدة' : 'The Four Essential Language Skills'}</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white">
          {isAr ? 'مركز المهارات اللغوية (Skills Hub)' : 'Skills Hub: Receptive & Productive'}
        </h1>
        <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400">
          {isAr
            ? 'أقسام متخصصة لمهارات القراءة (Reading)، الاستماع (Listening)، التحدث (Speaking)، والكتابة (Writing)'
            : 'Dedicated practice suites for Reading, Listening, Speaking, and Writing based on Grade 10A'}
        </p>
      </div>

      {/* 4 Skill Tabs */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[
          { id: 'reading', labelEn: 'Reading & Viewing', labelAr: 'القراءة والتحليل', icon: BookOpen, color: 'text-blue-500' },
          { id: 'listening', labelEn: 'Listening & Viewing', labelAr: 'الاستماع الصوتي', icon: Headphones, color: 'text-purple-500' },
          { id: 'speaking', labelEn: 'Speaking & Presenting', labelAr: 'التحدث والإلقاء', icon: Mic, color: 'text-rose-500' },
          { id: 'writing', labelEn: 'Writing & Composing', labelAr: 'الكتابة الإنشائية', icon: PenTool, color: 'text-emerald-500' },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeSkill === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveSkill(tab.id as any)}
              className={`p-4 rounded-2xl border text-start transition-all cursor-pointer flex items-center gap-3 ${
                isActive
                  ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-900 border-slate-900 dark:border-white shadow-lg'
                  : 'bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-800 hover:border-slate-400'
              }`}
            >
              <div className={`p-2 rounded-xl bg-slate-100 dark:bg-slate-800 ${tab.color}`}>
                <Icon className="w-5 h-5" />
              </div>
              <div>
                <span className="text-[11px] text-slate-400 font-bold block">{tab.labelEn}</span>
                <span className="text-xs sm:text-sm font-black">{isAr ? tab.labelAr : tab.labelEn}</span>
              </div>
            </button>
          );
        })}
      </div>

      {/* SKILL 1: READING */}
      {activeSkill === 'reading' && (
        <div className="space-y-6">
          {/* Unit pills */}
          <div className="flex items-center gap-2 overflow-x-auto pb-2">
            <span className="text-xs font-bold text-slate-400 flex-shrink-0">{isAr ? 'اختر الوحدة:' : 'Select Unit:'}</span>
            {[1, 2, 3, 4].map((uId) => (
              <button
                key={uId}
                onClick={() => setSelectedReadingUnit(uId)}
                className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer flex-shrink-0 ${
                  selectedReadingUnit === uId
                    ? 'bg-blue-600 text-white shadow-sm'
                    : 'bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300'
                }`}
              >
                {isAr ? `الوحدة ${uId}` : `Unit ${uId}`}
              </button>
            ))}
          </div>

          <div className="space-y-6">
            {readingLessons.map((les) => (
              <div
                key={les.id}
                className="p-6 sm:p-8 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-5"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 dark:border-slate-800 pb-4">
                  <div>
                    <span className="text-xs font-bold text-blue-600 dark:text-blue-400">
                      {isAr ? `درس القراءة • كتاب الطالب ص ${les.pageNumber}` : `Reading • Page ${les.pageNumber}`}
                    </span>
                    <h3 className="text-xl font-black text-slate-900 dark:text-white">
                      {isAr ? les.titleAr : les.titleEn}
                    </h3>
                  </div>

                  <button
                    onClick={() => speakText(les.content.readingText || '')}
                    className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-blue-50 dark:bg-blue-950 text-blue-700 dark:text-blue-300 text-xs font-bold hover:bg-blue-100 cursor-pointer self-start sm:self-auto"
                  >
                    <Volume2 className="w-4 h-4" />
                    <span>{isAr ? 'قراءة النص بصوت واضح' : 'Read Aloud'}</span>
                  </button>
                </div>

                <div
                  dir="ltr"
                  className="p-5 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 text-sm leading-relaxed text-slate-800 dark:text-slate-200 font-sans whitespace-pre-line"
                >
                  {les.content.readingText}
                </div>

                {/* Comprehension Tasks */}
                <div className="space-y-3 pt-2">
                  <h4 className="text-xs font-black uppercase text-slate-400 tracking-wider">
                    {isAr ? 'أسئلة الفهم والاستيعاب:' : 'Comprehension Check:'}
                  </h4>
                  <div className="grid grid-cols-1 gap-3">
                    {les.content.tasks.map((task, tIdx) => (
                      <div
                        key={task.id}
                        className="p-4 rounded-xl bg-white dark:bg-slate-850 border border-slate-200 dark:border-slate-700 text-xs space-y-1.5"
                      >
                        <p className="font-bold text-slate-900 dark:text-white">
                          {tIdx + 1}. {task.questionEn}
                        </p>
                        <p className="text-emerald-600 dark:text-emerald-400 font-semibold">
                          ✓ {task.explanation}
                        </p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* SKILL 2: LISTENING */}
      {activeSkill === 'listening' && (
        <div className="space-y-6">
          <div className="flex items-center gap-2 overflow-x-auto pb-2">
            <span className="text-xs font-bold text-slate-400 flex-shrink-0">{isAr ? 'اختر الوحدة:' : 'Select Unit:'}</span>
            {[1, 2, 3, 4].map((uId) => (
              <button
                key={uId}
                onClick={() => setSelectedListeningUnit(uId)}
                className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer flex-shrink-0 ${
                  selectedListeningUnit === uId
                    ? 'bg-purple-600 text-white shadow-sm'
                    : 'bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300'
                }`}
              >
                {isAr ? `الوحدة ${uId}` : `Unit ${uId}`}
              </button>
            ))}
          </div>

          <div className="space-y-6">
            {listeningLessons.map((les) => (
              <div
                key={les.id}
                className="p-6 sm:p-8 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-5"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 dark:border-slate-800 pb-4">
                  <div>
                    <span className="text-xs font-bold text-purple-600 dark:text-purple-400">
                      {isAr ? `نص الاستماع • كتاب الطالب ص ${les.pageNumber}` : `Listening Audio • Page ${les.pageNumber}`}
                    </span>
                    <h3 className="text-xl font-black text-slate-900 dark:text-white">
                      {isAr ? les.titleAr : les.titleEn}
                    </h3>
                  </div>

                  <button
                    onClick={() => speakText(les.content.listeningScript || '')}
                    className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold shadow-md cursor-pointer self-start sm:self-auto"
                  >
                    <Volume2 className="w-4 h-4" />
                    <span>{isAr ? 'تشغيل المقطع الصوتي' : 'Play Audio Script'}</span>
                  </button>
                </div>

                <div
                  dir="ltr"
                  className="p-5 rounded-2xl bg-purple-50/50 dark:bg-purple-950/20 border border-purple-200 dark:border-purple-900/50 text-sm leading-relaxed text-slate-800 dark:text-slate-200 font-sans whitespace-pre-line"
                >
                  {les.content.listeningScript}
                </div>

                {/* Comprehension Tasks */}
                <div className="space-y-3 pt-2">
                  <h4 className="text-xs font-black uppercase text-slate-400 tracking-wider">
                    {isAr ? 'تمارين الاستماع وتأكيد الفهم:' : 'Listening Tasks & Answers:'}
                  </h4>
                  <div className="grid grid-cols-1 gap-3">
                    {les.content.tasks.map((task, tIdx) => (
                      <div
                        key={task.id}
                        className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-700 text-xs space-y-1.5"
                      >
                        <p className="font-bold text-slate-900 dark:text-white">
                          {tIdx + 1}. {task.questionEn}
                        </p>
                        <p className="text-purple-600 dark:text-purple-400 font-semibold">
                          ✓ {task.explanation}
                        </p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* SKILL 3: SPEAKING */}
      {activeSkill === 'speaking' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Card 1: 1-Minute Talk Builder */}
          <div className="p-6 sm:p-8 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-5">
            <div className="flex items-center gap-2 text-rose-500 font-bold text-xs uppercase tracking-wider">
              <Mic className="w-4 h-4" />
              <span>{isAr ? 'مهارة إلقاء خطاب مدته دقيقة (ص 54)' : '1-Minute Talk Builder (p. 54)'}</span>
            </div>
            <h3 className="text-xl font-black text-slate-900 dark:text-white">
              {isAr ? 'هيكل الحديث عن الإنجاز المستقبلي (Big Dreamers)' : 'Future Achievement Profile'}
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
              {isAr
                ? 'استخدم هذه المخططات الخمسة لتقديم عرض تقديمي ممتاز أمام المعلم وزملائك في الفصل:'
                : 'Follow this 5-stage framework to deliver an inspiring talk:'}
            </p>

            <div className="space-y-3 text-xs">
              {[
                { stage: '1. Introduction', starter: 'In 10 years, I will be a...', tip: 'Say who you are in the future.' },
                { stage: '2. Inspiration', starter: 'I was inspired by...', tip: 'Mention a role model or heritage figure.' },
                { stage: '3. Achievement', starter: 'I created / designed / developed...', tip: 'Describe your concrete contribution.' },
                { stage: '4. Impact', starter: 'This helped people by...', tip: 'Explain the positive benefit to Kuwait and the world.' },
                { stage: '5. Message', starter: 'My message to younger students is...', tip: 'End with an inspiring call to action.' },
              ].map((item, idx) => (
                <div key={idx} className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="font-black text-slate-900 dark:text-white">{item.stage}</span>
                    <span className="text-[10px] text-slate-400">{item.tip}</span>
                  </div>
                  <p dir="ltr" className="font-mono text-rose-600 dark:text-rose-400 font-bold">
                    "{item.starter}"
                  </p>
                </div>
              ))}
            </div>
          </div>

          {/* Card 2: Presentation & Debate Assessment Rubric */}
          <div className="p-6 sm:p-8 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-5">
            <div className="flex items-center gap-2 text-amber-500 font-bold text-xs uppercase tracking-wider">
              <CheckCircle2 className="w-4 h-4" />
              <span>{isAr ? 'معايير التقييم الشفوي الرسمية (ص 46 و78)' : 'Official Speaking Rubric (pp. 46, 78)'}</span>
            </div>
            <h3 className="text-xl font-black text-slate-900 dark:text-white">
              {isAr ? 'سلم درجات التقييم الذاتي وتقييم الزملاء' : 'Peer & Self Assessment Criteria'}
            </h3>

            <div className="space-y-3 text-xs">
              {[
                { name: 'Voice & Fluency', excellent: 'Speaks clearly, confidently with natural pace and good volume.' },
                { name: 'Content & Organisation', excellent: 'Gives well-chosen information with clear logical sequence.' },
                { name: 'Language Use', excellent: 'Uses wide range of target Grade 10 vocabulary and accurate grammar.' },
                { name: 'Body Language', excellent: 'Maintains eye contact, natural posture, and respectful gestures.' },
              ].map((c, i) => (
                <div key={i} className="p-3.5 rounded-xl bg-amber-50/50 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-900/40 space-y-1">
                  <span className="font-black text-amber-900 dark:text-amber-200 block">{c.name}</span>
                  <p className="text-slate-600 dark:text-slate-300 font-sans">{c.excellent}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* SKILL 4: WRITING */}
      {activeSkill === 'writing' && (
        <div className="space-y-6">
          <div className="p-6 sm:p-8 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-6">
            <div>
              <span className="text-xs font-black text-emerald-500 uppercase tracking-wider block mb-1">
                Expository Writing Suite
              </span>
              <h2 className="text-2xl font-black text-slate-900 dark:text-white">
                {isAr ? 'مختبر كتابة المقال التفسيري (8 جمل - 90 كلمة)' : 'Expository Paragraph Blueprint'}
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                {isAr
                  ? 'تعلم كتابة الفقرات الإنشائية وفق المعايير الوزارية لكتاب الطالب للصف العاشر'
                  : 'Follow the Ministry of Education standard: Topic Sentence, Supporting Ideas, Conclusion, and Linkers'}
              </p>
            </div>

            {/* Structure Breakdown */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
              <div className="p-4 rounded-2xl bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-800 space-y-1">
                <span className="font-black text-blue-800 dark:text-blue-300 block">1. Topic Sentence (TS)</span>
                <p className="text-slate-600 dark:text-slate-300">
                  {isAr ? 'تحدد الفكرة المحورية للموضوع بوضوح وتجذب انتباه القارئ.' : 'Clearly states the main controlling idea of the paragraph.'}
                </p>
              </div>
              <div className="p-4 rounded-2xl bg-teal-50 dark:bg-teal-950/40 border border-teal-200 dark:border-teal-800 space-y-1">
                <span className="font-black text-teal-800 dark:text-teal-300 block">2. Supporting Ideas (SI)</span>
                <p className="text-slate-600 dark:text-slate-300">
                  {isAr ? 'فكرتان أو ثلاث مدعمة بأمثلة واقعية وشواهد وأدوات ربط.' : 'Give 2-3 specific arguments supported by real-life examples.'}
                </p>
              </div>
              <div className="p-4 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 space-y-1">
                <span className="font-black text-emerald-800 dark:text-emerald-300 block">3. Concluding Sentence (CS)</span>
                <p className="text-slate-600 dark:text-slate-300">
                  {isAr ? 'إعادة صياغة الفكرة المحورية بكلمات جديدة دون تكرار حرفي.' : 'Paraphrases the topic sentence and leaves a lasting insight.'}
                </p>
              </div>
            </div>

            {/* Linkers Reference Bank */}
            <div className="p-5 rounded-2xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-700 space-y-3">
              <h4 className="text-xs font-black uppercase text-slate-700 dark:text-slate-300 tracking-wider">
                {isAr ? 'بنك أدوات الربط الرسمية (Mandatory Linkers):' : 'Official Transition Linkers Bank:'}
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                <div>
                  <span className="font-bold text-emerald-600 dark:text-emerald-400 block mb-1">
                    {isAr ? 'لإضافة أفكار (To add ideas):' : 'To add ideas:'}
                  </span>
                  <div className="flex flex-wrap gap-1 font-mono">
                    <span className="px-2 py-0.5 rounded bg-white dark:bg-slate-900 border">furthermore</span>
                    <span className="px-2 py-0.5 rounded bg-white dark:bg-slate-900 border">moreover</span>
                    <span className="px-2 py-0.5 rounded bg-white dark:bg-slate-900 border">in addition</span>
                  </div>
                </div>

                <div>
                  <span className="font-bold text-amber-600 dark:text-amber-400 block mb-1">
                    {isAr ? 'لبيان النتيجة (To show result):' : 'To show result:'}
                  </span>
                  <div className="flex flex-wrap gap-1 font-mono">
                    <span className="px-2 py-0.5 rounded bg-white dark:bg-slate-900 border">consequently</span>
                    <span className="px-2 py-0.5 rounded bg-white dark:bg-slate-900 border">therefore</span>
                    <span className="px-2 py-0.5 rounded bg-white dark:bg-slate-900 border">as a result</span>
                  </div>
                </div>

                <div>
                  <span className="font-bold text-purple-600 dark:text-purple-400 block mb-1">
                    {isAr ? 'للخاتمة والتلخيص (To conclude):' : 'To conclude:'}
                  </span>
                  <div className="flex flex-wrap gap-1 font-mono">
                    <span className="px-2 py-0.5 rounded bg-white dark:bg-slate-900 border">ultimately</span>
                    <span className="px-2 py-0.5 rounded bg-white dark:bg-slate-900 border">in summary</span>
                    <span className="px-2 py-0.5 rounded bg-white dark:bg-slate-900 border">to sum up</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Interactive Essay Writing Pad */}
            <div className="space-y-3">
              <label className="text-xs font-bold text-slate-700 dark:text-slate-200 block">
                {isAr ? 'محرر كتابة المقال والتمرين العملي:' : 'Practice Your Expository Essay:'}
              </label>
              <textarea
                value={writtenEssay}
                onChange={(e) => setWrittenEssay(e.target.value)}
                placeholder="Start with an engaging Topic Sentence, connect your supporting arguments with linkers like 'Furthermore' and 'Consequently', and conclude with 'Ultimately'..."
                dir="ltr"
                rows={6}
                className="w-full p-4 rounded-2xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-sm font-sans focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
              <div className="flex justify-between items-center text-xs text-slate-400">
                <span>
                  {isAr ? 'الكلمات:' : 'Words:'}{' '}
                  {writtenEssay.trim() ? writtenEssay.trim().split(/\s+/).length : 0} / 90
                </span>
                <span className="font-bold text-emerald-600">
                  {writtenEssay.trim().split(/\s+/).length >= 80 ? '✓ الطول مناسب للاختبار' : 'اكتب حوالي 90 كلمة'}
                </span>
              </div>
            </div>

            {/* Success Bar Checklist */}
            <div className="space-y-2 pt-2 border-t border-slate-100 dark:border-slate-800">
              <span className="text-xs font-black text-slate-400 uppercase tracking-wider block">
                {isAr ? 'شريط النجاح والتقييم الذاتي (Success Bar Checklist ص 56):' : 'Writing Success Bar Checklist:'}
              </span>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                {[
                  { id: 'c1', label: 'I wrote a clear Topic Sentence (الجملة الافتتاحية واضحة)' },
                  { id: 'c2', label: 'I connected ideas using linkers (استخدمت أدوات الربط)' },
                  { id: 'c3', label: 'I used at least four target vocabulary words (وظفت 4 مفردات جديدة)' },
                  { id: 'c4', label: 'I wrote a solid Concluding Sentence (صغت خاتمة تلخص الفكرة)' },
                ].map((item) => (
                  <button
                    key={item.id}
                    onClick={() => toggleCheck(item.id)}
                    className={`p-3 rounded-xl border text-start flex items-center gap-2 cursor-pointer transition-colors ${
                      checklist[item.id]
                        ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-500 text-emerald-900 dark:text-emerald-200 font-bold'
                        : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400'
                    }`}
                  >
                    <CheckCircle2 className={`w-4 h-4 ${checklist[item.id] ? 'text-emerald-600' : 'text-slate-300'}`} />
                    <span>{item.label}</span>
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
