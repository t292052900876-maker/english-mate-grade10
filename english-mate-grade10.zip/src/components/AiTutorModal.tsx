import React, { useState, useRef, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import {
  X,
  Bot,
  Send,
  Sparkles,
  Volume2,
  RotateCcw,
  User,
  Lightbulb,
} from 'lucide-react';

interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  text: string;
  timestamp: string;
}

export const AiTutorModal: React.FC = () => {
  const { language, isAiModalOpen, setIsAiModalOpen, speakText } = useApp();
  const isAr = language === 'ar';

  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome',
      role: 'model',
      text: isAr
        ? `مرحباً بك يا بطل! أنا مساعدك الذكي English Mate AI المخصص لمنهج الصف العاشر (Origin to Outlook – 2026/2027) بدولة الكويت 🇰🇼.

كيف يمكنني مساعدتك اليوم؟ يمكنك سؤالي عن:
• شرح أي من القواعد التسع (مثل OSASCOMP أو Reported Speech أو Present Perfect).
• توضيح معاني واستخدامات المفردات الجديدة وأمثلة عليها.
• المساعدة في صياغة مقالات الكتابة (Expository Essays) والربط المنطقي.
• التدرب على الوظائف اللغوية وأسئلة الاختبار.`
        : `Hello! I am your English Mate AI tutor, tailored for Kuwait Grade 10 (Origin to Outlook – 2026/2027) 🇰🇼.

How can I help you today? Ask me about:
• Explaining the 9 grammar rules (OSASCOMP, Reported Speech, Conditionals, etc.)
• Textbook vocabulary definitions, phonetics, and contextual sentences
• Drafting and polishing expository essays with transition linkers
• Preparing for speaking and language function exams!`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);

  const [inputText, setInputText] = useState('');
  const [loading, setLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    if (isAiModalOpen) {
      scrollToBottom();
    }
  }, [messages, isAiModalOpen]);

  if (!isAiModalOpen) return null;

  const quickPrompts = [
    isAr ? 'اشرح لي ترتيب الصفات OSASCOMP' : 'Explain OSASCOMP Adjectives',
    isAr ? 'كيف أستخدم Reported Speech؟' : 'How does Reported Speech work?',
    isAr ? 'ما الفرق بين thrifting و upcycling؟' : 'Difference between thrifting & upcycling',
    isAr ? 'أعطني أفكاراً لموضوع Smart Canteen' : 'Help me plan Smart Canteen essay',
  ];

  const handleSendMessage = async (textToSend?: string) => {
    const text = textToSend || inputText;
    if (!text.trim() || loading) return;

    const userMsg: ChatMessage = {
      id: `u-${Date.now()}`,
      role: 'user',
      text: text.trim(),
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputText('');
    setLoading(true);

    try {
      // Format conversation history for server-side proxy
      const conversationHistory = messages.map((m) => ({
        role: m.role,
        text: m.text,
      }));

      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: text.trim(),
          conversationHistory,
        }),
      });

      const data = await res.json();
      const botReply = data.reply || (isAr ? 'عذراً، حدث خطأ غير متوقع. حاول مرة أخرى.' : 'Sorry, an error occurred. Please try again.');

      const botMsg: ChatMessage = {
        id: `m-${Date.now()}`,
        role: 'model',
        text: botReply,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      setMessages((prev) => [...prev, botMsg]);
    } catch (err) {
      console.error(err);
      const errMsg: ChatMessage = {
        id: `err-${Date.now()}`,
        role: 'model',
        text: isAr
          ? 'تعذر الاتصال بالخادم. يرجى التأكد من تشغيل الخادم وتوافر الاتصال بالإنترنت.'
          : 'Could not connect to the AI tutor server. Please check your connection.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages((prev) => [...prev, errMsg]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6 animate-fadeIn">
      <div className="relative w-full max-w-2xl bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 flex flex-col h-[85vh] overflow-hidden">
        {/* Header */}
        <div className="p-4 sm:p-5 bg-gradient-to-r from-violet-600 via-indigo-600 to-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-white/20 backdrop-blur-md flex items-center justify-center text-amber-300">
              <Bot className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-black">English Mate AI</h3>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500 text-slate-950 font-black">
                  Online
                </span>
              </div>
              <p className="text-[11px] text-violet-200">
                {isAr ? 'معلم الذكاء الاصطناعي لمنهج الصف العاشر' : 'Grade 10 Kuwait AI Tutor'}
              </p>
            </div>
          </div>

          <button
            onClick={() => setIsAiModalOpen(false)}
            className="p-2 rounded-xl text-white/70 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Quick prompt chips */}
        <div className="p-3 bg-slate-50 dark:bg-slate-800/50 border-b border-slate-200 dark:border-slate-800 flex items-center gap-2 overflow-x-auto text-xs">
          <span className="font-bold text-slate-400 flex items-center gap-1 flex-shrink-0">
            <Lightbulb className="w-3.5 h-3.5 text-amber-500" />
            {isAr ? 'اقتراحات:' : 'Suggestions:'}
          </span>
          {quickPrompts.map((prompt, i) => (
            <button
              key={i}
              onClick={() => handleSendMessage(prompt)}
              className="px-3 py-1.5 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:border-violet-500 transition-colors cursor-pointer flex-shrink-0"
            >
              {prompt}
            </button>
          ))}
        </div>

        {/* Messages Stream */}
        <div className="p-4 sm:p-6 overflow-y-auto flex-1 space-y-4">
          {messages.map((m) => {
            const isBot = m.role === 'model';
            return (
              <div
                key={m.id}
                className={`flex items-start gap-3 ${isBot ? 'flex-row' : 'flex-row-reverse'}`}
              >
                <div
                  className={`w-8 h-8 rounded-xl flex items-center justify-center flex-shrink-0 text-sm ${
                    isBot
                      ? 'bg-gradient-to-tr from-violet-600 to-indigo-600 text-white shadow-md'
                      : 'bg-emerald-500 text-slate-950 font-bold'
                  }`}
                >
                  {isBot ? <Bot className="w-4 h-4" /> : <User className="w-4 h-4" />}
                </div>

                <div
                  className={`max-w-[85%] rounded-2xl p-4 text-xs sm:text-sm leading-relaxed ${
                    isBot
                      ? 'bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-white rounded-tl-sm'
                      : 'bg-emerald-500 text-slate-950 font-medium rounded-tr-sm'
                  }`}
                >
                  <p className="whitespace-pre-line font-sans">{m.text}</p>
                  <div
                    className={`flex items-center justify-between gap-3 mt-2 text-[10px] ${
                      isBot ? 'text-slate-400' : 'text-slate-900/60'
                    }`}
                  >
                    <span>{m.timestamp}</span>
                    {isBot && (
                      <button
                        onClick={() => speakText(m.text)}
                        className="hover:text-violet-600 cursor-pointer p-0.5"
                        title={isAr ? 'استمع للإجابة' : 'Listen'}
                      >
                        <Volume2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}

          {loading && (
            <div className="flex items-center gap-2 text-xs text-slate-400 p-2">
              <Bot className="w-4 h-4 animate-spin text-violet-500" />
              <span>{isAr ? 'المساعد الذكي يجهز الإجابة التعليمية...' : 'English Mate AI is typing...'}</span>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Input Bar */}
        <div className="p-3 sm:p-4 bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSendMessage();
            }}
            className="flex items-center gap-2"
          >
            <input
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder={
                isAr
                  ? 'اكتب سؤالك هنا باللغة العربية أو الإنجليزية...'
                  : 'Ask about Grade 10 English lessons, grammar, or vocabulary...'
              }
              className="flex-1 p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs sm:text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-violet-500"
            />
            <button
              type="submit"
              disabled={!inputText.trim() || loading}
              className="p-3 rounded-xl bg-violet-600 hover:bg-violet-500 disabled:opacity-50 text-white font-bold cursor-pointer transition-colors shadow-md"
            >
              <Send className="w-4 h-4 rtl:rotate-180" />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
