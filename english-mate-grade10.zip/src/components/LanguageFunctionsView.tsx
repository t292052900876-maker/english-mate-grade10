import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { LANGUAGE_FUNCTIONS } from '../data/functionsData';
import {
  MessageSquare,
  Volume2,
  Sparkles,
  CheckCircle2,
  HelpCircle,
  Search,
  BookOpen,
} from 'lucide-react';

export const LanguageFunctionsView: React.FC = () => {
  const { language, speakText } = useApp();
  const isAr = language === 'ar';

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedFunctionId, setSelectedFunctionId] = useState<string>(LANGUAGE_FUNCTIONS[0].id);

  const filteredFunctions = LANGUAGE_FUNCTIONS.filter(
    (fn) =>
      fn.categoryEn.toLowerCase().includes(searchQuery.toLowerCase()) ||
      fn.categoryAr.includes(searchQuery) ||
      fn.expressions.some((exp) => exp.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  const activeFunction =
    LANGUAGE_FUNCTIONS.find((fn) => fn.id === selectedFunctionId) || LANGUAGE_FUNCTIONS[0];

  return (
    <div className="space-y-8 animate-fadeIn">
      {/* Header */}
      <div>
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-100 dark:bg-indigo-950/80 text-indigo-800 dark:text-indigo-300 text-xs font-bold border border-indigo-300 dark:border-indigo-800 mb-2">
          <MessageSquare className="w-3.5 h-3.5" />
          <span>{isAr ? 'بنك الوظائف اللغوية ص 93 - 94' : 'Language Functions Bank pp. 93–94'}</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white">
          {isAr ? 'بنك الوظائف اللغوية التفاعلي' : 'Interactive Functions Bank'}
        </h1>
        <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400">
          {isAr
            ? 'تدرب على المواقف التعبيرية الأساسية لأسئلة الوظائف اللغوية في الاختبارات مع الاستماع الصوتي'
            : 'Master key communicative functions and phrases essential for Ministry of Education speaking and writing tests'}
        </p>
      </div>

      {/* Search Bar */}
      <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
        <div className="relative">
          <Search className="absolute right-3.5 top-3.5 w-5 h-5 text-slate-400 rtl:right-3.5 rtl:left-auto ltr:left-3.5 ltr:right-auto" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={
              isAr
                ? 'ابحث في الوظائف اللغوية (مثل: advice, opinion, تحذير, اقتراح)...'
                : 'Search functions or phrases (e.g., advice, agree, warning)...'
            }
            className="w-full py-3 px-11 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
        </div>
      </div>

      {/* Main Grid: Categories on Left / Active Card on Right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Categories Sidebar */}
        <div className="lg:col-span-5 space-y-2 max-h-[600px] overflow-y-auto pr-1">
          {filteredFunctions.map((fn) => {
            const isSelected = fn.id === activeFunction.id;
            return (
              <button
                key={fn.id}
                onClick={() => setSelectedFunctionId(fn.id)}
                className={`w-full p-4 rounded-2xl text-start transition-all cursor-pointer border flex items-center justify-between gap-3 ${
                  isSelected
                    ? 'bg-indigo-600 text-white border-indigo-600 shadow-md shadow-indigo-600/20'
                    : 'bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-200 border-slate-200 dark:border-slate-800 hover:border-indigo-500/50'
                }`}
              >
                <div>
                  <span className={`text-[11px] font-bold block ${isSelected ? 'text-indigo-200' : 'text-slate-400'}`}>
                    {isAr ? `كتاب الطالب ص ${fn.page}` : `Student Book p. ${fn.page}`}
                  </span>
                  <h4 className="font-extrabold text-xs sm:text-sm">
                    {isAr ? fn.categoryAr : fn.categoryEn}
                  </h4>
                  <p className={`text-[11px] font-sans ${isSelected ? 'text-indigo-100' : 'text-slate-500'}`}>
                    {fn.categoryEn}
                  </p>
                </div>
                <span className={`px-2 py-0.5 rounded-full text-[11px] font-bold ${isSelected ? 'bg-white/20 text-white' : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400'}`}>
                  {fn.expressions.length}
                </span>
              </button>
            );
          })}
        </div>

        {/* Selected Function Deep-Dive Card */}
        <div className="lg:col-span-7 space-y-6">
          <div className="p-6 sm:p-8 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-6">
            <div className="border-b border-slate-100 dark:border-slate-800 pb-5 space-y-1">
              <span className="text-xs font-bold text-indigo-600 dark:text-indigo-400">
                {isAr ? `الوظيفة اللغوية (ص ${activeFunction.page})` : `Language Function (p. ${activeFunction.page})`}
              </span>
              <h2 className="text-2xl font-black text-slate-900 dark:text-white">
                {isAr ? activeFunction.categoryAr : activeFunction.categoryEn}
              </h2>
              <p className="text-xs text-slate-400 font-sans">{activeFunction.categoryEn}</p>
            </div>

            {/* Expressions List with Audio */}
            <div className="space-y-3">
              <span className="text-xs font-black uppercase text-slate-400 tracking-wider block">
                {isAr ? 'التعبيرات المعتمدة للحفظ والاستخدام:' : 'Key Model Expressions:'}
              </span>

              <div className="space-y-2">
                {activeFunction.expressions.map((exp, idx) => (
                  <div
                    key={idx}
                    dir="ltr"
                    className="flex items-center justify-between gap-3 p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 hover:border-indigo-500/50 transition-colors"
                  >
                    <span className="text-xs sm:text-sm font-bold text-slate-900 dark:text-white font-sans">
                      {exp}
                    </span>
                    <button
                      onClick={() => speakText(exp)}
                      className="p-1.5 rounded-lg text-slate-400 hover:text-indigo-600 hover:bg-white dark:hover:bg-slate-700 transition-colors cursor-pointer flex-shrink-0"
                      title={isAr ? 'استمع للتعبير' : 'Listen'}
                    >
                      <Volume2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            </div>

            {/* Exam Simulation Scenario Dialogue */}
            <div className="space-y-3 pt-2">
              <span className="text-xs font-black uppercase text-slate-400 tracking-wider block">
                {isAr ? 'نموذج محاكاة لأسئلة الاختبار (Situational Dialogue):' : 'Exam Dialogue Demonstration:'}
              </span>

              <div className="p-5 rounded-2xl bg-indigo-50/50 dark:bg-indigo-950/20 border border-indigo-200 dark:border-indigo-900/50 space-y-3">
                <div className="flex items-start gap-3">
                  <span className="w-7 h-7 rounded-full bg-indigo-600 text-white flex items-center justify-center font-bold text-xs flex-shrink-0">
                    A
                  </span>
                  <div>
                    <span className="text-[11px] font-bold text-indigo-700 dark:text-indigo-300 block">
                      {activeFunction.exampleDialogue.speakerA}
                    </span>
                    <p dir="ltr" className="text-xs sm:text-sm text-slate-800 dark:text-slate-200 font-sans">
                      "{activeFunction.exampleDialogue.textA}"
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <span className="w-7 h-7 rounded-full bg-emerald-600 text-white flex items-center justify-center font-bold text-xs flex-shrink-0">
                    B
                  </span>
                  <div>
                    <span className="text-[11px] font-bold text-emerald-700 dark:text-emerald-300 block">
                      {activeFunction.exampleDialogue.speakerB}
                    </span>
                    <p dir="ltr" className="text-xs sm:text-sm text-slate-800 dark:text-slate-200 font-sans font-semibold">
                      "{activeFunction.exampleDialogue.textB}"
                    </p>
                  </div>
                </div>

                <div className="pt-2 text-end">
                  <button
                    onClick={() =>
                      speakText(
                        `${activeFunction.exampleDialogue.speakerA} says: ${activeFunction.exampleDialogue.textA}. ${activeFunction.exampleDialogue.speakerB} replies: ${activeFunction.exampleDialogue.textB}`
                      )
                    }
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-700 dark:text-slate-200 hover:border-indigo-500 cursor-pointer"
                  >
                    <Volume2 className="w-3.5 h-3.5 text-indigo-500" />
                    <span>{isAr ? 'استمع للمحادثة كاملة' : 'Listen to Full Dialogue'}</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
