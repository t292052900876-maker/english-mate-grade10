import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  User,
  Award,
  Trophy,
  CheckCircle2,
  Bookmark,
  Sparkles,
  Download,
  RotateCcw,
  BookOpen,
  Edit2,
  Save,
  Printer,
} from 'lucide-react';
import confetti from 'canvas-confetti';

const AVATARS = ['🎓', '🏆', '🌟', '📚', '🇰🇼', '🦅', '🚀', '💡', '🌱', '🎨'];

export const StudentProfileView: React.FC = () => {
  const { language, student, updateStudent } = useApp();
  const isAr = language === 'ar';

  const [isEditing, setIsEditing] = useState(false);
  const [nameInput, setNameInput] = useState(student.name);
  const [schoolInput, setSchoolInput] = useState(student.school);

  const handleSaveProfile = () => {
    updateStudent({
      name: nameInput.trim() || (isAr ? 'طالب الصف العاشر' : 'Grade 10 Scholar'),
      school: schoolInput.trim() || (isAr ? 'مدارس دولة الكويت' : 'Kuwait Secondary School'),
    });
    setIsEditing(false);
    confetti({ particleCount: 35, spread: 45 });
  };

  const handleSelectAvatar = (av: string) => {
    updateStudent({ avatar: av });
  };

  const completedCount = student.completedLessons.length;
  const quizzesList = Object.entries(student.completedQuizzes);

  // Badges logic
  const badges = [
    {
      id: 'b1',
      titleEn: 'Nutrition Pioneer',
      titleAr: 'رائد التغذية السليمة',
      descEn: 'Completed Unit 1: The Science of Nutrition lessons',
      descAr: 'إنجاز دروس الوحدة الأولى (علم التغذية)',
      icon: '🥗',
      unlocked: student.completedLessons.filter((id) => id.startsWith('u1')).length >= 2,
    },
    {
      id: 'b2',
      titleEn: 'Eco Guardian',
      titleAr: 'حامي البيئة والاستدامة',
      descEn: 'Completed Unit 2: Choices & Change lessons',
      descAr: 'إنجاز دروس الوحدة الثانية (خيارات وتغيير)',
      icon: '🌱',
      unlocked: student.completedLessons.filter((id) => id.startsWith('u2')).length >= 2,
    },
    {
      id: 'b3',
      titleEn: 'Heritage Ambassador',
      titleAr: 'سفير التراث الكويتي',
      descEn: 'Explored Unit 3: Kuwaiti cultural icons and Sadu weaving',
      descAr: 'استكشاف التراث وفنون السدو والرواد',
      icon: '🏛️',
      unlocked: student.completedLessons.filter((id) => id.startsWith('u3')).length >= 1,
    },
    {
      id: 'b4',
      titleEn: 'Exemplary Citizen',
      titleAr: 'المواطن الصالح القدوة',
      descEn: 'Studied Unit 4: The Constitution and National Duties',
      descAr: 'دراسة الدستور والواجبات الوطنية وقيم المواطنة',
      icon: '🇰🇼',
      unlocked: student.completedLessons.filter((id) => id.startsWith('u4')).length >= 1,
    },
    {
      id: 'b5',
      titleEn: 'Grammar Master',
      titleAr: 'فارس القواعد التسع',
      descEn: 'Scored 80%+ on unit quizzes',
      descAr: 'تحقيق نتائج متفوقة في اختبارات القواعد',
      icon: '⚖️',
      unlocked: student.totalScore >= 150,
    },
    {
      id: 'b6',
      titleEn: 'English Mate Scholar',
      titleAr: 'وسام التفوق والامتياز',
      descEn: 'Earned 200+ learning points',
      descAr: 'تجاوز 200 نقطة في المنصة التعليمية',
      icon: '🎖️',
      unlocked: student.totalScore >= 200,
    },
  ];

  return (
    <div className="space-y-8 animate-fadeIn">
      {/* Profile Header Card */}
      <div className="relative overflow-hidden rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 sm:p-10 shadow-sm">
        <div className="flex flex-col md:flex-row items-center md:items-start gap-6">
          {/* Avatar */}
          <div className="relative group">
            <div className="w-24 h-24 sm:w-28 sm:h-28 rounded-3xl bg-gradient-to-tr from-emerald-500 via-teal-500 to-cyan-500 flex items-center justify-center text-4xl sm:text-5xl shadow-xl shadow-emerald-500/20">
              {student.avatar}
            </div>
          </div>

          {/* Details */}
          <div className="flex-1 text-center md:text-start space-y-3">
            {!isEditing ? (
              <>
                <div className="flex flex-col sm:flex-row sm:items-center gap-2 justify-center md:justify-start">
                  <h1 className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white">
                    {student.name}
                  </h1>
                  <button
                    onClick={() => setIsEditing(true)}
                    className="inline-flex items-center gap-1 text-xs font-bold text-emerald-600 dark:text-emerald-400 hover:underline cursor-pointer self-center sm:self-auto"
                  >
                    <Edit2 className="w-3.5 h-3.5" />
                    <span>{isAr ? 'تعديل البيانات' : 'Edit Profile'}</span>
                  </button>
                </div>
                <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400">
                  {student.school}
                </p>
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-slate-100 dark:bg-slate-800 text-xs font-bold text-slate-700 dark:text-slate-300">
                  <span>{isAr ? 'الصف العاشر الثانوي (Grade 10A)' : 'Grade 10 Secondary Student'}</span>
                  <span>•</span>
                  <span>{isAr ? 'العام الدراسي 2026/2027' : 'Academic Year 2026/2027'}</span>
                </div>
              </>
            ) : (
              <div className="space-y-3 max-w-md">
                <div>
                  <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block mb-1">
                    {isAr ? 'اسم الطالب:' : 'Student Name:'}
                  </label>
                  <input
                    type="text"
                    value={nameInput}
                    onChange={(e) => setNameInput(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs font-bold text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block mb-1">
                    {isAr ? 'اسم المدرسة / المنطقة التعليمية:' : 'School / Educational District:'}
                  </label>
                  <input
                    type="text"
                    value={schoolInput}
                    onChange={(e) => setSchoolInput(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs font-bold text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={handleSaveProfile}
                    className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-emerald-500 text-slate-950 font-black text-xs cursor-pointer shadow-md"
                  >
                    <Save className="w-3.5 h-3.5" />
                    <span>{isAr ? 'حفظ البيانات' : 'Save Changes'}</span>
                  </button>
                  <button
                    onClick={() => setIsEditing(false)}
                    className="px-3 py-2 rounded-xl text-xs font-bold text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                  >
                    {isAr ? 'إلغاء' : 'Cancel'}
                  </button>
                </div>
              </div>
            )}

            {/* Avatar selector pills */}
            <div className="pt-2">
              <span className="text-[11px] font-bold text-slate-400 block mb-1.5">
                {isAr ? 'اختر رمزك التعبيري المفضل:' : 'Select Your Avatar:'}
              </span>
              <div className="flex flex-wrap gap-1.5 justify-center md:justify-start">
                {AVATARS.map((av) => (
                  <button
                    key={av}
                    onClick={() => handleSelectAvatar(av)}
                    className={`w-8 h-8 rounded-xl text-lg flex items-center justify-center transition-transform hover:scale-110 cursor-pointer ${
                      student.avatar === av
                        ? 'bg-emerald-500/20 border-2 border-emerald-500'
                        : 'bg-slate-100 dark:bg-slate-800'
                    }`}
                  >
                    {av}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Points & Score Card */}
          <div className="w-full md:w-60 p-5 rounded-2xl bg-gradient-to-br from-amber-500/10 to-orange-500/10 border border-amber-500/30 text-center space-y-1">
            <span className="text-xs font-black text-amber-600 dark:text-amber-400 uppercase tracking-widest block">
              {isAr ? 'إجمالي النقاط المكتسبة' : 'Total Score'}
            </span>
            <div className="text-4xl font-black text-slate-900 dark:text-white">
              {student.totalScore}
            </div>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 font-medium">
              {isAr ? 'واصل التعلم وحل الاختبارات لجمع المزيد!' : 'Keep learning to unlock new badges!'}
            </p>
          </div>
        </div>
      </div>

      {/* Badges & Achievements Grid */}
      <div className="space-y-4">
        <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white flex items-center gap-2">
          <Award className="w-6 h-6 text-amber-500" />
          <span>{isAr ? 'الأوسمة والإنجازات الأكاديمية' : 'Achievements & Badges'}</span>
        </h2>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {badges.map((b) => (
            <div
              key={b.id}
              className={`p-5 rounded-2xl border transition-all flex items-center gap-4 ${
                b.unlocked
                  ? 'bg-white dark:bg-slate-900 border-amber-500/40 shadow-sm'
                  : 'bg-slate-50 dark:bg-slate-800/30 border-slate-200 dark:border-slate-800 opacity-60'
              }`}
            >
              <div
                className={`w-14 h-14 rounded-2xl flex items-center justify-center text-2xl flex-shrink-0 ${
                  b.unlocked
                    ? 'bg-amber-100 dark:bg-amber-950/80 shadow-md shadow-amber-500/10'
                    : 'bg-slate-200 dark:bg-slate-800 grayscale'
                }`}
              >
                {b.icon}
              </div>
              <div className="space-y-0.5">
                <div className="flex items-center gap-1.5">
                  <h3 className="text-sm font-extrabold text-slate-900 dark:text-white">
                    {isAr ? b.titleAr : b.titleEn}
                  </h3>
                  {b.unlocked && (
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500 flex-shrink-0" />
                  )}
                </div>
                <p className="text-xs text-slate-500 dark:text-slate-400 leading-snug">
                  {isAr ? b.descAr : b.descEn}
                </p>
                <span className="text-[10px] font-bold text-amber-600 dark:text-amber-400 block pt-1">
                  {b.unlocked ? (isAr ? '✓ تم الحصول عليه' : 'Unlocked') : isAr ? '🔒 قيد الإنجاز' : 'Locked'}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Quiz History Table */}
      <div className="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
        <h3 className="text-lg font-black text-slate-900 dark:text-white flex items-center gap-2">
          <Trophy className="w-5 h-5 text-emerald-500" />
          <span>{isAr ? 'سجل درجات الاختبارات المسجلة' : 'Recorded Quiz History'}</span>
        </h3>

        {quizzesList.length === 0 ? (
          <p className="text-xs text-slate-400 py-4 text-center">
            {isAr ? 'لم تخض أي اختبار بعد. ابدأ باختبار الوحدة الأولى الآن!' : 'No quizzes completed yet. Take Unit 1 quiz to record your score!'}
          </p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-xs text-start">
              <thead className="bg-slate-50 dark:bg-slate-800 text-slate-500 dark:text-slate-300 border-b border-slate-200 dark:border-slate-700">
                <tr>
                  <th className="p-3 text-start font-bold">{isAr ? 'الاختبار' : 'Assessment'}</th>
                  <th className="p-3 text-start font-bold">{isAr ? 'الدرجة' : 'Score'}</th>
                  <th className="p-3 text-start font-bold">{isAr ? 'النسبة' : 'Percentage'}</th>
                  <th className="p-3 text-start font-bold">{isAr ? 'التاريخ' : 'Date'}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {quizzesList.map(([quizKey, qData]) => {
                  const pct = Math.round((qData.score / qData.total) * 100);
                  return (
                    <tr key={quizKey} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/40">
                      <td className="p-3 font-extrabold text-slate-900 dark:text-white capitalize">
                        {quizKey.replace('-', ' ')}
                      </td>
                      <td className="p-3 font-bold text-emerald-600 dark:text-emerald-400">
                        {qData.score} / {qData.total}
                      </td>
                      <td className="p-3 font-semibold text-slate-700 dark:text-slate-200">
                        {pct}%
                      </td>
                      <td className="p-3 text-slate-400 font-mono">
                        {qData.date}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Export Project ZIP & Backup Card */}
      <div className="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="space-y-1 text-center sm:text-start">
          <div className="flex items-center justify-center sm:justify-start gap-2 text-xs font-bold text-emerald-600 dark:text-emerald-400">
            <Download className="w-4 h-4" />
            <span>{isAr ? 'تصدير المشروع كاملاً (Standalone Export)' : 'Export Full Project Package'}</span>
          </div>
          <h4 className="text-base font-black text-slate-900 dark:text-white">
            {isAr ? 'تحميل كود المشروع بصيغة ZIP للنشر الخارجي' : 'Download Complete Project ZIP Archive'}
          </h4>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            {isAr
              ? 'تحتوي حزمة ZIP على جميع ملفات الكود، كتاب الطالب PDF، الخادم، والدليل الكامل README للاستضافة الخارجية على GitHub أو Render.'
              : 'Includes all source files, textbook PDF, Express server, and GitHub/Render deployment documentation.'}
          </p>
        </div>

        <a
          href="/english-mate-grade10.zip"
          download="english-mate-grade10.zip"
          className="inline-flex items-center gap-2 px-5 py-3 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs sm:text-sm shadow-md transition-all cursor-pointer flex-shrink-0 active:scale-95"
        >
          <Download className="w-4 h-4" />
          <span>{isAr ? 'تحميل المشروع الآن (ZIP)' : 'Download ZIP Package'}</span>
        </a>
      </div>

      {/* Official Certificate of Achievement Preview */}
      <div className="p-8 rounded-3xl bg-gradient-to-r from-emerald-950 via-teal-950 to-slate-950 border-2 border-emerald-500/30 text-white shadow-2xl relative overflow-hidden text-center space-y-4">
        <div className="w-16 h-16 mx-auto rounded-full bg-emerald-500/20 text-amber-300 flex items-center justify-center border border-amber-300/40 shadow-inner">
          <Award className="w-9 h-9" />
        </div>

        <span className="text-xs font-bold text-emerald-300 uppercase tracking-widest block">
          State of Kuwait • Ministry of Education
        </span>
        <h3 className="text-2xl sm:text-3xl font-black text-white">
          {isAr ? 'شهادة إنجاز وتفوق في اللغة الإنجليزية' : 'Certificate of Academic Achievement'}
        </h3>
        <p className="text-xs sm:text-sm text-slate-300 max-w-lg mx-auto">
          {isAr
            ? `تمنح هذه الشهادة للطالب/ـة المتميز/ة (${student.name}) تقديراً لإنجازه المتميز وتفوقه في مقرر اللغة الإنجليزية للصف العاشر وفق منهج Origin to Outlook.`
            : `Presented to (${student.name}) in recognition of outstanding learning dedication in English Grade 10.`}
        </p>

        <div className="pt-4 flex justify-center">
          <button
            onClick={() => window.print()}
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-xs shadow-lg cursor-pointer transition-transform active:scale-95"
          >
            <Printer className="w-4 h-4" />
            <span>{isAr ? 'طباعة شهادة التقدير' : 'Print Certificate'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
