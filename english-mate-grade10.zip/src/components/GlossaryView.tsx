import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import { GLOSSARY_WORDS } from '../data/glossaryData';
import { VocabularyWord } from '../types';
import {
  Search,
  Volume2,
  Bookmark,
  BookA,
  Sparkles,
  Layers,
  RotateCw,
  ExternalLink,
  Filter,
} from 'lucide-react';

export const GlossaryView: React.FC = () => {
  const { language, student, toggleBookmark, speakText } = useApp();
  const isAr = language === 'ar';

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedUnit, setSelectedUnit] = useState<number | 'all'>('all');
  const [selectedPos, setSelectedPos] = useState<string>('all');
  const [studyMode, setStudyMode] = useState<boolean>(false);
  const [flippedCards, setFlippedCards] = useState<Record<string, boolean>>({});

  const filteredWords = useMemo(() => {
    return GLOSSARY_WORDS.filter((word) => {
      const matchesSearch =
        word.word.toLowerCase().includes(searchQuery.toLowerCase()) ||
        word.arabicMeaning.includes(searchQuery) ||
        word.englishDefinition.toLowerCase().includes(searchQuery.toLowerCase());

      const matchesUnit = selectedUnit === 'all' || word.unit === selectedUnit;
      const matchesPos =
        selectedPos === 'all' || word.partOfSpeech.toLowerCase().includes(selectedPos.toLowerCase());

      return matchesSearch && matchesUnit && matchesPos;
    });
  }, [searchQuery, selectedUnit, selectedPos]);

  const toggleFlip = (id: string) => {
    setFlippedCards((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  return (
    <div className="space-y-8 animate-fadeIn">
      {/* Header Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-teal-100 dark:bg-teal-950/80 text-teal-800 dark:text-teal-300 text-xs font-bold border border-teal-300 dark:border-teal-800 mb-2">
            <BookA className="w-3.5 h-3.5" />
            <span>{isAr ? 'قاموس مصطلحات كتاب الطالب ص 79 - 85' : 'Official Student Book Glossary pp. 79–85'}</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white">
            {isAr ? 'قاموس المفردات المعتمد (Glossary)' : 'Curriculum Vocabulary Dictionary'}
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400">
            {isAr
              ? `يحتوي على جميع كلمات المقرر (${GLOSSARY_WORDS.length} مفردة) مع المعاني والرموز الصوتية والأمثلة والاستماع الصوتي`
              : `All ${GLOSSARY_WORDS.length} target words with phonetic transcriptions, Arabic definitions, and audio`}
          </p>
        </div>

        {/* Study Mode Toggle */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setStudyMode(!studyMode)}
            className={`inline-flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer border ${
              studyMode
                ? 'bg-amber-500 text-slate-950 border-amber-600 shadow-md'
                : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 border-slate-200 dark:border-slate-700 hover:border-amber-500'
            }`}
          >
            <RotateCw className="w-4 h-4" />
            <span>{isAr ? 'وضع بطاقات المراجعة (Flashcards)' : 'Flashcards Mode'}</span>
          </button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
        <div className="relative">
          <Search className="absolute right-3.5 top-3.5 w-5 h-5 text-slate-400 rtl:right-3.5 rtl:left-auto ltr:left-3.5 ltr:right-auto" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={
              isAr
                ? 'ابحث بالإنجليزية أو العربية (مثل: nutritious, استدامة, heritage)...'
                : 'Search words, Arabic meanings, or definitions...'
            }
            className="w-full py-3 px-11 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white text-sm focus:outline-none focus:ring-2 focus:ring-teal-500"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2 pt-1 text-xs">
          {/* Unit Filters */}
          <span className="font-bold text-slate-400 flex items-center gap-1">
            <Filter className="w-3.5 h-3.5" />
            {isAr ? 'الوحدة:' : 'Unit:'}
          </span>
          {['all', 1, 2, 3, 4].map((u) => (
            <button
              key={u}
              onClick={() => setSelectedUnit(u as any)}
              className={`px-3 py-1.5 rounded-xl font-bold transition-colors cursor-pointer ${
                selectedUnit === u
                  ? 'bg-teal-500 text-white shadow-sm'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
              }`}
            >
              {u === 'all' ? (isAr ? 'الكل' : 'All') : isAr ? `الوحدة ${u}` : `Unit ${u}`}
            </button>
          ))}

          <span className="text-slate-300 dark:text-slate-700 mx-1">|</span>

          {/* Part of speech filters */}
          <span className="font-bold text-slate-400">{isAr ? 'النوع:' : 'Type:'}</span>
          {['all', 'noun', 'verb', 'adjective', 'adverb', 'phrasal'].map((pos) => (
            <button
              key={pos}
              onClick={() => setSelectedPos(pos)}
              className={`px-3 py-1.5 rounded-xl font-semibold transition-colors cursor-pointer capitalize ${
                selectedPos === pos
                  ? 'bg-slate-800 text-white dark:bg-white dark:text-slate-900'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
              }`}
            >
              {pos === 'all' ? (isAr ? 'الكل' : 'All') : pos}
            </button>
          ))}
        </div>
      </div>

      {/* Words Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredWords.map((item) => {
          const isBookmarked = student.bookmarks.includes(item.id);
          const isFlipped = flippedCards[item.id];

          // Flashcard Mode
          if (studyMode) {
            return (
              <div
                key={item.id}
                onClick={() => toggleFlip(item.id)}
                className="relative min-h-[220px] p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm hover:shadow-lg transition-all duration-300 cursor-pointer flex flex-col justify-between"
              >
                {!isFlipped ? (
                  <div className="flex-1 flex flex-col items-center justify-center text-center space-y-2">
                    <span className="text-xs px-2.5 py-0.5 rounded-full bg-teal-50 dark:bg-teal-950 text-teal-700 dark:text-teal-300 font-semibold border border-teal-200 dark:border-teal-800">
                      {item.partOfSpeech}
                    </span>
                    <h3 className="text-2xl font-black text-slate-900 dark:text-white">
                      {item.word}
                    </h3>
                    <p className="text-xs text-slate-400 font-mono">{item.phonetic}</p>
                    <p className="text-xs text-amber-500 font-bold pt-4">
                      {isAr ? '👆 انقر لقلب البطاقة ومعرفة المعنى' : '👆 Click to reveal meaning'}
                    </p>
                  </div>
                ) : (
                  <div className="flex-1 flex flex-col justify-between space-y-3 animate-fadeIn">
                    <div className="space-y-1">
                      <span className="text-xs font-bold text-slate-400">
                        {isAr ? `الوحدة ${item.unit} • ص ${item.page}` : `Unit ${item.unit} • p. ${item.page}`}
                      </span>
                      <h4 className="text-lg font-black text-emerald-600 dark:text-emerald-400">
                        {item.arabicMeaning}
                      </h4>
                      <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed font-sans">
                        {item.englishDefinition}
                      </p>
                    </div>

                    <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 text-xs italic text-slate-700 dark:text-slate-300 font-sans">
                      "{item.exampleSentence}"
                    </div>
                  </div>
                )}

                <div className="flex items-center justify-between pt-3 border-t border-slate-100 dark:border-slate-800 text-xs">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      speakText(item.word);
                    }}
                    className="p-1 text-slate-400 hover:text-teal-500 cursor-pointer"
                    title={isAr ? 'استمع للنطق' : 'Pronounce'}
                  >
                    <Volume2 className="w-4 h-4" />
                  </button>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      toggleBookmark(item.id);
                    }}
                    className={`p-1 cursor-pointer ${isBookmarked ? 'text-amber-500 fill-amber-500' : 'text-slate-400 hover:text-amber-500'}`}
                  >
                    <Bookmark className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          }

          // Standard Dictionary Card
          return (
            <div
              key={item.id}
              className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm hover:shadow-md hover:border-teal-500/50 transition-all flex flex-col justify-between space-y-4"
            >
              <div>
                {/* Top badges & audio */}
                <div className="flex items-start justify-between gap-2 mb-2">
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <span className="px-2 py-0.5 rounded-md text-[11px] font-bold bg-teal-50 dark:bg-teal-950 text-teal-700 dark:text-teal-300 border border-teal-200 dark:border-teal-800">
                      {item.partOfSpeech}
                    </span>
                    <span className="text-[11px] font-medium text-slate-400">
                      {isAr ? `الوحدة ${item.unit}` : `Unit ${item.unit}`}
                    </span>
                    <span className="text-[11px] font-medium text-slate-400">
                      • {isAr ? `ص ${item.page}` : `p. ${item.page}`}
                    </span>
                  </div>

                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => speakText(item.word)}
                      className="p-1.5 rounded-lg text-slate-400 hover:text-teal-600 hover:bg-teal-50 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                      title={isAr ? 'نطق الكلمة' : 'Pronounce'}
                    >
                      <Volume2 className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => toggleBookmark(item.id)}
                      className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
                        isBookmarked
                          ? 'text-amber-500 fill-amber-500'
                          : 'text-slate-400 hover:text-amber-500'
                      }`}
                      title={isAr ? 'حفظ الكلمة' : 'Bookmark'}
                    >
                      <Bookmark className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* English Word & Phonetics */}
                <div className="mb-2">
                  <h3 className="text-xl font-black text-slate-900 dark:text-white">
                    {item.word}
                  </h3>
                  <span className="text-xs text-slate-400 font-mono">{item.phonetic}</span>
                </div>

                {/* Arabic Translation */}
                <div className="p-2.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800/60 mb-3">
                  <span className="text-xs text-emerald-800 dark:text-emerald-300 font-bold">
                    {item.arabicMeaning}
                  </span>
                </div>

                {/* Definition */}
                <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed font-sans mb-3">
                  {item.englishDefinition}
                </p>
              </div>

              {/* Example sentence from textbook */}
              <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-800 text-xs text-slate-700 dark:text-slate-300 font-sans leading-relaxed">
                <span className="font-bold text-slate-400 block mb-1 text-[10px] uppercase">
                  {isAr ? 'مثال من الكتاب المدرسي:' : 'Textbook Context:'}
                </span>
                <span className="italic font-serif">"{item.exampleSentence}"</span>
              </div>
            </div>
          );
        })}
      </div>

      {filteredWords.length === 0 && (
        <div className="p-12 text-center rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
          <BookA className="w-12 h-12 text-slate-400 mx-auto mb-3" />
          <h3 className="text-base font-bold text-slate-700 dark:text-slate-300">
            {isAr ? 'لم يتم العثور على كلمات مطابقة للبحث' : 'No vocabulary matching your search'}
          </h3>
          <p className="text-xs text-slate-400 mt-1">
            {isAr ? 'جرب البحث بكلمة أخرى أو قم بإلغاء التصفية' : 'Try searching another word or clear filters'}
          </p>
        </div>
      )}
    </div>
  );
};
