import React from 'react';
import { useApp } from '../context/AppContext';
import { UNITS_DATA } from '../data/unitsData';
import { GLOSSARY_WORDS } from '../data/glossaryData';
import { GRAMMAR_RULES } from '../data/grammarData';
import { LANGUAGE_FUNCTIONS } from '../data/functionsData';
import {
  BookOpen,
  Sparkles,
  BookA,
  MessageSquare,
  PenTool,
  CheckCircle,
  ArrowRight,
  ArrowLeft,
  Trophy,
  Flame,
  Bot,
  Compass,
  Star,
  ExternalLink,
} from 'lucide-react';

export const Dashboard: React.FC = () => {
  const {
    language,
    student,
    setCurrentSection,
    setSelectedUnitId,
    setSelectedLessonId,
    setIsAiModalOpen,
  } = useApp();

  const isAr = language === 'ar';
  const ArrowIcon = isAr ? ArrowLeft : ArrowRight;

  const totalLessons = UNITS_DATA.reduce((acc, u) => acc + u.lessons.length, 0);
  const completedCount = student.completedLessons.length;
  const progressPercent = Math.min(100, Math.round((completedCount / totalLessons) * 100));
  const quizzesTakenCount = Object.keys(student.completedQuizzes).length;

  const handleStartUnit = (unitId: number) => {
    setSelectedUnitId(unitId);
    setSelectedLessonId(null);
    setCurrentSection('units');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="space-y-10 animate-fadeIn">
      {/* Hero Welcome Banner */}
      <section className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-emerald-900 via-teal-900 to-slate-900 text-white p-6 sm:p-10 shadow-2xl border border-emerald-500/20">
        {/* Subtle decorative background circles */}
        <div className="absolute -right-20 -top-20 w-80 h-80 rounded-full bg-emerald-500/10 blur-3xl pointer-events-none" />
        <div className="absolute -left-20 -bottom-20 w-80 h-80 rounded-full bg-cyan-500/10 blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col lg:flex-row items-start lg:items-center justify-between gap-8">
          <div className="max-w-2xl space-y-4">
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/10 backdrop-blur-md border border-white/15 text-xs sm:text-sm font-semibold text-emerald-300">
              <span className="text-base">{student.avatar}</span>
              <span>{isAr ? 'أهلاً بك مجدداً يا بطل' : 'Welcome back, Scholar'}</span>
              <span className="text-white/40">•</span>
              <span className="text-amber-300 flex items-center gap-1 font-bold">
                <Flame className="w-3.5 h-3.5 fill-amber-300 text-amber-300" />
                {student.totalScore} {isAr ? 'نقطة تفوق' : 'Points'}
              </span>
            </div>

            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black tracking-tight leading-tight">
              {student.name}
            </h1>
            <p className="text-slate-300 text-sm sm:text-base leading-relaxed">
              {isAr
                ? 'استعد لرحلة تعلم شيقة وممتعة في مقرر اللغة الإنجليزية للصف العاشر وفق كتاب الطالب المعتمد Origin to Outlook (2026/2027) لوزارة التربية بدولة الكويت.'
                : 'Prepare for an engaging learning journey in Grade 10 English based on the official Kuwait Ministry of Education curriculum Origin to Outlook.'}
            </p>

            <div className="flex flex-wrap items-center gap-3 pt-2">
              <button
                onClick={() => handleStartUnit(1)}
                className="inline-flex items-center gap-2 px-5 py-3 rounded-2xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-sm shadow-lg shadow-emerald-500/30 transition-all hover:scale-105 active:scale-95 cursor-pointer"
              >
                <span>{isAr ? 'ابدأ من الوحدة الأولى' : 'Start Unit One'}</span>
                <ArrowIcon className="w-4 h-4" />
              </button>

              <button
                onClick={() => setIsAiModalOpen(true)}
                className="inline-flex items-center gap-2 px-5 py-3 rounded-2xl bg-white/10 hover:bg-white/20 border border-white/20 text-white font-bold text-sm backdrop-blur-md transition-all active:scale-95 cursor-pointer"
              >
                <Bot className="w-4 h-4 text-amber-300" />
                <span>{isAr ? 'تحدث مع المساعد الذكي' : 'Ask AI Tutor'}</span>
              </button>

              <a
                href="/assets/aistudio/Grade_10_Student_Book_A_compressed_48dec60f.pdf"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-4 py-3 rounded-2xl bg-white/10 hover:bg-white/20 border border-white/20 text-slate-200 hover:text-white font-bold text-xs sm:text-sm backdrop-blur-md transition-all cursor-pointer"
              >
                <BookOpen className="w-4 h-4 text-emerald-300" />
                <span>{isAr ? 'كتاب الطالب PDF الأصلي' : 'Original Student Book PDF'}</span>
                <ExternalLink className="w-3.5 h-3.5 opacity-60" />
              </a>
            </div>
          </div>

          {/* Quick Progress Card */}
          <div className="w-full lg:w-80 bg-white/10 backdrop-blur-xl border border-white/20 rounded-2xl p-6 text-white shadow-xl space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-300 uppercase tracking-wider">
                {isAr ? 'مؤشر التقدم العام' : 'Overall Progress'}
              </span>
              <span className="text-lg font-black text-emerald-400">{progressPercent}%</span>
            </div>

            {/* Progress bar */}
            <div className="w-full h-3 rounded-full bg-slate-800/80 overflow-hidden border border-white/10">
              <div
                className="h-full bg-gradient-to-r from-emerald-400 to-cyan-400 transition-all duration-700"
                style={{ width: `${progressPercent}%` }}
              />
            </div>

            <div className="grid grid-cols-2 gap-3 pt-2 text-center">
              <div className="p-3 rounded-xl bg-white/5 border border-white/10">
                <p className="text-2xl font-black text-white">{completedCount}</p>
                <p className="text-[11px] text-slate-300 font-medium">
                  {isAr ? `من أصل ${totalLessons} درساً` : `of ${totalLessons} Lessons`}
                </p>
              </div>
              <div className="p-3 rounded-xl bg-white/5 border border-white/10">
                <p className="text-2xl font-black text-amber-300">{quizzesTakenCount}</p>
                <p className="text-[11px] text-slate-300 font-medium">
                  {isAr ? 'اختبارات تم إنجازها' : 'Quizzes Done'}
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Quick Navigation Cards */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 dark:text-white">
              {isAr ? 'الأقسام التعليمية الرئيسية' : 'Key Learning Hubs'}
            </h2>
            <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400">
              {isAr
                ? 'انتقل فورياً إلى القاموس، مركز القواعد، بنك الوظائف اللغوية والاختبارات التفاعلية'
                : 'Instantly jump to the official glossary, grammar rules, functions, or quizzes'}
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {/* Card 1: Units & Lessons */}
          <div
            onClick={() => {
              setCurrentSection('units');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className="group relative p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-emerald-500 dark:hover:border-emerald-500 hover:shadow-xl hover:shadow-emerald-500/10 transition-all cursor-pointer"
          >
            <div className="w-12 h-12 rounded-xl bg-emerald-100 dark:bg-emerald-950/80 text-emerald-600 dark:text-emerald-400 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
              <BookOpen className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-slate-900 dark:text-white mb-1 group-hover:text-emerald-600 dark:group-hover:text-emerald-400 transition-colors">
              {isAr ? 'الوحدات الأربع والدروس' : 'The 4 Units & Lessons'}
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mb-4 line-clamp-2">
              {isAr
                ? '44 درساً متكاملاً بالترتيب الدقيق وفق منهج كتاب الطالب Grade 10A.'
                : 'All 44 curriculum lessons in sequential order from Student Book 10A.'}
            </p>
            <div className="flex items-center justify-between text-xs font-bold text-emerald-600 dark:text-emerald-400">
              <span>{isAr ? '4 وحدات • 44 درساً' : '4 Units • 44 Lessons'}</span>
              <ArrowIcon className="w-4 h-4 group-hover:translate-x-1 rtl:group-hover:-translate-x-1 transition-transform" />
            </div>
          </div>

          {/* Card 2: Glossary */}
          <div
            onClick={() => {
              setCurrentSection('glossary');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className="group relative p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-teal-500 dark:hover:border-teal-500 hover:shadow-xl hover:shadow-teal-500/10 transition-all cursor-pointer"
          >
            <div className="w-12 h-12 rounded-xl bg-teal-100 dark:bg-teal-950/80 text-teal-600 dark:text-teal-400 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
              <BookA className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-slate-900 dark:text-white mb-1 group-hover:text-teal-600 dark:group-hover:text-teal-400 transition-colors">
              {isAr ? 'قاموس المفردات الشامل' : 'Textbook Glossary'}
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mb-4 line-clamp-2">
              {isAr
                ? 'أكثر من 80 كلمة مع المعاني العربية، النطق الصوتي، والتعريف والصفحة.'
                : '80+ target vocabulary with phonetics, Arabic translations, and audio playback.'}
            </p>
            <div className="flex items-center justify-between text-xs font-bold text-teal-600 dark:text-teal-400">
              <span>{GLOSSARY_WORDS.length} {isAr ? 'مفردة معتمدة' : 'Official Words'}</span>
              <ArrowIcon className="w-4 h-4 group-hover:translate-x-1 rtl:group-hover:-translate-x-1 transition-transform" />
            </div>
          </div>

          {/* Card 3: Grammar Center */}
          <div
            onClick={() => {
              setCurrentSection('grammar');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className="group relative p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-amber-500 dark:hover:border-amber-500 hover:shadow-xl hover:shadow-amber-500/10 transition-all cursor-pointer"
          >
            <div className="w-12 h-12 rounded-xl bg-amber-100 dark:bg-amber-950/80 text-amber-600 dark:text-amber-400 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
              <Sparkles className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-slate-900 dark:text-white mb-1 group-hover:text-amber-600 dark:group-hover:text-amber-400 transition-colors">
              {isAr ? 'مركز القواعد التسع' : 'Grammar Center (9 Rules)'}
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mb-4 line-clamp-2">
              {isAr
                ? 'شرح شامل لقواعد الكتاب التسع وأداة OSASCOMP وجداول الأفعال الشاذة والجامدة.'
                : 'In-depth guide to all 9 Grammar File rules, OSASCOMP builder, and irregular verbs.'}
            </p>
            <div className="flex items-center justify-between text-xs font-bold text-amber-600 dark:text-amber-400">
              <span>{GRAMMAR_RULES.length} {isAr ? 'قواعد أساسية' : 'Core Rules'}</span>
              <ArrowIcon className="w-4 h-4 group-hover:translate-x-1 rtl:group-hover:-translate-x-1 transition-transform" />
            </div>
          </div>

          {/* Card 4: Language Functions */}
          <div
            onClick={() => {
              setCurrentSection('functions');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className="group relative p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-indigo-500 dark:hover:border-indigo-500 hover:shadow-xl hover:shadow-indigo-500/10 transition-all cursor-pointer"
          >
            <div className="w-12 h-12 rounded-xl bg-indigo-100 dark:bg-indigo-950/80 text-indigo-600 dark:text-indigo-400 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
              <MessageSquare className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-slate-900 dark:text-white mb-1 group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-colors">
              {isAr ? 'بنك الوظائف اللغوية' : 'Language Functions'}
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mb-4 line-clamp-2">
              {isAr
                ? 'أكثر من 24 موقفاً تواصلياً مع التعبيرات وأمثلة الحوار للامتحانات.'
                : '24+ communicative situations with expressions and exam dialogues.'}
            </p>
            <div className="flex items-center justify-between text-xs font-bold text-indigo-600 dark:text-indigo-400">
              <span>{LANGUAGE_FUNCTIONS.length} {isAr ? 'موقفاً وظيفياً' : 'Situations'}</span>
              <ArrowIcon className="w-4 h-4 group-hover:translate-x-1 rtl:group-hover:-translate-x-1 transition-transform" />
            </div>
          </div>
        </div>
      </section>

      {/* The 4 Units Detailed Grid */}
      <section className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 dark:text-white">
              {isAr ? 'الوحدات الدراسية الأربع (Grade 10A)' : 'The Four Curriculum Units'}
            </h2>
            <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400">
              {isAr
                ? 'مرتبة بالكامل وفق فهرس كتاب الطالب Origin to Outlook مع تفاصيل الدروس'
                : 'Sequenced strictly in textbook order with all 11 lessons per unit'}
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {UNITS_DATA.map((unit) => {
            const unitLessons = unit.lessons;
            const completedInThisUnit = unitLessons.filter((l) =>
              student.completedLessons.includes(l.id)
            ).length;
            const unitPercent = Math.round((completedInThisUnit / unitLessons.length) * 100);

            const colorStyles = {
              1: 'border-emerald-500/30 hover:border-emerald-500 bg-gradient-to-br from-emerald-500/5 via-transparent to-transparent',
              2: 'border-teal-500/30 hover:border-teal-500 bg-gradient-to-br from-teal-500/5 via-transparent to-transparent',
              3: 'border-amber-500/30 hover:border-amber-500 bg-gradient-to-br from-amber-500/5 via-transparent to-transparent',
              4: 'border-blue-500/30 hover:border-blue-500 bg-gradient-to-br from-blue-500/5 via-transparent to-transparent',
            }[unit.id] || 'border-slate-300';

            const badgeBg = {
              1: 'bg-emerald-500 text-white',
              2: 'bg-teal-500 text-white',
              3: 'bg-amber-500 text-white',
              4: 'bg-blue-500 text-white',
            }[unit.id];

            return (
              <div
                key={unit.id}
                className={`relative rounded-3xl p-6 sm:p-7 bg-white dark:bg-slate-900 border transition-all duration-300 shadow-lg hover:shadow-xl ${colorStyles}`}
              >
                {/* Header Tag */}
                <div className="flex items-center justify-between gap-3 mb-4">
                  <span className="text-[11px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                    {isAr ? unit.moduleNameAr : unit.moduleNameEn}
                  </span>
                  <span className={`px-2.5 py-1 rounded-full text-xs font-black shadow-sm ${badgeBg}`}>
                    {isAr ? `الوحدة ${unit.id}` : `Unit ${unit.id}`}
                  </span>
                </div>

                <h3 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white mb-2">
                  {isAr ? unit.titleAr : unit.titleEn}
                </h3>
                <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 mb-6 leading-relaxed">
                  {isAr ? unit.descriptionAr : unit.descriptionEn}
                </p>

                {/* Progress bar within unit */}
                <div className="space-y-2 mb-6">
                  <div className="flex items-center justify-between text-xs font-semibold">
                    <span className="text-slate-500 dark:text-slate-400">
                      {isAr
                        ? `تم إنجاز ${completedInThisUnit} من ${unitLessons.length} دروس`
                        : `${completedInThisUnit} of ${unitLessons.length} lessons completed`}
                    </span>
                    <span className="font-bold text-slate-700 dark:text-slate-200">{unitPercent}%</span>
                  </div>
                  <div className="w-full h-2 rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden">
                    <div
                      className={`h-full transition-all duration-500 ${badgeBg}`}
                      style={{ width: `${unitPercent}%` }}
                    />
                  </div>
                </div>

                {/* Quick preview of key lessons */}
                <div className="space-y-1.5 mb-6 text-xs text-slate-600 dark:text-slate-400">
                  <div className="font-bold text-slate-700 dark:text-slate-300 mb-2">
                    {isAr ? 'أبرز الدروس في هذه الوحدة:' : 'Key lessons preview:'}
                  </div>
                  {unit.lessons.slice(0, 4).map((les) => (
                    <div key={les.id} className="flex items-center gap-2">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 flex-shrink-0" />
                      <span className="font-semibold text-slate-900 dark:text-slate-200">
                        {isAr ? les.titleAr : les.titleEn}
                      </span>
                      <span className="text-[10px] text-slate-400">({les.type})</span>
                    </div>
                  ))}
                  <div className="text-[11px] text-slate-400 pt-1">
                    {isAr ? `+ ${unit.lessons.length - 4} دروس إضافية...` : `+ ${unit.lessons.length - 4} more lessons...`}
                  </div>
                </div>

                {/* Action button */}
                <button
                  onClick={() => handleStartUnit(unit.id)}
                  className="w-full inline-flex items-center justify-center gap-2 py-3 px-4 rounded-xl text-xs sm:text-sm font-bold bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-900 dark:text-white transition-colors cursor-pointer"
                >
                  <span>{isAr ? 'عرض جميع دروس واختبارات الوحدة' : 'Explore All Lessons & Quiz'}</span>
                  <ArrowIcon className="w-4 h-4" />
                </button>
              </div>
            );
          })}
        </div>
      </section>

      {/* Inspirational Kuwait Vision & Educational Values Box */}
      <section className="rounded-3xl bg-slate-100 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-800 p-6 sm:p-8 flex flex-col md:flex-row items-center gap-6">
        <div className="w-16 h-16 rounded-2xl bg-amber-500/10 text-amber-500 flex items-center justify-center flex-shrink-0">
          <Compass className="w-8 h-8" />
        </div>
        <div className="space-y-1 flex-1">
          <div className="flex items-center gap-2 text-xs font-bold text-amber-600 dark:text-amber-400 uppercase tracking-wider">
            <Star className="w-3.5 h-3.5 fill-amber-500 text-amber-500" />
            <span>{isAr ? 'رؤية الكويت 2035 ومهارات القرن الحادي والعشرين' : 'Kuwait Vision 2035 & 21st Century Skills'}</span>
          </div>
          <h4 className="text-base sm:text-lg font-black text-slate-900 dark:text-white">
            {isAr ? 'الإنجليزية جسر للتطوير الذاتي والفخر الوطني' : 'English as a Bridge to Growth and National Pride'}
          </h4>
          <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 leading-relaxed">
            {isAr
              ? 'يركز مقرر Origin to Outlook على المهارات الأربع (التفكير الناقد، التعاون، التواصل، والإبداع 4Cs) وتنمية المواطنة المسؤولة والوعي البيئي والصحي.'
              : 'The curriculum promotes the 4Cs (Critical thinking, Collaboration, Communication, Creativity) along with digital literacy and responsible citizenship.'}
          </p>
        </div>
        <button
          onClick={() => {
            setCurrentSection('review');
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          className="flex-shrink-0 px-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 text-xs font-bold text-slate-800 dark:text-slate-200 hover:bg-white dark:hover:bg-slate-800 transition-colors cursor-pointer"
        >
          {isAr ? 'المراجعة الشاملة للاختبار' : 'Final Exam Review'}
        </button>
      </section>
    </div>
  );
};
