import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { UNITS_DATA } from '../data/unitsData';
import { Lesson } from '../types';
import {
  BookOpen,
  Volume2,
  CheckCircle2,
  Circle,
  FileText,
  Sparkles,
  Headphones,
  Mic,
  PenTool,
  Bookmark,
  Layers,
  ArrowRight,
  ArrowLeft,
  BookA,
} from 'lucide-react';
import { LessonDetailModal } from './LessonDetailModal';

export const UnitsView: React.FC = () => {
  const {
    language,
    selectedUnitId,
    setSelectedUnitId,
    student,
    markLessonComplete,
    speakText,
    setCurrentSection,
  } = useApp();

  const [activeLesson, setActiveLesson] = useState<Lesson | null>(null);
  const isAr = language === 'ar';
  const ArrowIcon = isAr ? ArrowLeft : ArrowRight;

  const currentUnit = UNITS_DATA.find((u) => u.id === selectedUnitId) || UNITS_DATA[0];

  const getLessonIcon = (type: Lesson['type']) => {
    switch (type) {
      case 'Reading':
        return BookOpen;
      case 'Grammar':
        return Sparkles;
      case 'Listening':
        return Headphones;
      case 'Speaking':
        return Mic;
      case 'Writing':
        return PenTool;
      default:
        return Layers;
    }
  };

  const getBadgeColor = (type: Lesson['type']) => {
    switch (type) {
      case 'Reading':
        return 'bg-blue-100 text-blue-800 dark:bg-blue-950/80 dark:text-blue-300 border-blue-300 dark:border-blue-800';
      case 'Grammar':
        return 'bg-amber-100 text-amber-800 dark:bg-amber-950/80 dark:text-amber-300 border-amber-300 dark:border-amber-800';
      case 'Listening':
        return 'bg-purple-100 text-purple-800 dark:bg-purple-950/80 dark:text-purple-300 border-purple-300 dark:border-purple-800';
      case 'Speaking':
        return 'bg-rose-100 text-rose-800 dark:bg-rose-950/80 dark:text-rose-300 border-rose-300 dark:border-rose-800';
      case 'Writing':
        return 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/80 dark:text-emerald-300 border-emerald-300 dark:border-emerald-800';
      default:
        return 'bg-slate-100 text-slate-800 dark:bg-slate-800 dark:text-slate-300 border-slate-300 dark:border-slate-700';
    }
  };

  return (
    <div className="space-y-8 animate-fadeIn">
      {/* Unit Selector Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white">
            {isAr ? 'الوحدات الدراسية والدروس' : 'Units & Curriculum Lessons'}
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400">
            {isAr
              ? 'اختر الوحدة لاستعراض كافة الدروس الإحدى عشرة بالترتيب ونصوص القراءة والتسجيلات'
              : 'Select a unit to view all 11 sequential lessons, reading passages, and audio scripts'}
          </p>
        </div>

        {/* Quick Quiz link */}
        <button
          onClick={() => {
            setCurrentSection('quizzes');
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-black shadow-md cursor-pointer transition-transform active:scale-95"
        >
          <CheckCircle2 className="w-4 h-4" />
          <span>{isAr ? `اختبار الوحدة ${currentUnit.id}` : `Unit ${currentUnit.id} Quiz`}</span>
        </button>
      </div>

      {/* Unit Tabs */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-2.5">
        {UNITS_DATA.map((u) => {
          const isSelected = u.id === currentUnit.id;
          const completedCount = u.lessons.filter((l) => student.completedLessons.includes(l.id)).length;
          return (
            <button
              key={u.id}
              onClick={() => setSelectedUnitId(u.id)}
              className={`p-4 rounded-2xl text-start transition-all cursor-pointer border ${
                isSelected
                  ? 'bg-emerald-600 text-white border-emerald-600 shadow-lg shadow-emerald-600/20'
                  : 'bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-800 hover:border-emerald-500/50'
              }`}
            >
              <div className="flex items-center justify-between mb-1.5">
                <span className={`text-[11px] font-black uppercase tracking-wider ${isSelected ? 'text-emerald-200' : 'text-slate-400'}`}>
                  {isAr ? `الوحدة ${u.id}` : `Unit ${u.id}`}
                </span>
                <span className={`text-[11px] font-bold px-2 py-0.5 rounded-full ${isSelected ? 'bg-white/20 text-white' : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400'}`}>
                  {completedCount}/{u.lessons.length}
                </span>
              </div>
              <h3 className="font-extrabold text-xs sm:text-sm line-clamp-1">
                {isAr ? u.titleAr : u.titleEn}
              </h3>
            </button>
          );
        })}
      </div>

      {/* Current Unit Overview Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-slate-900 text-white p-6 sm:p-8 border border-slate-800 shadow-xl">
        <div className="max-w-3xl space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-400 text-xs font-bold border border-emerald-500/30">
            <span>{isAr ? currentUnit.moduleNameAr : currentUnit.moduleNameEn}</span>
          </div>

          <h2 className="text-2xl sm:text-3xl font-black">
            {isAr ? currentUnit.titleAr : currentUnit.titleEn}
          </h2>
          <p className="text-slate-300 text-xs sm:text-sm leading-relaxed">
            {isAr ? currentUnit.descriptionAr : currentUnit.descriptionEn}
          </p>

          {/* Educational Values & 21st Century Skills from Textbook */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-3 text-xs border-t border-slate-800">
            <div>
              <span className="font-bold text-emerald-400 block mb-1.5">
                {isAr ? 'القيم التربوية (Educational Values):' : 'Educational Values:'}
              </span>
              <div className="flex flex-wrap gap-1.5">
                {currentUnit.educationalValues.map((val, idx) => (
                  <span key={idx} className="px-2 py-0.5 rounded-md bg-white/5 border border-white/10 text-slate-300">
                    {val}
                  </span>
                ))}
              </div>
            </div>
            <div>
              <span className="font-bold text-cyan-400 block mb-1.5">
                {isAr ? 'مهارات القرن الحادي والعشرين (21st Century Skills):' : '21st Century Skills:'}
              </span>
              <div className="flex flex-wrap gap-1.5">
                {currentUnit.centurySkills.map((sk, idx) => (
                  <span key={idx} className="px-2 py-0.5 rounded-md bg-white/5 border border-white/10 text-slate-300">
                    {sk}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* 11 Lessons List */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-lg sm:text-xl font-black text-slate-900 dark:text-white">
            {isAr
              ? `دروس الوحدة بالترتيب الكامل (${currentUnit.lessons.length} دروس)`
              : `All ${currentUnit.lessons.length} Sequential Lessons`}
          </h3>
          <span className="text-xs text-slate-500 dark:text-slate-400">
            {isAr ? 'انقر على أي درس للاطلاع على المحتوى والتمارين' : 'Click any lesson to open full activities'}
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {currentUnit.lessons.map((lesson) => {
            const Icon = getLessonIcon(lesson.type);
            const isCompleted = student.completedLessons.includes(lesson.id);
            const badgeClass = getBadgeColor(lesson.type);

            return (
              <div
                key={lesson.id}
                onClick={() => setActiveLesson(lesson)}
                className={`group relative p-5 rounded-2xl bg-white dark:bg-slate-900 border transition-all duration-200 cursor-pointer shadow-sm hover:shadow-md ${
                  isCompleted
                    ? 'border-emerald-500/40 dark:border-emerald-500/30'
                    : 'border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700'
                }`}
              >
                <div className="flex items-start justify-between gap-3 mb-3">
                  <div className="flex items-center gap-2">
                    <span className={`px-2.5 py-0.5 rounded-lg text-xs font-bold border ${badgeClass}`}>
                      {lesson.type}
                    </span>
                    <span className="text-xs font-semibold text-slate-400">
                      {isAr ? `درس ${lesson.lessonNumber}` : `Lesson ${lesson.lessonNumber}`}
                    </span>
                    <span className="text-xs font-semibold text-slate-400">
                      • {isAr ? `ص ${lesson.pageNumber}` : `p. ${lesson.pageNumber}`}
                    </span>
                  </div>

                  {/* Complete check button */}
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      markLessonComplete(lesson.id);
                    }}
                    className="text-slate-400 hover:text-emerald-500 cursor-pointer p-1"
                    title={isCompleted ? (isAr ? 'تم إنجازه' : 'Completed') : (isAr ? 'تحديد كمنجز' : 'Mark as complete')}
                  >
                    {isCompleted ? (
                      <CheckCircle2 className="w-5 h-5 text-emerald-500 fill-emerald-500/20" />
                    ) : (
                      <Circle className="w-5 h-5 text-slate-300 dark:text-slate-700 hover:text-emerald-500" />
                    )}
                  </button>
                </div>

                <h4 className="text-base font-extrabold text-slate-900 dark:text-white mb-1.5 group-hover:text-emerald-600 dark:group-hover:text-emerald-400 transition-colors">
                  {isAr ? lesson.titleAr : lesson.titleEn}
                </h4>
                <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-2 mb-4 leading-relaxed">
                  {isAr ? lesson.objectiveAr : lesson.objectiveEn}
                </p>

                {/* Target Vocab Chips if any */}
                {lesson.newVocabulary.length > 0 && (
                  <div className="flex flex-wrap items-center gap-1.5 pt-2 border-t border-slate-100 dark:border-slate-800">
                    <span className="text-[11px] font-bold text-slate-400 flex items-center gap-1">
                      <BookA className="w-3 h-3" />
                      {isAr ? 'مفردات الدرس:' : 'Vocab:'}
                    </span>
                    {lesson.newVocabulary.map((word, wIdx) => (
                      <button
                        key={wIdx}
                        onClick={(e) => {
                          e.stopPropagation();
                          speakText(word);
                        }}
                        className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[11px] font-semibold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-emerald-50 dark:hover:bg-emerald-950/60 hover:text-emerald-700 dark:hover:text-emerald-300 transition-colors cursor-pointer"
                        title={isAr ? 'استمع للنطق' : 'Listen to pronunciation'}
                      >
                        <span>{word}</span>
                        <Volume2 className="w-2.5 h-2.5 text-slate-400" />
                      </button>
                    ))}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Lesson Detail Modal */}
      {activeLesson && (
        <LessonDetailModal
          lesson={activeLesson}
          onClose={() => setActiveLesson(null)}
        />
      )}
    </div>
  );
};
