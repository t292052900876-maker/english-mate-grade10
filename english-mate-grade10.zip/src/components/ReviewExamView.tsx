import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { FINAL_MOCK_EXAM } from '../data/quizzesData';
import {
  FileText,
  CheckCircle2,
  Printer,
  Sparkles,
  Trophy,
  RotateCcw,
  BookOpen,
  Award,
} from 'lucide-react';
import confetti from 'canvas-confetti';

export const ReviewExamView: React.FC = () => {
  const { language, saveQuizScore, student } = useApp();
  const isAr = language === 'ar';

  const [answers, setAnswers] = useState<Record<string, number>>({});
  const [submitted, setSubmitted] = useState<boolean>(false);

  const questions = FINAL_MOCK_EXAM.questions;

  const handleSelect = (qId: string, idx: number) => {
    if (submitted) return;
    setAnswers((prev) => ({ ...prev, [qId]: idx }));
  };

  const calculateScore = () => {
    let count = 0;
    questions.forEach((q) => {
      if (answers[q.id] === q.correctAnswer) count++;
    });
    return count;
  };

  const handleSubmit = () => {
    const score = calculateScore();
    setSubmitted(true);
    saveQuizScore('final-mock-exam', score, questions.length);

    if (score >= questions.length * 0.7) {
      confetti({
        particleCount: 100,
        spread: 90,
        origin: { y: 0.5 },
      });
    }
  };

  const score = calculateScore();
  const percentage = Math.round((score / questions.length) * 100);

  return (
    <div className="space-y-8 animate-fadeIn">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-100 dark:bg-blue-950/80 text-blue-800 dark:text-blue-300 text-xs font-bold border border-blue-300 dark:border-blue-800 mb-2">
            <FileText className="w-3.5 h-3.5" />
            <span>{isAr ? 'نموذج الاختبار الشامل الموحد' : 'Comprehensive Mock Examination'}</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white">
            {isAr ? 'المراجعة الشاملة ونموذج الاختبار النهائي' : 'Comprehensive Final Review & Mock Exam'}
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400">
            {isAr
              ? 'مراجعة لكافة مفردات وقواعد ووظائف منهج Origin to Outlook (Grade 10A) المعد لوزارة التربية'
              : 'End-of-term revision covering Vocabulary, Grammar, Functions, and Reading for Grade 10A'}
          </p>
        </div>

        <button
          onClick={() => window.print()}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200 text-xs font-bold hover:border-blue-500 cursor-pointer"
        >
          <Printer className="w-4 h-4 text-slate-500" />
          <span>{isAr ? 'طباعة الاختبار' : 'Print Exam Paper'}</span>
        </button>
      </div>

      {/* Official Kuwait Exam Header Style Card */}
      <div className="p-6 sm:p-8 rounded-3xl bg-white dark:bg-slate-900 border-2 border-slate-200 dark:border-slate-800 shadow-md space-y-4">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 text-center sm:text-start border-b border-slate-200 dark:border-slate-800 pb-5">
          <div>
            <h3 className="text-sm font-black text-slate-900 dark:text-white">
              {isAr ? 'وزارة التربية – التوجيه الفني العام للغة الإنجليزية' : 'Ministry of Education – General ELT Supervision'}
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              {isAr ? 'امتحان نهاية الفصل الدراسي الأول – الصف العاشر (2026/2027)' : 'First Term Final Examination – Grade 10 (2026/2027)'}
            </p>
          </div>
          <div className="text-end">
            <span className="px-3 py-1 rounded-xl text-xs font-black bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
              {isAr ? 'الزمن: 45 دقيقة • الدرجة: 100' : 'Time: 45 mins • Marks: 100'}
            </span>
          </div>
        </div>

        {/* Results Banner */}
        {submitted && (
          <div className="p-6 rounded-2xl bg-gradient-to-r from-blue-600 to-indigo-600 text-white flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <Trophy className="w-10 h-10 text-amber-300 flex-shrink-0" />
              <div>
                <h4 className="text-xl font-black">
                  {isAr ? 'نتيجتك النهائية:' : 'Final Examination Result:'} {score} / {questions.length} ({percentage}%)
                </h4>
                <p className="text-xs text-blue-100">
                  {percentage >= 80
                    ? (isAr ? 'مبارك! حصلت على تقدير امتياز في مادة اللغة الإنجليزية 🌟' : 'Excellent! Outstanding performance in Grade 10 English.')
                    : (isAr ? 'أداء جيد، راجع أسئلة القواعد والمفردات لضمان التفوق.' : 'Good attempt! Review the grammar questions and recheck.')}
                </p>
              </div>
            </div>
            <button
              onClick={() => {
                setAnswers({});
                setSubmitted(false);
              }}
              className="px-4 py-2 rounded-xl bg-white text-slate-900 font-bold text-xs hover:bg-blue-50 cursor-pointer"
            >
              {isAr ? 'إعادة الاختبار' : 'Retake Exam'}
            </button>
          </div>
        )}

        {/* Questions list */}
        <div className="space-y-6 pt-4">
          {questions.map((q, idx) => {
            const selected = answers[q.id];
            const isCorrect = selected === q.correctAnswer;

            return (
              <div
                key={q.id}
                className={`p-5 rounded-2xl border transition-all ${
                  submitted
                    ? isCorrect
                      ? 'bg-emerald-50/20 border-emerald-500/50'
                      : 'bg-rose-50/20 border-rose-500/50'
                    : 'bg-slate-50 dark:bg-slate-800/40 border-slate-200 dark:border-slate-700'
                }`}
              >
                <div className="flex items-start justify-between gap-2 mb-3">
                  <div className="flex items-start gap-2.5">
                    <span className="w-6 h-6 rounded-lg bg-slate-200 dark:bg-slate-700 text-slate-800 dark:text-slate-200 text-xs font-black flex items-center justify-center flex-shrink-0">
                      {idx + 1}
                    </span>
                    <div>
                      <span className="text-[10px] font-bold text-blue-600 dark:text-blue-400 uppercase tracking-wider block">
                        Part {q.type === 'vocab' ? 'I: Vocabulary' : q.type === 'grammar' ? 'II: Grammar' : 'III: Functions & Skills'}
                      </span>
                      <p className="text-sm font-bold text-slate-900 dark:text-white mt-1">
                        {q.question}
                      </p>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
                  {q.options.map((opt, oIdx) => {
                    const isThisSelected = selected === oIdx;
                    let style =
                      'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-200 hover:border-blue-500';

                    if (isThisSelected) {
                      style = 'bg-blue-100 dark:bg-blue-950 border-blue-500 text-blue-900 dark:text-blue-100 font-bold';
                    }

                    if (submitted) {
                      if (oIdx === q.correctAnswer) {
                        style = 'bg-emerald-500 text-white border-emerald-600 font-bold';
                      } else if (isThisSelected && !isCorrect) {
                        style = 'bg-rose-500 text-white border-rose-600 font-bold';
                      } else {
                        style = 'bg-slate-100 dark:bg-slate-800 text-slate-400 opacity-60';
                      }
                    }

                    return (
                      <button
                        key={oIdx}
                        disabled={submitted}
                        onClick={() => handleSelect(q.id, oIdx)}
                        className={`p-3 rounded-xl text-xs text-start font-medium border transition-all cursor-pointer ${style}`}
                      >
                        {String.fromCharCode(65 + oIdx)}. {opt}
                      </button>
                    );
                  })}
                </div>

                {submitted && (
                  <div className="mt-3 p-3 rounded-xl text-xs bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-sans">
                    <span className="font-bold text-emerald-600 dark:text-emerald-400 block mb-0.5">
                      {isCorrect ? '✓ Correct' : '✗ Incorrect'}:
                    </span>
                    {q.explanation}
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Submit */}
        {!submitted && (
          <div className="pt-6 border-t border-slate-200 dark:border-slate-800 flex justify-center">
            <button
              onClick={handleSubmit}
              disabled={Object.keys(answers).length === 0}
              className="px-8 py-3.5 rounded-2xl bg-blue-600 hover:bg-blue-500 text-white text-sm font-black shadow-lg shadow-blue-600/30 cursor-pointer transition-transform active:scale-95"
            >
              {isAr
                ? `تسليم ورقة الامتحان (${Object.keys(answers).length} من ${questions.length})`
                : `Submit Final Exam Paper (${Object.keys(answers).length}/${questions.length})`}
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
