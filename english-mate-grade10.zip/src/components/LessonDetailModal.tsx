import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Lesson } from '../types';
import {
  X,
  Volume2,
  CheckCircle2,
  BookOpen,
  Sparkles,
  Headphones,
  Mic,
  PenTool,
  Send,
  HelpCircle,
  Award,
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface Props {
  lesson: Lesson;
  onClose: () => void;
}

export const LessonDetailModal: React.FC<Props> = ({ lesson, onClose }) => {
  const { language, student, markLessonComplete, speakText } = useApp();
  const isAr = language === 'ar';

  const [selectedAnswers, setSelectedAnswers] = useState<Record<string, any>>({});
  const [showResults, setShowResults] = useState<Record<string, boolean>>({});
  const [studentWriting, setStudentWriting] = useState('');
  const [isReadingAloud, setIsReadingAloud] = useState(false);

  const isCompleted = student.completedLessons.includes(lesson.id);

  const handleSelectAnswer = (taskId: string, answer: any) => {
    setSelectedAnswers((prev) => ({ ...prev, [taskId]: answer }));
    setShowResults((prev) => ({ ...prev, [taskId]: true }));
  };

  const handleCompleteLesson = () => {
    markLessonComplete(lesson.id);
    confetti({
      particleCount: 50,
      spread: 60,
      origin: { y: 0.7 },
    });
  };

  const handleReadAloudText = (text: string) => {
    if (isReadingAloud) {
      window.speechSynthesis.cancel();
      setIsReadingAloud(false);
    } else {
      speakText(text);
      setIsReadingAloud(true);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6 animate-fadeIn">
      <div className="relative w-full max-w-4xl bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden my-6 max-h-[92vh] flex flex-col">
        {/* Header Bar */}
        <div className="sticky top-0 z-20 flex items-center justify-between p-5 sm:p-6 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-b border-slate-200 dark:border-slate-800">
          <div className="flex items-center gap-3">
            <span className="px-3 py-1 rounded-xl text-xs font-black bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-800">
              {lesson.type}
            </span>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-slate-400">
                  {isAr ? `الوحدة ${lesson.unitId} • درس ${lesson.lessonNumber}` : `Unit ${lesson.unitId} • Lesson ${lesson.lessonNumber}`}
                </span>
                <span className="text-xs text-slate-400">•</span>
                <span className="text-xs font-bold text-slate-400">
                  {isAr ? `كتاب الطالب ص ${lesson.pageNumber}` : `Page ${lesson.pageNumber}`}
                </span>
              </div>
              <h2 className="text-lg sm:text-xl font-black text-slate-900 dark:text-white">
                {isAr ? lesson.titleAr : lesson.titleEn}
              </h2>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Modal Body Scrollable Content */}
        <div className="p-5 sm:p-8 overflow-y-auto space-y-8 flex-1">
          {/* CEFR Learning Objective Box */}
          <div className="p-4 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800/60">
            <span className="text-[11px] font-black uppercase text-emerald-700 dark:text-emerald-400 tracking-wider block mb-1">
              {isAr ? 'مخرج التعلم المستهدف (Can-Do Objective):' : 'Can-Do Learning Objective:'}
            </span>
            <p className="text-xs sm:text-sm font-semibold text-emerald-900 dark:text-emerald-200">
              {isAr ? lesson.objectiveAr : lesson.objectiveEn}
            </p>
          </div>

          {/* New Vocabulary if present */}
          {lesson.newVocabulary.length > 0 && (
            <div className="space-y-3">
              <h3 className="text-sm font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
                <BookOpen className="w-4 h-4 text-emerald-500" />
                <span>{isAr ? 'المفردات الجديدة في هذا الدرس' : 'Target New Vocabulary'}</span>
              </h3>
              <div className="flex flex-wrap gap-2">
                {lesson.newVocabulary.map((word, idx) => (
                  <button
                    key={idx}
                    onClick={() => speakText(word)}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold bg-slate-100 dark:bg-slate-800 hover:bg-emerald-100 dark:hover:bg-emerald-950 text-slate-800 dark:text-slate-200 hover:text-emerald-700 dark:hover:text-emerald-300 transition-colors cursor-pointer border border-slate-200 dark:border-slate-700"
                  >
                    <span>{word}</span>
                    <Volume2 className="w-3.5 h-3.5 text-slate-400" />
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Reading Section */}
          {lesson.content.readingText && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-base font-black text-slate-900 dark:text-white flex items-center gap-2">
                  <BookOpen className="w-5 h-5 text-blue-500" />
                  <span>{isAr ? 'نص القراءة من كتاب الطالب' : 'Reading Passage'}</span>
                </h3>

                <button
                  onClick={() => handleReadAloudText(lesson.content.readingText!)}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold bg-blue-50 dark:bg-blue-950 text-blue-700 dark:text-blue-300 hover:bg-blue-100 dark:hover:bg-blue-900 transition-colors cursor-pointer border border-blue-200 dark:border-blue-800"
                >
                  <Volume2 className="w-4 h-4" />
                  <span>{isReadingAloud ? (isAr ? 'إيقاف الصوت' : 'Stop Audio') : (isAr ? 'قراءة النص بالإنجليزية' : 'Listen to Passage')}</span>
                </button>
              </div>

              <div
                dir="ltr"
                className="p-6 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80 text-sm leading-relaxed text-slate-800 dark:text-slate-200 font-sans whitespace-pre-line space-y-4"
              >
                {lesson.content.readingText}
              </div>
            </div>
          )}

          {/* Listening Section */}
          {lesson.content.listeningScript && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-base font-black text-slate-900 dark:text-white flex items-center gap-2">
                  <Headphones className="w-5 h-5 text-purple-500" />
                  <span>{isAr ? 'نص الاستماع الصوتي والمحادثة' : 'Listening Script & Audio'}</span>
                </h3>

                <button
                  onClick={() => handleReadAloudText(lesson.content.listeningScript!)}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold bg-purple-50 dark:bg-purple-950 text-purple-700 dark:text-purple-300 hover:bg-purple-100 dark:hover:bg-purple-900 transition-colors cursor-pointer border border-purple-200 dark:border-purple-800"
                >
                  <Volume2 className="w-4 h-4" />
                  <span>{isReadingAloud ? (isAr ? 'إيقاف' : 'Stop') : (isAr ? 'تشغيل المقطع الصوتي' : 'Play Audio')}</span>
                </button>
              </div>

              <div
                dir="ltr"
                className="p-6 rounded-2xl bg-purple-50/50 dark:bg-purple-950/20 border border-purple-200 dark:border-purple-900/50 text-sm leading-relaxed text-slate-800 dark:text-slate-200 font-sans whitespace-pre-line"
              >
                {lesson.content.listeningScript}
              </div>
            </div>
          )}

          {/* Useful Language Box (Speaking) */}
          {lesson.content.usefulLanguage && lesson.content.usefulLanguage.length > 0 && (
            <div className="space-y-4">
              <h3 className="text-base font-black text-slate-900 dark:text-white flex items-center gap-2">
                <Mic className="w-5 h-5 text-rose-500" />
                <span>{isAr ? 'صندوق التعبيرات المفيدة (Useful Language)' : 'Useful Language Box'}</span>
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {lesson.content.usefulLanguage.map((box, bIdx) => (
                  <div
                    key={bIdx}
                    className="p-4 rounded-2xl bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-900/50 space-y-2"
                  >
                    <h4 className="text-xs font-black text-amber-800 dark:text-amber-300 uppercase tracking-wider">
                      {box.title}
                    </h4>
                    <ul className="space-y-1.5 text-xs text-slate-700 dark:text-slate-200">
                      {box.expressions.map((exp, eIdx) => (
                        <li key={eIdx} className="flex items-start gap-1.5">
                          <span className="text-amber-500 font-bold">•</span>
                          <span>{exp}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Writing Guide & Interactive Writing Pad */}
          {lesson.content.writingPrompt && (
            <div className="space-y-4">
              <h3 className="text-base font-black text-slate-900 dark:text-white flex items-center gap-2">
                <PenTool className="w-5 h-5 text-emerald-500" />
                <span>{isAr ? 'مهمة الكتابة وفق إرشادات الوزارة' : 'Writing Prompt & Practice'}</span>
              </h3>

              <div className="p-5 rounded-2xl bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800/60 space-y-3">
                <p className="text-sm font-bold text-emerald-900 dark:text-emerald-100">
                  {lesson.content.writingPrompt.topic}
                </p>
                <div className="flex flex-wrap gap-2 text-xs">
                  <span className="font-bold text-slate-700 dark:text-slate-300">{isAr ? 'أدوات الربط المطلوبة:' : 'Target Linkers:'}</span>
                  {lesson.content.writingPrompt.linkers.map((linker, lIdx) => (
                    <span key={lIdx} className="px-2 py-0.5 rounded-md bg-white dark:bg-slate-900 font-semibold text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800">
                      {linker}
                    </span>
                  ))}
                </div>
              </div>

              {/* Model paragraph */}
              {lesson.content.writingPrompt.modelParagraph && (
                <div className="space-y-2">
                  <span className="text-xs font-bold text-slate-500 dark:text-slate-400">
                    {isAr ? 'الفقرة النموذجية الإرشادية (Model Paragraph):' : 'Model Paragraph:'}
                  </span>
                  <div
                    dir="ltr"
                    className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 text-xs text-slate-700 dark:text-slate-300 leading-relaxed font-sans"
                  >
                    {lesson.content.writingPrompt.modelParagraph}
                  </div>
                </div>
              )}

              {/* Interactive Writing Pad */}
              <div className="space-y-2 pt-2">
                <label className="text-xs font-bold text-slate-700 dark:text-slate-200 block">
                  {isAr ? 'مساحة التدريب لكتابة مسودتك الخاصة:' : 'Your Writing Pad:'}
                </label>
                <textarea
                  value={studentWriting}
                  onChange={(e) => setStudentWriting(e.target.value)}
                  placeholder={
                    isAr
                      ? 'اكتب هنا فقرتك بالإنجليزية مع استخدام أدوات الربط (Topic sentence, Supporting ideas, Conclusion)...'
                      : 'Type your English paragraph here with linkers...'
                  }
                  dir="ltr"
                  rows={5}
                  className="w-full p-4 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-sm font-sans focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
                <div className="flex justify-between items-center text-xs text-slate-400">
                  <span>
                    {isAr ? 'عدد الكلمات:' : 'Words:'}{' '}
                    {studentWriting.trim() ? studentWriting.trim().split(/\s+/).length : 0}
                  </span>
                  <span className="text-emerald-600 font-semibold">
                    {isAr ? 'المطلوب: 8 جمل (حوالي 90 كلمة)' : 'Requirement: 8 sentences (~90 words)'}
                  </span>
                </div>
              </div>
            </div>
          )}

          {/* Interactive Lesson Tasks */}
          {lesson.content.tasks && lesson.content.tasks.length > 0 && (
            <div className="space-y-4 pt-4 border-t border-slate-200 dark:border-slate-800">
              <h3 className="text-base font-black text-slate-900 dark:text-white flex items-center gap-2">
                <HelpCircle className="w-5 h-5 text-amber-500" />
                <span>{isAr ? 'تدريبات الدرس التفاعلية' : 'Interactive Lesson Exercises'}</span>
              </h3>

              <div className="space-y-5">
                {lesson.content.tasks.map((task, tIdx) => {
                  const isAnswered = showResults[task.id];
                  const userAnswer = selectedAnswers[task.id];
                  const isCorrect = userAnswer === task.correctAnswer;

                  return (
                    <div
                      key={task.id}
                      className="p-5 rounded-2xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-700/80 space-y-3"
                    >
                      <div className="flex items-start gap-3">
                        <span className="w-6 h-6 rounded-full bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300 flex items-center justify-center font-bold text-xs flex-shrink-0">
                          {tIdx + 1}
                        </span>
                        <div className="space-y-1 flex-1">
                          <p className="text-sm font-bold text-slate-900 dark:text-white">
                            {task.questionEn}
                          </p>
                          {isAr && (
                            <p className="text-xs text-slate-500 dark:text-slate-400">
                              {task.questionAr}
                            </p>
                          )}
                        </div>
                      </div>

                      {/* Options */}
                      {task.options && (
                        <div className="grid grid-cols-1 gap-2 pt-2">
                          {task.options.map((opt, oIdx) => {
                            const isThisSelected = userAnswer === (task.type === 'true_false' ? (oIdx === 0) : oIdx);
                            let btnStyle =
                              'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-200 hover:border-emerald-500';

                            if (isAnswered) {
                              const isThisCorrect =
                                task.type === 'true_false'
                                  ? (oIdx === 0 && task.correctAnswer === true) || (oIdx === 1 && task.correctAnswer === false)
                                  : oIdx === task.correctAnswer;

                              if (isThisCorrect) {
                                btnStyle = 'bg-emerald-500 text-white border-emerald-600 font-bold';
                              } else if (isThisSelected && !isThisCorrect) {
                                btnStyle = 'bg-rose-500 text-white border-rose-600 font-bold';
                              }
                            }

                            return (
                              <button
                                key={oIdx}
                                onClick={() => handleSelectAnswer(task.id, task.type === 'true_false' ? oIdx === 0 : oIdx)}
                                className={`p-3 rounded-xl text-xs sm:text-sm text-start font-medium border transition-all cursor-pointer ${btnStyle}`}
                              >
                                {opt}
                              </button>
                            );
                          })}
                        </div>
                      )}

                      {/* Explanation Feedback */}
                      {isAnswered && (
                        <div
                          className={`p-3 rounded-xl text-xs ${
                            isCorrect
                              ? 'bg-emerald-100 text-emerald-900 dark:bg-emerald-950/60 dark:text-emerald-200'
                              : 'bg-rose-100 text-rose-900 dark:bg-rose-950/60 dark:text-rose-200'
                          }`}
                        >
                          <p className="font-bold mb-1">
                            {isCorrect
                              ? (isAr ? 'إجابة صحيحة وذكية! أحسنت 🌟' : 'Excellent! Correct answer 🌟')
                              : (isAr ? 'إجابة غير دقيقة. راجع التوضيح التالي:' : 'Incorrect. Check the explanation:')}
                          </p>
                          <p>{task.explanation}</p>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="sticky bottom-0 z-20 flex items-center justify-between p-5 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-t border-slate-200 dark:border-slate-800">
          <div className="flex items-center gap-2">
            {isCompleted ? (
              <span className="inline-flex items-center gap-1.5 text-xs font-bold text-emerald-600 dark:text-emerald-400">
                <CheckCircle2 className="w-4 h-4" />
                <span>{isAr ? 'تم إنجاز هذا الدرس وتوثيقه' : 'Lesson Completed'}</span>
              </span>
            ) : (
              <span className="text-xs text-slate-400 font-medium">
                {isAr ? 'أكمل القراءة والتمارين لتوثيق إنجازك' : 'Complete activities to earn progress'}
              </span>
            )}
          </div>

          <button
            onClick={handleCompleteLesson}
            className={`inline-flex items-center gap-2 px-5 py-2.5 rounded-xl text-xs sm:text-sm font-black transition-all cursor-pointer ${
              isCompleted
                ? 'bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300'
                : 'bg-emerald-500 hover:bg-emerald-400 text-slate-950 shadow-md shadow-emerald-500/20 active:scale-95'
            }`}
          >
            <CheckCircle2 className="w-4 h-4" />
            <span>{isCompleted ? (isAr ? 'تم حفظ الإنجاز (+15 نقطة)' : 'Completed (+15 pts)') : (isAr ? 'توثيق إنجاز الدرس (+15 نقطة)' : 'Mark Complete (+15 pts)')}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
