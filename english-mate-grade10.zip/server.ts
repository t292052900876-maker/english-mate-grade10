import express, { Request, Response } from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

app.use(express.json());

// Initialize GoogleGenAI server-side with telemetry header
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY || '',
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

const SYSTEM_INSTRUCTION = `You are "English Mate AI", an expert English teacher and tutor for Kuwait Grade 10 secondary school students, strictly aligned with the Kuwait Ministry of Education curriculum textbook "Origin to Outlook - Grade 10A (2026/2027)".

Key textbook content guidelines:
- Module 1: The Sustainable Self
  - Unit 1: The Science of Nutrition (Food Log Reflection, Evolution of Kuwaiti Diet, Present Simple & Adverbs of Frequency, Heritage Lunchbox, International School Meal Systems, Smart Canteen Swaps, Personalised Nutrition, Present Continuous & Order of Adjectives OSASCOMP, Mediterranean Secret, Food Marketing, Mindful Eating).
  - Unit 2: Choices & Change (Sustainable Living, Shagaya Renewable Energy Park, Present Perfect Simple with since/for/already/just/yet/lately, Smart Homes, Powering Greener GCC, Power With Purpose, Think Before You Throw, 1st If Conditional & Modal Verbs, Rethinking Waste Worldwide, Throw-away Culture, Habits for a Better World).
- Module 2: Cultural Foundation & Civic Duty
  - Unit 3: Exploring Heritage (Stamps That Tell Our Story, Cultural Ambassadors: Mohammad Al Sharekh & Hamza Al Khayat, Non-defining Relative Pronouns & Clauses [who, which, whose, where, when], Stories Beyond The Walls [Bahla, Zubarah, Red Fort], Big Dreamers, Honour Inspire Remember, Can Technology Save Heritage? [Japan & Kuwait], Past Simple & Past Continuous [when/while/as], Continuous Culture: Sadu Weaving, Hidden Gems: The Secret Garden in Salmiya, Preserving Heritage).
  - Unit 4: Citizenship (What Makes a Good Citizen? [Souq Al-Mubarakiya, Dhows, Failaka], Timeless Growth [17th C Al-Kut, 18th C trade, 19th C maritime & Sheikh Mubarak, 1930s oil, 1961 independence & 1962 Constitution], Reported Speech rules, Address to the Nation [HH Sheikh Meshal Al-Ahmad Al-Jaber Al-Sabah], The Golden Rule, The Digital Diwan, Law Values & Universal Citizenship, Future Forms & Countable/Uncountable Nouns, Living Monuments [Qurain Martyrs' House, National Library, National Museum], The Invisible Safeguard, National Duty).

Teaching style:
- Friendly, encouraging, educational, and culturally respectful to Kuwait's heritage and Islamic values.
- Answer in bilingual Arabic and English when helpful to clarify English concepts or grammatical rules.
- Guide students through writing essays, checking grammar, spelling, and expanding on ideas using transition linkers (furthermore, moreover, consequently, therefore, ultimately).
- When a student asks about a word or rule, reference the unit and lesson if relevant.
- Keep answers concise, clear, well-formatted, and easy to read on mobile and desktop.`;

// API endpoint for AI Tutor Chat
app.post('/api/chat', async (req: Request, res: Response) => {
  try {
    const { message, conversationHistory } = req.body;

    if (!message || typeof message !== 'string') {
      return res.status(400).json({ error: 'Message is required' });
    }

    if (!process.env.GEMINI_API_KEY) {
      return res.status(200).json({
        reply: `مرحباً بك! أنا مساعدك الذكي في منصة English Mate. يبدو أن مفتاح Gemini API لم يتم تفعيله بعد في الإعدادات، ولكن يمكنك تصفح جميع دروس الوحدات الأربع، والقاموس الكامل، ومركز القواعد، والوظائف اللغوية والاختبارات التفاعلية بنجاح!`,
      });
    }

    // Build contents array with context
    const contents: any[] = [];
    if (Array.isArray(conversationHistory)) {
      for (const turn of conversationHistory.slice(-8)) {
        if (turn.role === 'user' || turn.role === 'model') {
          contents.push({
            role: turn.role,
            parts: [{ text: turn.text }],
          });
        }
      }
    }
    contents.push({
      role: 'user',
      parts: [{ text: message }],
    });

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: contents,
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
      },
    });

    const reply = response.text || 'I am ready to help you with your Grade 10 English studies!';
    return res.json({ reply });
  } catch (error: any) {
    console.error('Gemini API Error:', error);
    return res.status(500).json({
      error: 'Failed to generate response',
      details: error?.message || 'Unknown error',
    });
  }
});

// Setup Vite in development or serve static files in production
async function startServer() {
  const isProd = process.env.NODE_ENV === 'production';

  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
