# English Mate – Grade 10 (Origin to Outlook – 2026/2027) 🇰🇼

تطبيق ويب تعليمي شامل وتفاعلي لمقرر اللغة الإنجليزية للصف العاشر في دولة الكويت، مبني وفق منهج **Origin to Outlook – Grade 10A (2026/2027)** لوزارة التربية بدولة الكويت.

---

### إعداد وإشراف:
- **إعداد وتصميم:** أ. شريفه سالم المويزري
- **الموجهه الفنية:** أ. العنود الدغيم
- **مديرة المدرسة:** أ. سليمه العنزي

---

## 🚀 محتويات ومميزات المشروع:
1. **الصفحة الرئيسية (Dashboard):** مؤشر التقدم، النقاط، الأوسمة، ورابط مباشر لكتاب الطالب PDF.
2. **الوحدات الأربع (Units 1 to 4):** جميع الدروس الـ 44 بالترتيب الكامل مع نصوص القراءة، نصوص الاستماع، تمارين الفهم، والكتابة.
3. **قاموس المفردات (Glossary):** أكثر من 80 مفردة مع النطق الصوتي، المعنى العربي، والتعريف الإنجليزي، ووضع البطاقات التعليمية (Flashcards).
4. **مركز القواعد التسع (Grammar Center):** شرح مفصل لقواعد الكتاب، أداة OSASCOMP لترتيب الصفات، جداول الأفعال الشاذة والجامدة.
5. **بنك الوظائف اللغوية (Language Functions):** أكثر من 24 موقفاً لغوياً مع نماذج حوارات الامتحانات ونطق صوتي.
6. **المهارات الأربع (Skills Hub):** أقسام متخصصة لمهارات (Reading, Listening, Speaking, Writing).
7. **الاختبارات التفاعلية (Quizzes):** اختبار لكل وحدة مع درجات وتغذية راجعة فورية.
8. **المراجعة الشاملة (Mock Exam):** نموذج اختبار نهائي موحد قابل للطباعة.
9. **حساب الطالب (Profile):** حفظ التقدم محلياً في المتصفح وشهادة إنجاز قابلة للطباعة.
10. **مساعد ذكي (AI Tutor):** شات مخصص للمنهج عبر خادم Express وGemini API.

---

## 💻 متطلبات التشغيل المحلي (Prerequisites):
- تثبيت [Node.js](https://nodejs.org/) (الإصدار 18 أو 20 أو أحدث).
- مفتاح Google Gemini API (اختياري لتشغيل ميزة المساعد الذكي AI Tutor).

---

## 🛠️ خطوات التشغيل على جهازك الشخصي (Local Setup):

1. **فك ضغط ملف المشروع** ثم افتح مجلد المشروع في برنامج Visual Studio Code أو الطرفية (Terminal).
2. **تثبيت الحزم البرمجية:**
   ```bash
   npm install
   ```
3. **إعداد ملف البيئة:**
   قم بإنشاء ملف باسم `.env` في المجلد الرئيسي وضع فيه:
   ```env
   GEMINI_API_KEY="ضع_مفتاح_GEMINI_هنا"
   PORT=3000
   ```
4. **تشغيل خادم التطوير:**
   ```bash
   npm run dev
   ```
5. افتح المتصفح على الرابط:
   ```
   http://localhost:3000
   ```

---

## 📦 خطوات البناء للإنتاج (Production Build):
```bash
npm run build
```
سيتولد مجلد `dist` يحتوي على ملفات الواجهة المجمعة والسريعة.

---

## 🌐 خطوات ربط المشروع بحساب GitHub:

1. أنشئ مستودعاً جديداً (New Repository) على حسابك في [GitHub](https://github.com) باسم `english-mate-grade10`.
2. في الطرفية داخل مجلد المشروع، نفذ الأوامر التالية:
   ```bash
   git init
   git add .
   git commit -m "Initial commit of English Mate Grade 10"
   git branch -M main
   git remote add origin https://github.com/اسم_حسابك/english-mate-grade10.git
   git push -u origin main
   ```

---

## 🚀 طرق الاستضافة المجانية خارج AI Studio:

### 1. الاستضافة عبر منصة Render (موصى بها لتشغيل الخادم الكامل مع AI Tutor):
1. سجل دخولك على [Render.com](https://render.com) بحساب GitHub.
2. اختر **New +** ثم **Web Service**.
3. اربط مستودع GitHub الخاص بالمشروع.
4. اضبط الإعدادات التالية:
   - **Environment:** Node
   - **Build Command:** `npm install && npm run build`
   - **Start Command:** `npm run start`
   - **Environment Variables:** أضف `GEMINI_API_KEY` بقيمة مفتاحك.
5. اضغط **Deploy Web Service** وستحصل على رابط دائم خاص بك (مثل: `english-mate.onrender.com`).

### 2. الاستضافة عبر منصة Railway:
1. ادخل إلى [Railway.app](https://railway.app).
2. اختر **New Project** ➔ **Deploy from GitHub repo**.
3. أضف متغير البيئة `GEMINI_API_KEY`.
4. اضغط نشر وسيعمل فوراً مع رابط مباشر.

### 3. الاستضافة عبر منصة Vercel:
1. ادخل إلى [Vercel.com](https://vercel.com) واربط مستودع GitHub.
2. Vercel سيتعرف تلقائياً على مشروع Vite ويقوم بنشره خلال ثوانٍ.
